package inetsoft.report.design;

import inetsoft.report.Common;
import inetsoft.report.FixedContainer;
import inetsoft.report.Margin;
import inetsoft.report.PageArea;
import inetsoft.report.PageLayoutElement;
import inetsoft.report.Paintable;
import inetsoft.report.PainterElement;
import inetsoft.report.Position;
import inetsoft.report.PreviewPage;
import inetsoft.report.PreviewPane;
import inetsoft.report.ReportElement;
import inetsoft.report.SectionBand;
import inetsoft.report.SectionElement;
import inetsoft.report.SectionLens;
import inetsoft.report.Size;
import inetsoft.report.SpaceElement;
import inetsoft.report.StylePage;
import inetsoft.report.StyleSheet;
import inetsoft.report.TOC;
import inetsoft.report.TOCElement;
import inetsoft.report.TextElement;
import inetsoft.report.XStyleSheet;
import inetsoft.report.internal.AreaBreakElementDef;
import inetsoft.report.internal.BaseElement;
import inetsoft.report.internal.BasePaintable;
import inetsoft.report.internal.ChartXElement;
import inetsoft.report.internal.CompositeElementDef;
import inetsoft.report.internal.CondPageBreakElementDef;
import inetsoft.report.internal.EmptyContainer;
import inetsoft.report.internal.EmptyPainter;
import inetsoft.report.internal.HeadingElementDef;
import inetsoft.report.internal.ImageXElement;
import inetsoft.report.internal.NewlineElementDef;
import inetsoft.report.internal.PageBreakElementDef;
import inetsoft.report.internal.PageLayoutElementDef;
import inetsoft.report.internal.PainterElementDef;
import inetsoft.report.internal.SectionElementDef;
import inetsoft.report.internal.SectionPaintable;
import inetsoft.report.internal.SectionXElement;
import inetsoft.report.internal.SeparatorElementDef;
import inetsoft.report.internal.SpaceElementDef;
import inetsoft.report.internal.TOCElementDef;
import inetsoft.report.internal.TabElementDef;
import inetsoft.report.internal.TableAttr;
import inetsoft.report.internal.TableElementDef;
import inetsoft.report.internal.TablePaintable;
import inetsoft.report.internal.TableXElement;
import inetsoft.report.internal.TextBased;
import inetsoft.report.internal.TextBoxElementDef;
import inetsoft.report.internal.TextElementDef;
import inetsoft.report.lens.DefaultHeadingLens;
import inetsoft.report.lens.DefaultTableLens;
import inetsoft.report.lens.DefaultTextLens;
import inetsoft.report.locale.Catalog;
import inetsoft.report.painter.BulletPainter;
import java.awt.AWTEventMulticaster;
import java.awt.Adjustable;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Insets;
import java.awt.ItemSelectable;
import java.awt.MediaTracker;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.BitSet;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.tree.TreeModel;

public class DesignPane extends PreviewPane implements ItemSelectable, DesignView {
  public static final int HEADER = 256;
  
  public static final int BODY = 0;
  
  public static final int FOOTER = 512;
  
  ItemListener itemListener;
  
  public ActionListener undoListener;
  
  public ActionListener copyListener;
  
  public ActionListener cutListener;
  
  public ActionListener pasteListener;
  
  public ActionListener editListener;
  
  public ActionListener propertyListener;
  
  public ActionListener scriptListener;
  
  public KeyListener keyListener;
  
  Object[][] align_opts;
  
  String[][] format_strs;
  
  String[][] presenter_strs;
  
  JMenuItem copyM;
  
  JMenuItem cutM;
  
  JMenuItem pasteM;
  
  JMenuItem editM;
  
  JMenuItem propertyM;
  
  JMenuItem scriptM;
  
  int pageCnt;
  
  Vector pages;
  
  BaseElement current;
  
  Vector currlist;
  
  DesignPage currPage;
  
  Rectangle cursor;
  
  boolean showGrid;
  
  boolean editArea;
  
  boolean drawingArea;
  
  Resizer resizer;
  
  Resizer rubberBand;
  
  TableResizer tableResizer;
  
  SectionResizer sectionResizer;
  
  BaseElement pending;
  
  int ordering;
  
  int target;
  
  boolean changed;
  
  UndoMgr undoMgr;
  
  boolean textmode;
  
  boolean editing;
  
  TextEditor textEditor;
  
  CellEditor cellEditor;
  
  boolean reprintLater;
  
  Hashtable idmap;
  
  Hashtable ordermap;
  
  Hashtable hdrordermap;
  
  Hashtable ftrordermap;
  
  Hashtable propmap;
  
  Vector resizeBoxes;
  
  ResizeBox resizeType;
  
  Insets insets;
  
  Image anchorImg;
  
  ReportTreeModel treemodel;
  
  public DesignPane() {
    this.itemListener = null;
    this.undoListener = new ActionListener(this) {
        private final DesignPane this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.undo(); }
      };
    this.copyListener = new ActionListener(this) {
        private final DesignPane this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.copy(); }
      };
    this.cutListener = new ActionListener(this) {
        private final DesignPane this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.cut(); }
      };
    this.pasteListener = new ActionListener(this) {
        private final DesignPane this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.paste(); }
      };
    this.editListener = new ActionListener(this) {
        private final DesignPane this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.currPage.showEditor(this.this$0.getCurrent(), false, null, null); }
      };
    this.propertyListener = new ActionListener(this) {
        private final DesignPane this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.showProperty(); }
      };
    this.scriptListener = new ActionListener(this) {
        private final DesignPane this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.editScript(); }
      };
    this.keyListener = new KeyAdapter(this) {
        private final DesignPane this$0;
        
        public void keyTyped(KeyEvent param1KeyEvent) {
          if (this.this$0.editArea || this.this$0.editing)
            return; 
          BaseElement baseElement = this.this$0.currPage.getPrevElement(this.this$0.current);
          boolean bool = (baseElement == null || !(baseElement instanceof TextElement));
          boolean bool1 = false;
          if (bool && this.this$0.current instanceof TextElement) {
            bool = false;
            baseElement = this.this$0.current;
            bool1 = true;
          } 
          if (param1KeyEvent.getKeyChar() == ' ' && (!this.this$0.textmode || bool)) {
            SpaceElementDef spaceElementDef = null;
            if (this.this$0.current != null && !(this.this$0.current instanceof SpaceElement) && baseElement instanceof SpaceElement)
              spaceElementDef = (SpaceElement)baseElement; 
            if (spaceElementDef != null) {
              spaceElementDef.setSpace(spaceElementDef.getSpace() + 6);
            } else {
              spaceElementDef = new SpaceElementDef(this.this$0.sheet, 6);
              this.this$0.makeIDUnique(spaceElementDef);
              this.this$0.setContext(spaceElementDef, this.this$0.currPage.getPrevElement(this.this$0.current));
              this.this$0.insert(spaceElementDef, false);
            } 
            this.this$0.reprint(spaceElementDef);
            return;
          } 
          if (this.this$0.textmode && this.this$0.currPage != null) {
            boolean bool2 = false;
            switch (Character.getType(param1KeyEvent.getKeyChar())) {
              case 1:
              case 2:
              case 3:
              case 5:
              case 9:
              case 10:
              case 11:
              case 20:
              case 21:
              case 22:
              case 23:
              case 24:
              case 25:
              case 26:
              case 27:
              case 28:
                bool2 = true;
                break;
              default:
                bool2 = (param1KeyEvent.getKeyChar() == ' ') ? 1 : 0;
                break;
            } 
            if (bool2) {
              TextElementDef textElementDef;
              String str = "";
              Point point = null;
              if (bool) {
                textElementDef = new TextElementDef(this.this$0.sheet, new DefaultTextLens(param1KeyEvent.getKeyChar() + ""));
                this.this$0.makeIDUnique(textElementDef);
                this.this$0.setContext(textElementDef, this.this$0.currPage.getPrevElement(this.this$0.current));
              } else {
                TextElement textElement = (TextElement)textElementDef;
                str = textElement.getText();
                if (bool1) {
                  textElement.setText(param1KeyEvent.getKeyChar() + textElement.getText());
                  point = new Point(1, -1);
                } else {
                  textElement.setText(textElement.getText() + param1KeyEvent.getKeyChar());
                } 
              } 
              this.this$0.currPage.showEditor(textElementDef, bool, point, str);
            } 
          } 
        }
        
        public void keyPressed(KeyEvent param1KeyEvent) {
          if (this.this$0.editing)
            return; 
          if (param1KeyEvent.getKeyCode() == 127) {
            if (this.this$0.textmode && this.this$0.current instanceof TextElement) {
              TextElement textElement = (TextElement)this.this$0.current;
              String str = textElement.getText();
              if (str.length() > 0)
                textElement.setText(str.substring(1)); 
              this.this$0.currPage.showEditor(textElement, false, new Point(0, 0), str);
            } else {
              this.this$0.cut();
            } 
          } else if (param1KeyEvent.getKeyCode() == 8) {
            if (!this.this$0.editArea) {
              ReportElement reportElement = this.this$0.currPage.getPrevElement(this.this$0.current);
              if (this.this$0.textmode && reportElement instanceof TextElement) {
                TextElement textElement = (TextElement)reportElement;
                String str = textElement.getText();
                if (str.length() > 0)
                  textElement.setText(str.substring(0, str.length() - 1)); 
                this.this$0.currPage.showEditor(textElement, false, null, str);
              } else if (reportElement != null) {
                DesignPane.clipboard = (BaseElement)reportElement;
                this.this$0.remove(reportElement, true);
              } 
            } 
          } else if (param1KeyEvent.getKeyCode() == 10 && !this.this$0.editArea) {
            NewlineElementDef newlineElementDef = new NewlineElementDef(this.this$0.sheet, 1, param1KeyEvent.isControlDown());
            this.this$0.makeIDUnique(newlineElementDef);
            this.this$0.insert(newlineElementDef, false);
            this.this$0.reprint(newlineElementDef);
          } else if (param1KeyEvent.getKeyCode() == 74 && param1KeyEvent.isControlDown()) {
            NewlineElementDef newlineElementDef = new NewlineElementDef(this.this$0.sheet, 1, true);
            this.this$0.makeIDUnique(newlineElementDef);
            this.this$0.insert(newlineElementDef, false);
            this.this$0.reprint(newlineElementDef);
          } else if (param1KeyEvent.getKeyCode() == 9 && !this.this$0.editArea) {
            TabElementDef tabElementDef = new TabElementDef(this.this$0.sheet, 0);
            this.this$0.makeIDUnique(tabElementDef);
            this.this$0.setContext(tabElementDef, this.this$0.currPage.getPrevElement(this.this$0.current));
            this.this$0.insert(tabElementDef, false);
            param1KeyEvent.consume();
            this.this$0.reprint(tabElementDef);
          } else if ((param1KeyEvent.getKeyCode() == 38 || param1KeyEvent.getKeyCode() == 37 || param1KeyEvent.getKeyCode() == 40 || param1KeyEvent.getKeyCode() == 39) && !this.this$0.editArea) {
            if (this.this$0.resizeType.bounds != null && this.this$0.resizeBoxes.size() > 0 && this.this$0.resizeType.element.getParent() instanceof FixedContainer) {
              byte b1 = 0, b2 = 0;
              if (param1KeyEvent.getKeyCode() == 38) {
                b2 = -1;
              } else if (param1KeyEvent.getKeyCode() == 37) {
                b1 = -1;
              } else if (param1KeyEvent.getKeyCode() == 40) {
                b2 = 1;
              } else if (param1KeyEvent.getKeyCode() == 39) {
                b1 = 1;
              } 
              boolean bool = Resizer.isSnapToGrid();
              Resizer.setSnapToGrid(false);
              this.this$0.resizeType.type = 256;
              this.this$0.currPage.startResize();
              this.this$0.resizer.move(b1, b2);
              if (this.this$0.currPage.processResize())
                this.this$0.reprint(null); 
              Resizer.setSnapToGrid(bool);
            } else if (param1KeyEvent.getKeyCode() == 37) {
              ReportElement reportElement = this.this$0.currPage.getPrevElement(this.this$0.current);
              if (reportElement != null)
                this.this$0.setCurrent(reportElement, (DesignPane.DesignPage)param1KeyEvent.getSource()); 
            } else if (param1KeyEvent.getKeyCode() == 39 && this.this$0.current != null) {
              ReportElement reportElement = this.this$0.currPage.getNextElement(this.this$0.current);
              if (reportElement != null)
                this.this$0.setCurrent(reportElement, (DesignPane.DesignPage)param1KeyEvent.getSource()); 
            } 
            param1KeyEvent.consume();
          } 
        }
      };
    this.align_opts = new Object[][] { { Catalog.getString("Top Left"), new Integer(9) }, { Catalog.getString("Top Center"), new Integer(10) }, { Catalog.getString("Top Right"), new Integer(12) }, { Catalog.getString("Middle Left"), new Integer(17) }, { Catalog.getString("Middle Center"), new Integer(18) }, { Catalog.getString("Middle Right"), new Integer(20) }, { Catalog.getString("Bottom Left"), new Integer(33) }, { Catalog.getString("Bottom Center"), new Integer(34) }, { Catalog.getString("Bottom Right"), new Integer(36) } };
    this.format_strs = new String[][] { { Catalog.getString("(none)"), null }, { Catalog.getString("Date Format") + "...", "DateFormat" }, { Catalog.getString("Decimal Format") + "...", "DecimalFormat" }, { Catalog.getString("Currency Format"), "CurrencyFormat" }, { Catalog.getString("Percent Format"), "PercentFormat" } };
    this.presenter_strs = new String[][] { { Catalog.getString("(none)"), null }, { "BarPresenter", "BarPresenter" }, { "Bar2Presenter", "Bar2Presenter" }, { "BooleanPresenter", "BooleanPresenter" }, { "ButtonPresenter", "ButtonPresenter" }, { "IconCounterPresenter", "IconCounterPresenter" }, { "ShadowPresenter", "ShadowPresenter" } };
    this.pageCnt = 0;
    this.pages = new Vector();
    this.current = null;
    this.currlist = new Vector();
    this.currPage = null;
    this.cursor = null;
    this.showGrid = false;
    this.editArea = false;
    this.drawingArea = false;
    this.ordering = -1;
    this.target = 0;
    this.changed = false;
    this.textmode = false;
    this.editing = false;
    this.textEditor = new TextEditor(this);
    this.cellEditor = new CellEditor(this);
    this.reprintLater = false;
    this.idmap = new Hashtable();
    this.ordermap = new Hashtable();
    this.hdrordermap = new Hashtable();
    this.ftrordermap = new Hashtable();
    this.propmap = new Hashtable();
    this.resizeBoxes = new Vector();
    this.resizeType = new ResizeBox();
    this.insets = new Insets(0, 0, 0, 0);
    this.sectionInsertM = new SectionInsertMenu(this);
    this.showGrid = DesignEnv.getProperty("show.grid", "false").equals("true");
    setShowRuler(DesignEnv.getProperty("show.ruler", "true").equals("true"));
    this.editM = new JMenuItem(Catalog.getString("Edit"));
    this.editM.addActionListener(this.editListener);
    this.copyM = new JMenuItem(Catalog.getString("Copy"));
    this.copyM.addActionListener(this.copyListener);
    this.cutM = new JMenuItem(Catalog.getString("Cut"));
    this.cutM.addActionListener(this.cutListener);
    this.pasteM = new JMenuItem(Catalog.getString("Paste"));
    this.pasteM.addActionListener(this.pasteListener);
    this.propertyM = new JMenuItem(Catalog.getString("Properties") + "...");
    this.propertyM.addActionListener(this.propertyListener);
    this.scriptM = new JMenuItem(Catalog.getString("Script") + "...");
    this.scriptM.addActionListener(this.scriptListener);
    getVAdjustable().setUnitIncrement(18);
    getHAdjustable().setUnitIncrement(18);
    MediaTracker mediaTracker = new MediaTracker(this);
    try {
      this.anchorImg = Common.getImage(DesignPane.class, "images/anchor.gif");
      mediaTracker.addImage(this.anchorImg, 0);
      mediaTracker.waitForAll();
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
    setEnabled();
  }
  
  public void setShowGrid(boolean paramBoolean) {
    this.showGrid = paramBoolean;
    repaint(100L);
  }
  
  public boolean isShowGrid() { return this.showGrid; }
  
  public void setCurrentFont(Font paramFont) {
    if (this.currlist.size() == 0) {
      this.sheet.setCurrentFont(paramFont);
      return;
    } 
    for (byte b = 0; b < this.currlist.size(); b++) {
      ReportElement reportElement1 = (ReportElement)this.currlist.elementAt(b);
      ReportElement reportElement2 = null;
      try {
        reportElement2 = (ReportElement)reportElement1.clone();
      } catch (Exception exception) {
        exception.printStackTrace();
      } 
      reportElement1.setFont(paramFont);
      if (reportElement2 != null)
        getUndoMgr().undoProperty(reportElement2, reportElement1, getTarget()); 
    } 
    fireEvent();
    reprint(this.current);
  }
  
  public void setCurrentAlignment(int paramInt) {
    if (this.currlist.size() == 0) {
      this.sheet.setCurrentAlignment(paramInt);
      return;
    } 
    for (byte b = 0; b < this.currlist.size(); b++) {
      ReportElement reportElement1 = (ReportElement)this.currlist.elementAt(b);
      ReportElement reportElement2 = null;
      try {
        reportElement2 = (ReportElement)reportElement1.clone();
      } catch (Exception exception) {
        exception.printStackTrace();
      } 
      reportElement1.setAlignment(paramInt);
      if (reportElement2 != null)
        getUndoMgr().undoProperty(reportElement2, reportElement1, getTarget()); 
    } 
    fireEvent();
    reprint(this.current);
  }
  
  public void setCurrentJustify(boolean paramBoolean) {
    if (this.currlist.size() == 0) {
      this.sheet.setCurrentJustify(paramBoolean);
      return;
    } 
    for (byte b = 0; b < this.currlist.size(); b++) {
      ReportElement reportElement1 = (ReportElement)this.currlist.elementAt(b);
      ReportElement reportElement2 = null;
      try {
        reportElement2 = (ReportElement)reportElement1.clone();
      } catch (Exception exception) {
        exception.printStackTrace();
      } 
      if (reportElement1 instanceof TextBased)
        ((TextBased)this.current).setJustify(paramBoolean); 
      if (reportElement2 != null)
        getUndoMgr().undoProperty(reportElement2, reportElement1, getTarget()); 
    } 
    fireEvent();
    reprint(this.current);
  }
  
  public void align(int paramInt) {
    if (this.resizeBoxes.size() < 2)
      return; 
    FixedContainer fixedContainer = null;
    int i = Integer.MAX_VALUE, j = Integer.MAX_VALUE;
    int k = 0, m = 0;
    for (byte b1 = 0; b1 < this.resizeBoxes.size(); b1++) {
      ResizeBox resizeBox = (ResizeBox)this.resizeBoxes.elementAt(b1);
      fixedContainer = (FixedContainer)resizeBox.element.getParent();
      Rectangle rectangle = fixedContainer.getBounds(fixedContainer.getElementIndex(resizeBox.element));
      i = Math.min(i, rectangle.y);
      j = Math.min(j, rectangle.x);
      k = Math.max(k, rectangle.y + rectangle.height);
      m = Math.max(m, rectangle.x + rectangle.width);
    } 
    int n = this.undoMgr.getCount();
    for (byte b2 = 0; b2 < this.resizeBoxes.size(); b2++) {
      ResizeBox resizeBox = (ResizeBox)this.resizeBoxes.elementAt(b2);
      fixedContainer = (FixedContainer)resizeBox.element.getParent();
      Rectangle rectangle = fixedContainer.getBounds(fixedContainer.getElementIndex(resizeBox.element));
      if ((paramInt & true) != 0) {
        rectangle.x = j;
      } else if ((paramInt & 0x2) != 0) {
        rectangle.x = j + (m - j) / 2 - rectangle.width / 2;
      } else if ((paramInt & 0x4) != 0) {
        rectangle.x = m - rectangle.width;
      } 
      if ((paramInt & 0x8) != 0) {
        rectangle.y = i;
      } else if ((paramInt & 0x10) != 0) {
        rectangle.y = i + (k - i) / 2 - rectangle.height / 2;
      } else if ((paramInt & 0x20) != 0) {
        rectangle.y = k - rectangle.height;
      } 
      int i1 = fixedContainer.getElementIndex(resizeBox.element);
      this.undoMgr.undoBounds(resizeBox.element, fixedContainer.getBounds(i1));
      fixedContainer.setBounds(i1, rectangle);
    } 
    this.undoMgr.undoN(this.undoMgr.getCount() - n);
    reprint(null);
  }
  
  public void distribute(int paramInt) {
    if (this.resizeBoxes.size() < 3)
      return; 
    FixedContainer fixedContainer = null;
    int i = 0, j = 0;
    int k = Integer.MAX_VALUE, m = Integer.MAX_VALUE;
    int n = 0, i1 = 0;
    ResizeBox[] arrayOfResizeBox1 = new ResizeBox[this.resizeBoxes.size()];
    ResizeBox[] arrayOfResizeBox2 = new ResizeBox[this.resizeBoxes.size()];
    boolean bool1 = ((paramInt & 0x107) != 0) ? 1 : 0;
    boolean bool2 = ((paramInt & 0x238) != 0) ? 1 : 0;
    int i2 = this.undoMgr.getCount();
    for (byte b = 0; b < this.resizeBoxes.size(); b++) {
      ResizeBox resizeBox = (ResizeBox)this.resizeBoxes.elementAt(b);
      fixedContainer = (FixedContainer)resizeBox.element.getParent();
      Rectangle rectangle = fixedContainer.getBounds(fixedContainer.getElementIndex(resizeBox.element));
      if ((paramInt & 0x100) != 0)
        i += rectangle.width; 
      if ((paramInt & 0x200) != 0)
        j += rectangle.height; 
      k = Math.min(k, rectangle.y);
      m = Math.min(m, rectangle.x);
      n = Math.max(n, rectangle.y + rectangle.height);
      i1 = Math.max(i1, rectangle.x + rectangle.width);
      if (bool2) {
        arrayOfResizeBox2[b] = resizeBox;
        for (byte b1 = b; b1 > 0 && (arrayOfResizeBox2[b1]).bounds.y < (arrayOfResizeBox2[b1 - 1]).bounds.y; b1--) {
          ResizeBox resizeBox1 = arrayOfResizeBox2[b1];
          arrayOfResizeBox2[b1] = arrayOfResizeBox2[b1 - 1];
          arrayOfResizeBox2[b1 - 1] = resizeBox1;
        } 
      } 
      if (bool1) {
        arrayOfResizeBox1[b] = resizeBox;
        for (byte b1 = b; b1 > 0 && (arrayOfResizeBox1[b1]).bounds.x < (arrayOfResizeBox1[b1 - 1]).bounds.x; b1--) {
          ResizeBox resizeBox1 = arrayOfResizeBox1[b1];
          arrayOfResizeBox1[b1] = arrayOfResizeBox1[b1 - 1];
          arrayOfResizeBox1[b1 - 1] = resizeBox1;
        } 
      } 
    } 
    if (bool1) {
      float f1 = 0.0F, f2 = 0.0F, f3 = 0.0F;
      if ((paramInt & true) != 0) {
        f3 = m;
        f2 = ((i1 - m - (arrayOfResizeBox1[arrayOfResizeBox1.length - 1]).bounds.width) / (arrayOfResizeBox1.length - 1));
      } else if ((paramInt & 0x2) != 0) {
        f3 = (m + (arrayOfResizeBox1[0]).bounds.width / 2);
        f2 = ((i1 - m - (arrayOfResizeBox1[0]).bounds.width / 2 - (arrayOfResizeBox1[arrayOfResizeBox1.length - 1]).bounds.width / 2) / (arrayOfResizeBox1.length - 1));
        f1 = 0.5F;
      } else if ((paramInt & 0x4) != 0) {
        f3 = (m + (arrayOfResizeBox1[0]).bounds.width);
        f2 = ((i1 - m - (arrayOfResizeBox1[0]).bounds.width) / (arrayOfResizeBox1.length - 1));
        f1 = 1.0F;
      } else if ((paramInt & 0x100) != 0) {
        f3 = m;
        f2 = ((i1 - m - i) / (arrayOfResizeBox1.length - 1));
      } 
      for (byte b1 = 0; b1 < arrayOfResizeBox1.length; b1++) {
        int i3 = fixedContainer.getElementIndex((arrayOfResizeBox1[b1]).element);
        Rectangle rectangle = fixedContainer.getBounds(i3);
        if ((paramInt & 0x100) != 0) {
          rectangle.x = (int)f3;
          f3 += rectangle.width + f2;
        } else {
          rectangle.x = (int)(f3 - rectangle.width * f1);
          f3 += f2;
        } 
        this.undoMgr.undoBounds((arrayOfResizeBox1[b1]).element, fixedContainer.getBounds(i3));
        fixedContainer.setBounds(i3, rectangle);
      } 
    } 
    if (bool2) {
      float f1 = 0.0F, f2 = 0.0F, f3 = 0.0F;
      if ((paramInt & 0x8) != 0) {
        f3 = k;
        f2 = ((n - k - (arrayOfResizeBox2[arrayOfResizeBox2.length - 1]).bounds.height) / (arrayOfResizeBox2.length - 1));
      } else if ((paramInt & 0x10) != 0) {
        f3 = (k + (arrayOfResizeBox2[0]).bounds.height / 2);
        f2 = ((n - k - (arrayOfResizeBox2[0]).bounds.height / 2 - (arrayOfResizeBox2[arrayOfResizeBox2.length - 1]).bounds.height / 2) / (arrayOfResizeBox2.length - 1));
        f1 = 0.5F;
      } else if ((paramInt & 0x20) != 0) {
        f3 = (k + (arrayOfResizeBox2[0]).bounds.height);
        f2 = ((n - k - (arrayOfResizeBox2[0]).bounds.height) / (arrayOfResizeBox2.length - 1));
        f1 = 1.0F;
      } else if ((paramInt & 0x200) != 0) {
        f3 = k;
        f2 = ((n - k - j) / (arrayOfResizeBox2.length - 1));
      } 
      for (byte b1 = 0; b1 < arrayOfResizeBox2.length; b1++) {
        int i3 = fixedContainer.getElementIndex((arrayOfResizeBox2[b1]).element);
        Rectangle rectangle = fixedContainer.getBounds(i3);
        if ((paramInt & 0x200) != 0) {
          rectangle.y = (int)f3;
          f3 += rectangle.height + f2;
        } else {
          rectangle.y = (int)(f3 - rectangle.height * f1);
          f3 += f2;
        } 
        this.undoMgr.undoBounds((arrayOfResizeBox2[b1]).element, fixedContainer.getBounds(i3));
        fixedContainer.setBounds(i3, rectangle);
      } 
    } 
    this.undoMgr.undoN(this.undoMgr.getCount() - i2);
    reprint(null);
  }
  
  public void changeSizes(int paramInt1, int paramInt2) {
    if (this.resizeBoxes.size() < 2 || (paramInt1 == 0 && paramInt2 == 0))
      return; 
    FixedContainer fixedContainer = null;
    int i = Integer.MAX_VALUE, j = 0;
    int k = Integer.MAX_VALUE, m = 0;
    int n = this.undoMgr.getCount();
    if (paramInt1 == Integer.MAX_VALUE || paramInt1 == Integer.MIN_VALUE || paramInt2 == Integer.MAX_VALUE || paramInt2 == Integer.MIN_VALUE)
      for (byte b1 = 0; b1 < this.resizeBoxes.size(); b1++) {
        ResizeBox resizeBox = (ResizeBox)this.resizeBoxes.elementAt(b1);
        fixedContainer = (FixedContainer)resizeBox.element.getParent();
        Rectangle rectangle = fixedContainer.getBounds(fixedContainer.getElementIndex(resizeBox.element));
        i = Math.min(i, rectangle.height);
        j = Math.max(j, rectangle.height);
        k = Math.min(k, rectangle.width);
        m = Math.max(m, rectangle.width);
      }  
    for (byte b = 0; b < this.resizeBoxes.size(); b++) {
      ResizeBox resizeBox = (ResizeBox)this.resizeBoxes.elementAt(b);
      fixedContainer = (FixedContainer)resizeBox.element.getParent();
      int i1 = fixedContainer.getElementIndex(resizeBox.element);
      Rectangle rectangle = fixedContainer.getBounds(i1);
      if (paramInt1 == Integer.MAX_VALUE) {
        rectangle.width = m;
      } else if (paramInt1 == Integer.MIN_VALUE) {
        rectangle.width = k;
      } else if (paramInt1 > 0) {
        rectangle.width = paramInt1;
      } 
      if (paramInt2 == Integer.MAX_VALUE) {
        rectangle.height = j;
      } else if (paramInt2 == Integer.MIN_VALUE) {
        rectangle.height = i;
      } else if (paramInt2 > 0) {
        rectangle.height = paramInt2;
      } 
      this.undoMgr.undoBounds(resizeBox.element, fixedContainer.getBounds(i1));
      fixedContainer.setBounds(i1, rectangle);
    } 
    this.undoMgr.undoN(this.undoMgr.getCount() - n);
    reprint(null);
  }
  
  public void setTextMode(boolean paramBoolean) {
    if (this.textmode != paramBoolean) {
      this.textmode = paramBoolean;
      this.textEditor.resetTextMode(paramBoolean);
      this.cellEditor.resetTextMode(paramBoolean);
      if (!paramBoolean)
        this.currPage.requestFocus(); 
      setAllCursor(paramBoolean ? new Cursor(2) : new Cursor(0));
      fireEvent();
      repaint(100L);
    } 
  }
  
  public boolean isTextMode() { return this.textmode; }
  
  public int getUndoCount() { return (this.undoMgr == null) ? 0 : this.undoMgr.getCount(); }
  
  public void setAllCursor(Cursor paramCursor) {
    setCursor(paramCursor);
    for (byte b = 0; b < this.pages.size(); b++)
      ((Component)this.pages.elementAt(b)).setCursor(paramCursor); 
  }
  
  public void undo() {
    if (this.undoMgr != null) {
      this.undoMgr.undo();
      reprint(null);
      fireEvent();
    } 
  }
  
  public JPopupMenu getPopupMenu(Point paramPoint) { return (this.currPage != null) ? this.currPage.getPopupMenu(paramPoint) : null; }
  
  public void setEditArea(boolean paramBoolean) {
    if (this.editArea != paramBoolean) {
      this.editArea = paramBoolean;
      if (!this.editArea) {
        if (this.ordering >= 0)
          orderAreas(false); 
        for (byte b = 0; b < this.pages.size(); b++)
          ((DesignPage)this.pages.elementAt(b)).setCurrentFrame(-1); 
        if (this.resizeType.element == null && this.resizeBoxes.size() > 0) {
          this.resizeType.copy((ResizeBox)this.resizeBoxes.elementAt(0));
          this.resizer = null;
        } 
      } 
      if (!this.editArea && this.pending != null) {
        reprint(this.pending);
        this.pending = null;
      } else {
        repaint(100L);
      } 
    } 
  }
  
  public void setEditArea(String paramString) {
    this.editArea = true;
    for (byte b = 0; b < this.pages.size(); b++)
      ((DesignPage)this.pages.elementAt(b)).setEditArea(paramString); 
    repaint(100L);
  }
  
  public boolean isEditArea() { return this.editArea; }
  
  public void setTarget(int paramInt) {
    if (this.target != paramInt) {
      Rectangle rectangle;
      this.currPage.requestFocus();
      this.target = paramInt;
      setCurrent(null, null);
      this.treemodel.targetChanged();
      DesignPage designPage = (DesignPage)this.pages.elementAt(0);
      switch (paramInt) {
        case 256:
          ((JScrollPane)this.scrollpane).getViewport().setViewPosition(new Point(0, 0));
          setCurrentPage(designPage);
          break;
        case 512:
          rectangle = new Rectangle(designPage.getPrintBounds());
          ((JScrollPane)this.scrollpane).getViewport().setViewPosition(new Point(0, (designPage.getLocation()).y + rectangle.height + rectangle.y - (getViewportSize()).height + 5));
          setCurrentPage(designPage);
          break;
      } 
      this.currPage.positionCursor();
      this.currPage.requestFocus();
      repaint(100L);
    } 
  }
  
  public int getTarget() { return this.target; }
  
  protected PreviewPage createPage(double paramDouble1, double paramDouble2, int paramInt) {
    PreviewPage previewPage = null;
    if (this.pageCnt < this.pages.size()) {
      previewPage = (PreviewPage)this.pages.elementAt(this.pageCnt);
      Size size = previewPage.getPageSizeInch();
      if (size.width == paramDouble1 && size.height == paramDouble2) {
        previewPage.getStylePage().reset();
      } else {
        previewPage = null;
      } 
    } 
    if (previewPage == null) {
      previewPage = new DesignPage(this, this.pageCnt, paramDouble1, paramDouble2, paramInt);
      previewPage.setCursor(getCursor());
      previewPage.addKeyListener(this.keyListener);
      if (this.pageCnt < this.pages.size()) {
        this.pages.setElementAt(previewPage, this.pageCnt);
      } else {
        this.pages.addElement(previewPage);
      } 
    } 
    this.pageCnt++;
    return previewPage;
  }
  
  public void print(StyleSheet paramStyleSheet) {
    paramStyleSheet.setDesignTime(true);
    Margin margin1 = StyleSheet.getPrinterMargin();
    StyleSheet.setPrinterMargin(new Margin());
    if (this.sheet != paramStyleSheet) {
      setCurrent(null, null);
      this.currPage = null;
      this.changed = false;
      this.undoMgr = new UndoMgr(this, paramStyleSheet);
    } else {
      this.changed = true;
    } 
    this.sheet = (XStyleSheet)paramStyleSheet;
    this.pageCnt = 0;
    Margin margin2 = paramStyleSheet.getMargin();
    this.insets.left = Math.max(0, (int)((1.0D - margin2.left) * 72.0D));
    super.print(paramStyleSheet);
    populateOrderMap(this.ordermap, paramStyleSheet.getAllElements());
    populateOrderMap(this.hdrordermap, paramStyleSheet.getAllHeaderElements());
    populateOrderMap(this.ftrordermap, paramStyleSheet.getAllFooterElements());
    for (byte b = 0; b < this.pages.size(); b++)
      ((DesignPage)this.pages.elementAt(b)).refresh(); 
    if (this.currPage == null && this.pages.size() > 0) {
      setCurrentPage((DesignPage)this.pages.elementAt(0));
      fireEvent();
    } 
    this.currPage.positionCursor();
    this.currPage.requestFocus();
    if (this.treemodel != null)
      this.treemodel.treeChanged(); 
    StyleSheet.setPrinterMargin(margin1);
    buildIDMap(paramStyleSheet);
  }
  
  public boolean isChanged() {
    this.textEditor.stop();
    this.cellEditor.stop();
    return this.changed;
  }
  
  public void setChanged(boolean paramBoolean) { this.changed = paramBoolean; }
  
  public void insertTable(int paramInt1, int paramInt2, boolean paramBoolean) {
    TableXElement tableXElement = new TableXElement(this.sheet, new DefaultTableLens(paramInt1, paramInt2));
    tableXElement.setPadding(new Insets(0, 1, 0, 1));
    makeIDUnique(tableXElement);
    insert(tableXElement, paramBoolean);
  }
  
  public void insertText(boolean paramBoolean) {
    TextElementDef textElementDef = new TextElementDef(this.sheet, new DefaultTextLens(""));
    makeIDUnique(textElementDef);
    if (paramBoolean || (this.currPage != null && this.currPage.isCurrentNonFlowFrame())) {
      insert(textElementDef, paramBoolean);
    } else {
      setContext(textElementDef, this.currPage.getPrevElement(this.current));
      this.currPage.showEditor(textElementDef, true, null, null);
    } 
  }
  
  public void insertTextBox(boolean paramBoolean) {
    TextBoxElementDef textBoxElementDef = new TextBoxElementDef(this.sheet, new DefaultTextLens(""));
    textBoxElementDef.setPadding(new Insets(0, 1, 0, 1));
    textBoxElementDef.setMargin(new Insets(0, 0, 0, 0));
    textBoxElementDef.setTextAlignment(65);
    makeIDUnique(textBoxElementDef);
    if (paramBoolean || (this.currPage != null && this.currPage.isCurrentNonFlowFrame())) {
      insert(textBoxElementDef, paramBoolean);
    } else {
      setContext(textBoxElementDef, this.currPage.getPrevElement(this.current));
      this.currPage.showEditor(textBoxElementDef, true, null, null);
    } 
  }
  
  public void insertSection(boolean paramBoolean) {
    SectionXElement sectionXElement = new SectionXElement(this.sheet);
    makeIDUnique(sectionXElement);
    insert(sectionXElement, paramBoolean);
  }
  
  public void insertChart(int paramInt, boolean paramBoolean) {
    ChartXElement chartXElement = new ChartXElement(this.sheet, paramInt);
    makeIDUnique(chartXElement);
    insert(chartXElement, paramBoolean);
  }
  
  public void insertImage(boolean paramBoolean) {
    ImageXElement imageXElement = new ImageXElement(this.sheet);
    makeIDUnique(imageXElement);
    if (paramBoolean || (this.currPage != null && this.currPage.isCurrentNonFlowFrame())) {
      insert(imageXElement, paramBoolean);
    } else {
      ImageProperty imageProperty = new ImageProperty(this);
      setContext(imageXElement, this.currPage.getPrevElement(this.current));
      imageProperty.show(imageXElement, Catalog.getString("Image"), new ActionListener(this, imageXElement) {
            private final ImageXElement val$image;
            
            private final DesignPane this$0;
            
            public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.insert(this.val$image, false); }
          });
    } 
  }
  
  public void insertPainter(boolean paramBoolean) {
    PainterElementDef painterElementDef = new PainterElementDef(this.sheet, new EmptyPainter());
    makeIDUnique(painterElementDef);
    if (paramBoolean || (this.currPage != null && this.currPage.isCurrentNonFlowFrame())) {
      insert(painterElementDef, paramBoolean);
    } else {
      PainterProperty painterProperty = new PainterProperty(this);
      setContext(painterElementDef, this.currPage.getPrevElement(this.current));
      painterProperty.show(painterElementDef, Catalog.getString("Layout"), new ActionListener(this, painterElementDef) {
            private final PainterElementDef val$painter;
            
            private final DesignPane this$0;
            
            public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.insert(this.val$painter, false); }
          });
    } 
  }
  
  public void insertContainer(boolean paramBoolean) {
    CompositeElementDef compositeElementDef = new CompositeElementDef(this.sheet, new EmptyContainer());
    makeIDUnique(compositeElementDef);
    insert(compositeElementDef, paramBoolean);
  }
  
  public void insertTOC(boolean paramBoolean) {
    TOCElementDef tOCElementDef = new TOCElementDef(this.sheet, TOC.DEFAULT);
    makeIDUnique(tOCElementDef);
    if (paramBoolean || (this.currPage != null && this.currPage.isCurrentNonFlowFrame())) {
      insert(tOCElementDef, paramBoolean);
    } else {
      TOCProperty tOCProperty = new TOCProperty(this);
      tOCProperty.show(tOCElementDef, Catalog.getString("Table Of Contents"), new ActionListener(this, tOCElementDef) {
            private final TOCElement val$toc;
            
            private final DesignPane this$0;
            
            public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.insert(this.val$toc, false); }
          });
    } 
  }
  
  public void insertHeading(int paramInt, boolean paramBoolean) {
    DefaultHeadingLens defaultHeadingLens = new DefaultHeadingLens("", paramInt);
    HeadingElementDef headingElementDef = new HeadingElementDef(this.sheet, defaultHeadingLens);
    makeIDUnique(headingElementDef);
    if (paramBoolean || (this.currPage != null && this.currPage.isCurrentNonFlowFrame())) {
      insert(headingElementDef, paramBoolean);
    } else {
      setContext(headingElementDef, this.currPage.getPrevElement(this.current));
      this.currPage.showEditor(headingElementDef, true, null, null);
    } 
  }
  
  public void insertSeparator(boolean paramBoolean) {
    String str = DesignEnv.getProperty("separator.style");
    char c = (str == null) ? 4097 : Integer.parseInt(str);
    SeparatorElementDef separatorElementDef = new SeparatorElementDef(this.sheet, c);
    makeIDUnique(separatorElementDef);
    insert(separatorElementDef, paramBoolean);
  }
  
  public void insertBullet(boolean paramBoolean) {
    BulletPainter bulletPainter = new BulletPainter();
    Size size = bulletPainter.getSize();
    PainterElementDef painterElementDef = new PainterElementDef(this.sheet, bulletPainter, size.width, size.height);
    painterElementDef.setID(this.sheet.getNextID("Bullet"));
    makeIDUnique(painterElementDef);
    if (this.currPage != null && this.currPage.isCurrentNonFlowFrame()) {
      insert(painterElementDef, paramBoolean);
    } else {
      TextElementDef textElementDef = new TextElementDef(this.sheet, new DefaultTextLens(""));
      makeIDUnique(textElementDef);
      textElementDef.setHindent((int)((bulletPainter.getSize()).width * 72.0F));
      insert(painterElementDef, false);
      this.cursor.x = (int)(this.cursor.x + size.width * 72.0F);
      this.currPage.showEditor(textElementDef, true, null, null);
    } 
  }
  
  public void insertTab(boolean paramBoolean) {
    TabElementDef tabElementDef = new TabElementDef(this.sheet, 0);
    makeIDUnique(tabElementDef);
    insert(tabElementDef, paramBoolean);
  }
  
  public void insertLinefeed(boolean paramBoolean) {
    NewlineElementDef newlineElementDef = new NewlineElementDef(this.sheet, 1, false);
    makeIDUnique(newlineElementDef);
    insert(newlineElementDef, paramBoolean);
  }
  
  public void insertBreak(boolean paramBoolean) {
    NewlineElementDef newlineElementDef = new NewlineElementDef(this.sheet, 1, true);
    makeIDUnique(newlineElementDef);
    insert(newlineElementDef, paramBoolean);
  }
  
  public void insertSpace(boolean paramBoolean) {
    SpaceElementDef spaceElementDef = new SpaceElementDef(this.sheet, 6);
    makeIDUnique(spaceElementDef);
    insert(spaceElementDef, paramBoolean);
  }
  
  public void insertPageBreak(boolean paramBoolean) {
    PageBreakElementDef pageBreakElementDef = new PageBreakElementDef(this.sheet);
    makeIDUnique(pageBreakElementDef);
    insert(pageBreakElementDef, paramBoolean);
  }
  
  public void insertCondPageBreak(boolean paramBoolean) {
    CondPageBreakElementDef condPageBreakElementDef = new CondPageBreakElementDef(this.sheet, 0.0D);
    makeIDUnique(condPageBreakElementDef);
    insert(condPageBreakElementDef, paramBoolean);
  }
  
  public void insertAreaBreak(boolean paramBoolean) {
    AreaBreakElementDef areaBreakElementDef = new AreaBreakElementDef(this.sheet);
    makeIDUnique(areaBreakElementDef);
    insert(areaBreakElementDef, paramBoolean);
  }
  
  public void insertArea(boolean paramBoolean) {
    if (!paramBoolean) {
      this.currPage.setCursor(new Cursor(0));
      this.drawingArea = false;
    } else if (this.editArea && this.currPage != null) {
      this.currPage.setCursor(new Cursor(1));
      this.drawingArea = true;
      synchronized (this) {
        while (this.drawingArea == true) {
          try {
            wait();
          } catch (Exception exception) {}
        } 
      } 
    } 
  }
  
  public void copy() {
    if (!this.editArea && this.currlist.size() > 0)
      try {
        clipboard = (Vector)this.currlist.clone();
        fireEvent();
      } catch (Exception exception) {
        JOptionPane.showMessageDialog(null, exception.toString(), Catalog.getString("Error"), 0);
      }  
  }
  
  public void cut() {
    if (!this.editArea && this.currlist.size() > 0) {
      copy();
      int i = this.undoMgr.getCount();
      while (this.currlist.size() > 0)
        remove((ReportElement)this.currlist.elementAt(0), (this.currlist.size() == 1)); 
      this.undoMgr.undoN(this.undoMgr.getCount() - i);
      setCurrent(null, null);
    } else if (this.editArea && this.currPage != null && this.currPage.getCurrentFrame() >= 0) {
      this.currPage.removeArea(this.currPage.getCurrentFrame());
    } 
  }
  
  public void paste() {
    if (!this.editArea && clipboard != null) {
      Vector vector = null;
      if (clipboard instanceof Vector) {
        vector = (Vector)clipboard;
      } else {
        vector = new Vector();
        vector.addElement(clipboard);
      } 
      for (byte b = 0; b < vector.size(); b++) {
        BaseElement baseElement = (BaseElement)vector.elementAt(b);
        String str = this.sheet.getNextID(baseElement.getType());
        while (this.idmap.get(str) != null)
          str = this.sheet.getNextID(baseElement.getType()); 
        try {
          baseElement = (BaseElement)baseElement.clone();
          baseElement.setParent(null);
          baseElement.setID(str);
          baseElement.setStyleSheet(this.sheet);
          if (baseElement instanceof SectionElement) {
            Enumeration enumeration = ((SectionElementDef)baseElement).getElements();
            while (enumeration.hasMoreElements())
              makeIDUnique((ReportElement)enumeration.nextElement()); 
          } 
          insert(baseElement, false);
        } catch (CloneNotSupportedException cloneNotSupportedException) {}
      } 
    } 
  }
  
  public boolean isPasteable() { return (clipboard != null); }
  
  public void orderAreas(boolean paramBoolean) {
    if (!paramBoolean) {
      this.currPage.setCursor(new Cursor(0));
      this.ordering = -1;
    } else if (this.editArea && this.currPage != null) {
      this.currPage.setCursor(new Cursor(12));
      this.ordering = 0;
      synchronized (this) {
        while (this.ordering >= 0) {
          try {
            wait();
          } catch (Exception exception) {}
        } 
      } 
      this.pending = (BaseElement)this.currPage.getElement(0);
    } 
  }
  
  public void setColumns(int paramInt) {
    if (this.currPage != null && this.currPage.getElementCount() > 0) {
      this.sheet.setPageColumns(paramInt, this.currPage.getElement(0));
    } else {
      this.sheet.setPageColumns(paramInt);
    } 
    reprint((this.currPage != null && this.currPage.getElementCount() > 0) ? this.currPage.getElement(0) : null);
  }
  
  void setCurrentPage(DesignPage paramDesignPage) {
    if (this.currPage != paramDesignPage) {
      this.currPage = paramDesignPage;
      setFocusPage(this.pages.indexOf(this.currPage));
      this.currPage.positionCursor();
      this.currPage.requestFocus();
      this.currPage.repaint(100L);
    } 
  }
  
  public void setCurrent(ReportElement paramReportElement, DesignPage paramDesignPage) {
    if (this.current != paramReportElement && paramReportElement != null) {
      if (paramDesignPage == null)
        for (byte b = 0; b < getPageCount(); b++) {
          DesignPage designPage = (DesignPage)getPage(b);
          if (designPage.contains(paramReportElement)) {
            paramDesignPage = designPage;
            break;
          } 
        }  
      if (paramDesignPage != null)
        paramDesignPage.setCurrent(paramReportElement); 
    } 
    if (paramReportElement == null && this.currPage != null)
      this.currPage.setCurrent(null); 
    fireEvent();
  }
  
  public ReportElement getCurrent() { return this.current; }
  
  public ReportElement[] getSelectedElements() {
    ReportElement[] arrayOfReportElement = new ReportElement[this.currlist.size()];
    this.currlist.copyInto(arrayOfReportElement);
    return arrayOfReportElement;
  }
  
  public void setSelectedElements(ReportElement[] paramArrayOfReportElement) {
    clearSelectedElements();
    for (byte b = 0; b < paramArrayOfReportElement.length; b++) {
      for (byte b1 = 0; b1 < getPageCount(); b1++) {
        if (((DesignPage)getPage(b1)).contains(paramArrayOfReportElement[b])) {
          ((DesignPage)getPage(b1)).addSelectedElement(paramArrayOfReportElement[b], null);
          break;
        } 
      } 
    } 
    setCurrent((paramArrayOfReportElement.length > 0) ? paramArrayOfReportElement[0] : null, null);
    repaint(100L);
  }
  
  public boolean isAlignable() {
    byte b1 = 0;
    for (byte b2 = 0; b2 < this.resizeBoxes.size(); b2++) {
      BaseElement baseElement = ((ResizeBox)this.resizeBoxes.elementAt(b2)).element;
      if (!(baseElement.getParent() instanceof FixedContainer))
        return false; 
      b1++;
    } 
    return (b1 > 1);
  }
  
  public boolean isDistributable() {
    byte b1 = 0;
    FixedContainer fixedContainer = null;
    for (byte b2 = 0; b2 < this.resizeBoxes.size(); b2++) {
      BaseElement baseElement = ((ResizeBox)this.resizeBoxes.elementAt(b2)).element;
      if (!(baseElement.getParent() instanceof FixedContainer))
        return false; 
      if (fixedContainer == null) {
        fixedContainer = (FixedContainer)baseElement.getParent();
      } else if (fixedContainer != baseElement.getParent()) {
        return false;
      } 
      b1++;
    } 
    return (b1 > 2);
  }
  
  private void clearSelectedElements() {
    this.resizeType.type = -1;
    this.resizeType.element = null;
    this.resizeBoxes.removeAllElements();
    this.currlist.removeAllElements();
    fireEvent();
  }
  
  public DesignPage getCurrentPage() { return this.currPage; }
  
  public void showProperty() {
    if (this.editArea && this.currPage != null) {
      this.currPage.showPageAreaProperty();
      return;
    } 
    ReportElement reportElement = (this.current.getParent() instanceof ReportElement) ? (ReportElement)this.current.getParent() : this.current;
    PropertyDialog propertyDialog = getPropertyDialog(reportElement);
    try {
      BaseElement baseElement = (BaseElement)reportElement.clone();
      if (propertyDialog != null)
        propertyDialog.show(reportElement, null, new ActionListener(this, baseElement) {
              private final BaseElement val$oe;
              
              private final DesignPane this$0;
              
              public void actionPerformed(ActionEvent param1ActionEvent) {
                this.this$0.reprint(this.this$0.current);
                if (this.val$oe != null)
                  if (this.val$oe.getParent() instanceof FixedContainer) {
                    this.this$0.undoMgr.undoProperty(this.val$oe, this.this$0.current, (FixedContainer)this.val$oe.getParent());
                  } else {
                    this.this$0.undoMgr.undoProperty(this.val$oe, this.this$0.current, this.this$0.target);
                  }  
                this.this$0.fireEvent();
              }
            }); 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
  
  public void editScript() {
    if (this.editArea)
      return; 
    ReportElement reportElement = (this.current != null && this.current.getParent() instanceof ReportElement) ? (ReportElement)this.current.getParent() : this.current;
    ScriptDialog scriptDialog = new ScriptDialog((reportElement != null));
    try {
      BaseElement baseElement = (reportElement == null) ? null : (BaseElement)reportElement.clone();
      String str = this.sheet.getOnPageBreak();
      if (scriptDialog != null)
        scriptDialog.show(reportElement, this.sheet, new ActionListener(this, baseElement, str) {
              private final BaseElement val$oe;
              
              private final String val$pbscript;
              
              private final DesignPane this$0;
              
              public void actionPerformed(ActionEvent param1ActionEvent) {
                this.this$0.reprint(this.this$0.current);
                if (this.val$oe != null) {
                  if (this.val$oe.getParent() instanceof FixedContainer) {
                    this.this$0.undoMgr.undoProperty(this.val$oe, this.this$0.current, (FixedContainer)this.val$oe.getParent());
                  } else {
                    this.this$0.undoMgr.undoProperty(this.val$oe, this.this$0.current, this.this$0.target);
                  } 
                } else {
                  this.this$0.undoMgr.undoOnPageBreak(this.val$pbscript);
                } 
                this.this$0.fireEvent();
              }
            }); 
    } catch (Exception exception) {
      exception.printStackTrace();
    } 
  }
  
  protected PropertyDialog getPropertyDialog(ReportElement paramReportElement) {
    PropertyDialog propertyDialog = (PropertyDialog)this.propmap.get(paramReportElement.getClass());
    if (propertyDialog == null)
      if (paramReportElement instanceof inetsoft.report.HeadingElement) {
        this.propmap.put(paramReportElement.getClass(), propertyDialog = new HeadingProperty(this));
      } else if (paramReportElement instanceof TextElement) {
        this.propmap.put(paramReportElement.getClass(), propertyDialog = new TextProperty(this));
      } else if (paramReportElement instanceof inetsoft.report.internal.FormXElement) {
        this.propmap.put(paramReportElement.getClass(), propertyDialog = new FormProperty(this));
      } else if (paramReportElement instanceof inetsoft.report.TableElement) {
        this.propmap.put(paramReportElement.getClass(), propertyDialog = new TableProperty(this));
      } else if (paramReportElement instanceof inetsoft.report.TextBoxElement) {
        this.propmap.put(paramReportElement.getClass(), propertyDialog = new TextBoxProperty(this));
      } else if (paramReportElement instanceof ChartXElement) {
        this.propmap.put(paramReportElement.getClass(), propertyDialog = new ChartProperty(this));
      } else if (paramReportElement instanceof ImageXElement) {
        this.propmap.put(paramReportElement.getClass(), propertyDialog = new ImageProperty(this));
      } else if (paramReportElement instanceof PainterElement) {
        this.propmap.put(paramReportElement.getClass(), propertyDialog = new PainterProperty(this));
      } else if (paramReportElement instanceof inetsoft.report.TabElement) {
        this.propmap.put(paramReportElement.getClass(), propertyDialog = new TabProperty(this));
      } else if (paramReportElement instanceof inetsoft.report.SeparatorElement) {
        this.propmap.put(paramReportElement.getClass(), propertyDialog = new SeparatorProperty(this));
      } else if (paramReportElement instanceof inetsoft.report.NewlineElement) {
        this.propmap.put(paramReportElement.getClass(), propertyDialog = new NewlineProperty(this));
      } else if (paramReportElement instanceof SpaceElement) {
        this.propmap.put(paramReportElement.getClass(), propertyDialog = new SpaceProperty(this));
      } else if (paramReportElement instanceof inetsoft.report.CondPageBreakElement) {
        this.propmap.put(paramReportElement.getClass(), propertyDialog = new CondPageBreakProperty(this));
      } else if (paramReportElement instanceof TOCElement) {
        this.propmap.put(paramReportElement.getClass(), propertyDialog = new TOCProperty(this));
      } else if (paramReportElement instanceof SectionElement) {
        this.propmap.put(paramReportElement.getClass(), propertyDialog = new SectionProperty(this));
      }  
    return propertyDialog;
  }
  
  public void insert(ReportElement paramReportElement, boolean paramBoolean) {
    if (paramBoolean)
      paramReportElement.setFont(getCurrent().getFont()); 
    if (paramBoolean || (this.currPage != null && this.currPage.isCurrentNonFlowFrame())) {
      this.currPage.setDrawElement(paramReportElement, paramBoolean ? (SectionElement)getCurrent() : null);
      return;
    } 
    switch (this.target) {
      case 256:
        if (this.current == null) {
          this.sheet.addHeaderElement(paramReportElement);
          break;
        } 
        this.sheet.insertHeaderElement(this.sheet.getHeaderElementIndex(this.current), paramReportElement);
        break;
      case 0:
        if (this.current == null) {
          this.sheet.addElement(paramReportElement);
          break;
        } 
        this.sheet.insertElement(this.sheet.getElementIndex(this.current), paramReportElement);
        break;
      case 512:
        if (this.current == null) {
          this.sheet.addFooterElement(paramReportElement);
          break;
        } 
        this.sheet.insertFooterElement(this.sheet.getFooterElementIndex(this.current), paramReportElement);
        break;
    } 
    reprint(this.current);
    this.undoMgr.undoInsert(paramReportElement, this.target);
    fireEvent();
  }
  
  void remove(ReportElement paramReportElement, boolean paramBoolean) {
    int i = -1;
    FixedContainer fixedContainer = null;
    if (this.currlist.contains(paramReportElement)) {
      this.currlist.removeElement(paramReportElement);
      for (byte b = 0; b < this.resizeBoxes.size(); b++) {
        if (((ResizeBox)this.resizeBoxes.elementAt(b)).element.equals(paramReportElement))
          this.resizeBoxes.removeElementAt(b--); 
      } 
    } 
    if (((BaseElement)paramReportElement).getParent() instanceof FixedContainer) {
      fixedContainer = (FixedContainer)((BaseElement)paramReportElement).getParent();
      i = fixedContainer.getElementIndex(paramReportElement);
      if (i >= 0) {
        this.undoMgr.undoRemove(paramReportElement, fixedContainer);
        fixedContainer.removeElement(i);
      } 
    } 
    int j = this.target;
    if (i < 0) {
      i = this.sheet.getElementIndex(paramReportElement);
      if (i >= 0) {
        this.sheet.removeElement(i);
        j = 0;
      } else {
        i = this.sheet.getHeaderElementIndex(paramReportElement);
        if (i >= 0) {
          this.sheet.removeHeaderElement(i);
          j = 256;
        } else {
          i = this.sheet.getFooterElementIndex(paramReportElement);
          if (i >= 0) {
            this.sheet.removeFooterElement(i);
            j = 512;
          } 
        } 
      } 
    } 
    if (paramBoolean)
      reprint(this.current); 
    if (i >= 0) {
      if (fixedContainer == null)
        this.undoMgr.undoRemove(i, paramReportElement, j); 
      fireEvent();
    } 
  }
  
  protected Container createScrollPane() { return new JScrollPane(); }
  
  protected void addToScrollPane(Component paramComponent) { ((JScrollPane)this.scrollpane).setViewportView(paramComponent); }
  
  protected Container getViewport() { return ((JScrollPane)this.scrollpane).getViewport(); }
  
  public Dimension getViewportSize() { return ((JScrollPane)this.scrollpane).getViewport().getSize(); }
  
  public Adjustable getVAdjustable() { return ((JScrollPane)this.scrollpane).getVerticalScrollBar(); }
  
  public Adjustable getHAdjustable() { return ((JScrollPane)this.scrollpane).getHorizontalScrollBar(); }
  
  public void showPageNumber(int paramInt) {}
  
  public void showPageSize(Size paramSize) {}
  
  public void showStatus(String paramString) {}
  
  public void reprint(ReportElement paramReportElement) {
    isChanged();
    print(this.sheet);
    repaint(100L);
  }
  
  public int getPageCount() { return this.pageCnt; }
  
  public ReportElement getElement(String paramString) { return (ReportElement)this.idmap.get(paramString); }
  
  private void setContext(ReportElement paramReportElement1, ReportElement paramReportElement2) {
    if (paramReportElement2 != null) {
      int i = paramReportElement1.getAlignment() & 0x7;
      int j = paramReportElement2.getAlignment() & 0x7;
      i = Math.max(i, j) | paramReportElement2.getAlignment() & 0x38;
      paramReportElement1.setAlignment(i);
    } 
  }
  
  private void makeIDUnique(ReportElement paramReportElement) {
    while (this.idmap.get(paramReportElement.getID()) != null)
      paramReportElement.setID(this.sheet.getNextID(paramReportElement.getType())); 
    this.idmap.put(paramReportElement.getID(), paramReportElement);
  }
  
  private void buildIDMap(StyleSheet paramStyleSheet) {
    int[] arrayOfInt = { 0, 256, 257, 258, 259, 512, 513, 514, 515 };
    Vector vector = new Vector();
    for (byte b1 = 0; b1 < arrayOfInt.length; b1++)
      vector.addElement(paramStyleSheet.getElements(arrayOfInt[b1])); 
    Enumeration enumeration = paramStyleSheet.getElementHeaders().elements();
    while (enumeration.hasMoreElements())
      vector.addElement((Vector)enumeration.nextElement()); 
    this.idmap.clear();
    for (byte b2 = 0; b2 < vector.size(); b2++) {
      Vector vector1 = (Vector)vector.elementAt(b2);
      for (byte b = 0; b < vector1.size(); b++) {
        ReportElement reportElement = (ReportElement)vector1.elementAt(b);
        this.idmap.put(reportElement.getID(), reportElement);
        if (reportElement instanceof PageLayoutElement) {
          PageArea[] arrayOfPageArea = ((PageLayoutElement)reportElement).getPageAreas();
          for (byte b3 = 0; b3 < arrayOfPageArea.length; b3++) {
            FixedContainer fixedContainer = arrayOfPageArea[b3].getElements();
            if (fixedContainer != null)
              for (byte b4 = 0; b4 < fixedContainer.getElementCount(); b4++) {
                ReportElement reportElement1 = fixedContainer.getElement(b4);
                this.idmap.put(reportElement1.getID(), reportElement1);
              }  
          } 
        } else if (reportElement instanceof SectionElement) {
          buildElementMap(((SectionElement)reportElement).getSection());
        } 
      } 
    } 
  }
  
  private void buildElementMap(SectionLens paramSectionLens) {
    buildElementMap(paramSectionLens.getSectionHeader());
    buildElementMap(paramSectionLens.getSectionFooter());
    Object object = paramSectionLens.getSectionContent();
    if (object instanceof SectionBand) {
      buildElementMap((SectionBand)object);
    } else {
      buildElementMap((SectionLens)object);
    } 
  }
  
  private void buildElementMap(SectionBand paramSectionBand) {
    for (byte b = 0; b < paramSectionBand.getElementCount(); b++) {
      ReportElement reportElement = paramSectionBand.getElement(b);
      this.idmap.put(reportElement.getID(), reportElement);
    } 
  }
  
  public TreeModel getTreeModel(JTree paramJTree) { return (this.treemodel == null) ? (this.treemodel = new ReportTreeModel(this, paramJTree)) : this.treemodel; }
  
  public Object[] getSelectedObjects() { new Object[1][0] = this.current;
    return (this.current == null) ? null : new Object[1]; }
  
  public void addItemListener(ItemListener paramItemListener) { this.itemListener = AWTEventMulticaster.add(this.itemListener, paramItemListener); }
  
  public void removeItemListener(ItemListener paramItemListener) { this.itemListener = AWTEventMulticaster.remove(this.itemListener, paramItemListener); }
  
  public void fireEvent() {
    if (this.itemListener != null)
      this.itemListener.itemStateChanged(new ItemEvent(this, 701, this.current, 1)); 
    setEnabled();
  }
  
  public void rename(String paramString1, String paramString2) {
    for (byte b = 0; b < this.pages.size(); b++)
      ((DesignPage)this.pages.elementAt(b)).rename(paramString1, paramString2); 
    Object object = this.idmap.get(paramString1);
    if (object != null) {
      this.idmap.remove(paramString1);
      this.idmap.put(paramString2, object);
    } 
    this.treemodel.treeChanged();
  }
  
  public class DesignPage extends PreviewPage implements MouseListener, MouseMotionListener {
    Hashtable paintablemap;
    
    Hashtable elemmap;
    
    Hashtable elempaintable;
    
    Hashtable bandmap;
    
    Vector elemlist;
    
    Vector headerlist;
    
    Vector footerlist;
    
    int pgnum;
    
    String editID;
    
    PageArea[] pageareas;
    
    Rectangle[] pageframes;
    
    BitSet nonflow;
    
    int currFrame;
    
    BaseElement drawingElement;
    
    Rectangle drawingBox;
    
    SectionElement drawingSection;
    
    Rectangle printBox;
    
    int resolution;
    
    Vector fixedBoxes;
    
    Rectangle areaBox;
    
    Rectangle elemBox;
    
    Rectangle rubberBox;
    
    Margin pmargin;
    
    private final DesignPane this$0;
    
    public DesignPage(DesignPane this$0, int param1Int, double param1Double1, double param1Double2) { this(this$0, param1Int, param1Double1, param1Double2, 72); }
    
    public DesignPage(DesignPane this$0, int param1Int1, double param1Double1, double param1Double2, int param1Int2) {
      super(param1Double1, param1Double2, param1Int2);
      this.this$0 = this$0;
      addMouseListener(this);
      addMouseMotionListener(this);
      this.paintablemap = new Hashtable();
      this.elemmap = new Hashtable();
      this.elempaintable = new Hashtable();
      this.bandmap = new Hashtable();
      this.elemlist = new Vector();
      this.headerlist = new Vector();
      this.footerlist = new Vector();
      this.nonflow = new BitSet();
      this.currFrame = -1;
      this.drawingElement = null;
      this.drawingBox = null;
      this.drawingSection = null;
      this.fixedBoxes = new Vector();
      this.areaBox = null;
      this.elemBox = null;
      this.rubberBox = null;
      this.pmargin = StyleSheet.getPrinterMargin();
      this.pgnum = param1Int1;
      addFocusListener(new DesignPane$6(this));
    }
    
    public int getPageNumber() { return this.pgnum; }
    
    public Rectangle getElementBounds(ReportElement param1ReportElement) {
      Vector vector = (Vector)this.elemmap.get(param1ReportElement);
      if (vector != null)
        return (Rectangle)vector.elementAt(0); 
      return null;
    }
    
    public void refresh() {
      Dimension dimension = getStylePage().getPageDimension();
      this.resolution = getStylePage().getPageResolution();
      Margin margin = this.this$0.sheet.getMargin();
      this.printBox = new Rectangle((int)((margin.left - this.pmargin.left) * this.resolution), (int)((margin.top - this.pmargin.top) * this.resolution), dimension.width - (int)((margin.left + margin.right) * this.resolution), dimension.height - (int)((margin.top + margin.bottom) * this.resolution));
      this.paintablemap.clear();
      this.elemmap.clear();
      this.elempaintable.clear();
      this.bandmap.clear();
      this.elemlist.removeAllElements();
      this.headerlist.removeAllElements();
      this.footerlist.removeAllElements();
      this.fixedBoxes.removeAllElements();
      StylePage stylePage = getStylePage();
      this.pageareas = stylePage.getPageAreas();
      createFrames();
      for (byte b1 = 0; b1 < stylePage.getPaintableCount(); b1++) {
        Paintable paintable = stylePage.getPaintable(b1);
        BaseElement baseElement = (BaseElement)paintable.getElement();
        if (baseElement != null) {
          boolean bool = baseElement.getParent() instanceof FixedContainer;
          if (baseElement.getParent() instanceof ReportElement)
            baseElement = (BaseElement)baseElement.getParent(); 
          Rectangle rectangle = bool ? getFixedElementBounds(paintable) : paintable.getBounds();
          this.paintablemap.put(rectangle, paintable);
          Vector vector = (Vector)this.elempaintable.get(baseElement);
          if (vector == null) {
            vector = new Vector();
            this.elempaintable.put(baseElement, vector);
          } 
          vector.addElement(paintable);
          if (paintable instanceof SectionPaintable) {
            SectionPaintable sectionPaintable = (SectionPaintable)paintable;
            for (byte b = 0; b < sectionPaintable.getSectionBandCount(); b++)
              this.bandmap.put(sectionPaintable.getSectionBand(b), sectionPaintable); 
          } 
          if (bool && (baseElement instanceof TextElement || baseElement instanceof inetsoft.report.TextBoxElement)) {
            FixedContainer fixedContainer = (FixedContainer)baseElement.getParent();
            int i = fixedContainer.getElementIndex(baseElement);
            Rectangle rectangle1 = fixedContainer.getBounds(i);
            Rectangle rectangle2 = ((BasePaintable)paintable).getFrame();
            this.fixedBoxes.addElement(new Rectangle(rectangle1.x + rectangle2.x, rectangle1.y + rectangle2.y, rectangle1.width, rectangle1.height));
          } 
          vector = (Vector)this.elemmap.get(baseElement);
          if (vector == null) {
            vector = new Vector();
            this.elemmap.put(baseElement, vector);
            addToListSorted(baseElement, null);
          } 
          if (bool)
            vector.removeAllElements(); 
          vector.addElement(rectangle);
        } 
      } 
      this.this$0.resizeType.bounds = null;
      for (byte b2 = 0; b2 < this.this$0.resizeBoxes.size(); b2++) {
        ResizeBox resizeBox = (ResizeBox)this.this$0.resizeBoxes.elementAt(b2);
        if (resizeBox.page == this) {
          Vector vector = (Vector)this.elempaintable.get(resizeBox.element);
          if (vector != null) {
            resizeBox.paintable = (Paintable)vector.elementAt(0);
            resizeBox.bounds = getElementBounds(resizeBox.element);
          } 
          if (resizeBox.paintable == null || resizeBox.bounds == null) {
            this.this$0.resizeBoxes.removeElementAt(b2--);
          } else {
            resizeBox.bounds = new Rectangle(resizeBox.bounds);
          } 
          if (this.this$0.resizeType.element == resizeBox.element)
            this.this$0.resizeType.bounds = resizeBox.bounds; 
        } 
      } 
      if (this.this$0.current != null) {
        this.this$0.tableResizer = null;
        if (this.this$0.current instanceof inetsoft.report.TableElement) {
          Vector vector = (Vector)this.elempaintable.get(this.this$0.current);
          if (vector != null)
            this.this$0.tableResizer = new TableResizer(vector); 
        } 
        this.this$0.sectionResizer = null;
        if (this.this$0.current instanceof SectionElement) {
          Vector vector = (Vector)this.elempaintable.get(this.this$0.current);
          if (vector != null)
            this.this$0.sectionResizer = new SectionResizer((SectionPaintable)vector.elementAt(0)); 
        } 
      } 
    }
    
    public Insets getInsets() { return this.this$0.insets; }
    
    public void setEditArea(String param1String) {
      this.editID = param1String;
      if (this.editID == null) {
        this.pageareas = getStylePage().getPageAreas();
        createFrames();
      } else {
        this.pageareas = (PageArea[])this.this$0.sheet.getElementAreas().get(param1String);
        createFrames();
      } 
    }
    
    public int getElementCount() { return this.elemlist.size(); }
    
    public ReportElement getElement(int param1Int) { return (param1Int < this.elemlist.size()) ? (ReportElement)this.elemlist.elementAt(param1Int) : null; }
    
    public ReportElement getPrevElement(ReportElement param1ReportElement) {
      if (param1ReportElement == null)
        switch (this.this$0.target) {
          case 256:
            return getPrevElement(this.headerlist, this.headerlist.size() - 1);
          case 512:
            return getPrevElement(this.footerlist, this.footerlist.size() - 1);
          case 0:
            return getPrevElement(this.elemlist, this.elemlist.size() - 1);
        }  
      int i = this.elemlist.indexOf(param1ReportElement);
      if (i >= 0)
        return getPrevElement(this.elemlist, i - 1); 
      i = this.headerlist.indexOf(param1ReportElement);
      if (i >= 0)
        return getPrevElement(this.headerlist, i - 1); 
      i = this.footerlist.indexOf(param1ReportElement);
      if (i >= 0)
        return getPrevElement(this.footerlist, i - 1); 
      return null;
    }
    
    private ReportElement getPrevElement(Vector param1Vector, int param1Int) {
      for (; param1Int >= 0; param1Int--) {
        BaseElement baseElement = (BaseElement)param1Vector.elementAt(param1Int);
        if (!(baseElement.getParent() instanceof FixedContainer))
          return baseElement; 
      } 
      return null;
    }
    
    public ReportElement getNextElement(ReportElement param1ReportElement) {
      int i = this.elemlist.indexOf(param1ReportElement);
      if (i >= 0 && i < this.elemlist.size() - 1)
        return getNextElement(this.elemlist, i + 1); 
      i = this.headerlist.indexOf(param1ReportElement);
      if (i >= 0 && i < this.headerlist.size() - 1)
        return getNextElement(this.headerlist, i + 1); 
      i = this.footerlist.indexOf(param1ReportElement);
      if (i >= 0 && i < this.footerlist.size() - 1)
        return getNextElement(this.footerlist, i + 1); 
      return null;
    }
    
    private ReportElement getNextElement(Vector param1Vector, int param1Int) {
      for (; param1Int < param1Vector.size(); param1Int++) {
        BaseElement baseElement = (BaseElement)param1Vector.elementAt(param1Int);
        if (!(baseElement.getParent() instanceof FixedContainer))
          return baseElement; 
      } 
      return null;
    }
    
    public boolean contains(ReportElement param1ReportElement) { return (this.elemmap.get(param1ReportElement) != null); }
    
    public void setAreas(PageArea[] param1ArrayOfPageArea) {
      this.pageareas = param1ArrayOfPageArea;
      createFrames();
      if (this.pageareas != null) {
        if (this.editID != null) {
          this.this$0.sheet.setPageAreas(this.pageareas, this.editID);
        } else if (getElementCount() == 0 || !(getElement(0) instanceof PageLayoutElement)) {
          PageLayoutElementDef pageLayoutElementDef = new PageLayoutElementDef(this.this$0.sheet, this.pageareas);
          this.this$0.makeIDUnique(pageLayoutElementDef);
          if (getElementCount() == 0) {
            this.this$0.sheet.addElement(pageLayoutElementDef);
          } else {
            this.this$0.sheet.insertElement(this.this$0.sheet.getElementIndex(getElement(0)), pageLayoutElementDef);
          } 
          this.elemlist.insertElementAt(pageLayoutElementDef, 0);
        } else {
          ((PageLayoutElement)getElement(0)).setPageAreas(this.pageareas);
        } 
      } else if (getElementCount() > 0 && getElement(0) instanceof PageLayoutElement) {
        this.this$0.sheet.removeElement(this.this$0.sheet.getElementIndex(getElement(0)));
        this.elemlist.removeElementAt(0);
      } 
      this.this$0.pending = (BaseElement)getElement(0);
    }
    
    public void removeArea(int param1Int) {
      PageArea[] arrayOfPageArea = new PageArea[this.pageareas.length - 1];
      for (byte b = 0; b < arrayOfPageArea.length; b++) {
        if (b < param1Int) {
          arrayOfPageArea[b] = this.pageareas[b];
        } else if (b >= param1Int) {
          arrayOfPageArea[b] = this.pageareas[b + true];
        } 
      } 
      this.currFrame = -1;
      setAreas(arrayOfPageArea);
      this.this$0.setEnabled();
      repaint(100L);
    }
    
    public void insertArea(PageArea param1PageArea) {
      PageArea[] arrayOfPageArea = new PageArea[this.pageframes.length + 1];
      this.currFrame = (this.currFrame >= 0) ? this.currFrame : this.pageframes.length;
      for (byte b = 0; b < arrayOfPageArea.length; b++) {
        if (b < this.currFrame) {
          arrayOfPageArea[b] = this.pageareas[b];
        } else if (b == this.currFrame) {
          arrayOfPageArea[b] = param1PageArea;
        } else if (b > this.currFrame) {
          arrayOfPageArea[b] = this.pageareas[b - true];
        } 
      } 
      setAreas(arrayOfPageArea);
      this.this$0.setEnabled();
      repaint(100L);
    }
    
    public int getCurrentFrame() { return this.currFrame; }
    
    public void setCurrentFrame(int param1Int) { this.currFrame = param1Int; }
    
    private void createFrames() {
      if (this.pageareas != null) {
        this.pageframes = new Rectangle[this.pageareas.length];
        for (byte b = 0; b < this.pageframes.length; b++) {
          this.pageframes[b] = this.pageareas[b].getBounds(this.printBox, this.resolution);
          if (this.pageareas[b].isFlow()) {
            this.nonflow.clear(b);
          } else {
            this.nonflow.set(b);
          } 
        } 
      } else {
        this.pageframes = new Rectangle[0];
      } 
      this.currFrame = Math.min(this.currFrame, this.pageframes.length - 1);
    }
    
    public void setCurrent(ReportElement param1ReportElement) {
      if (this.this$0.current != param1ReportElement) {
        this.this$0.current = (BaseElement)param1ReportElement;
        boolean bool = (this.this$0.current != null && this.this$0.current.getParent() instanceof FixedContainer && !(this.this$0.current.getParent() instanceof SectionBand)) ? 1 : 0;
        if (!bool) {
          this.currFrame = -1;
        } else {
          this.currFrame = getNonFlowFrame(this.this$0.current);
        } 
        if (this.this$0.current instanceof inetsoft.report.TableElement) {
          this.this$0.tableResizer = new TableResizer((Vector)this.elempaintable.get(this.this$0.current));
        } else {
          this.this$0.tableResizer = null;
        } 
        if (this.this$0.current instanceof SectionElement) {
          Vector vector = (Vector)this.elempaintable.get(this.this$0.current);
          this.this$0.sectionResizer = new SectionResizer((SectionPaintable)vector.elementAt(0));
        } else {
          this.this$0.sectionResizer = null;
        } 
        positionCursor();
        repaint(100L);
      } 
    }
    
    public void showPageAreaProperty() {
      if (this.currFrame >= 0) {
        AreaProperty areaProperty = new AreaProperty(this.this$0);
        areaProperty.setElement(this.pageareas[this.currFrame]);
        areaProperty.setActionListener(new DesignPane$7(this));
        areaProperty.pack();
        areaProperty.setVisible(true);
      } 
    }
    
    public void paintBG(Graphics param1Graphics) {
      super.paintBG(param1Graphics);
      if (!this.this$0.editing && !this.this$0.editArea) {
        param1Graphics.setColor(new Color(200, 200, 200));
        for (byte b = 0; b < this.fixedBoxes.size(); b++) {
          Rectangle rectangle1 = new Rectangle((Rectangle)this.fixedBoxes.elementAt(b));
          rectangle1.x--;
          rectangle1.width++;
          param1Graphics.drawRect(rectangle1.x, rectangle1.y, rectangle1.width, rectangle1.height);
        } 
      } 
      param1Graphics.setColor(Color.lightGray);
      Rectangle rectangle = getPrintBounds();
      param1Graphics.drawRect(rectangle.x, rectangle.y, rectangle.width, rectangle.height);
      param1Graphics.setColor(Color.black);
      if (this.this$0.showGrid) {
        Dimension dimension = getSize();
        Rectangle rectangle1 = getBounds();
        Size size = getPageSizeInch();
        param1Graphics.setColor(new Color(0, 0, 128));
        double d1 = (rectangle1.height / size.height);
        for (double d2 = 0.0D; d2 < size.height; d2 += 0.125D) {
          int i = (int)(d2 * d1);
          for (double d = 0.0D; d < size.width; d += 0.125D) {
            int j = (int)(d * d1);
            param1Graphics.drawLine(j, i, j, i);
          } 
        } 
      } 
    }
    
    public void paint(Graphics param1Graphics) {
      Rectangle rectangle = param1Graphics.getClipBounds();
      if (this.pageframes == null)
        return; 
      if (rectangle != null && this.this$0.editing) {
        Rectangle rectangle1 = this.this$0.cellEditor.hasFocus() ? this.this$0.cellEditor.getBounds() : this.this$0.textEditor.getBounds();
        if (rectangle1.contains(rectangle.x, rectangle.y) && rectangle1.contains(rectangle.x + rectangle.width - 1, rectangle.y + rectangle.height - 1)) {
          paintContainer(param1Graphics);
          return;
        } 
      } 
      Dimension dimension = getPageSize();
      if (this.this$0.editArea) {
        if (PreviewPage.bSize.width != dimension.width || PreviewPage.bSize.height != dimension.height) {
          PreviewPage.buffer = createImage(dimension.width + this.this$0.insets.left + this.this$0.insets.right, dimension.height + this.this$0.insets.top + this.this$0.insets.bottom);
          PreviewPage.bSize = dimension;
        } 
        Graphics graphics = PreviewPage.buffer.getGraphics();
        graphics.translate(this.this$0.insets.left, this.this$0.insets.top);
        paintBG(graphics);
        graphics.setColor(Color.black);
        graphics.drawRect(-this.this$0.insets.left, -this.this$0.insets.top, dimension.width + this.this$0.insets.left + this.this$0.insets.right - 1, dimension.height + this.this$0.insets.top + this.this$0.insets.bottom - 1);
        Enumeration enumeration = this.paintablemap.keys();
        while (enumeration.hasMoreElements()) {
          Rectangle rectangle1 = (Rectangle)enumeration.nextElement();
          graphics.setColor(new Color(200, 200, 200));
          graphics.drawRect(rectangle1.x, rectangle1.y, rectangle1.width, rectangle1.height);
        } 
        graphics.setColor(Color.black);
        if (this.this$0.drawingArea && this.areaBox != null) {
          Common.drawRect(graphics, this.areaBox.x, this.areaBox.y, this.areaBox.width, this.areaBox.height, 4113);
          paintResizeBox(graphics, this.areaBox);
        } else if (this.currFrame >= 0 && this.currFrame < this.pageframes.length) {
          paintResizeBox(graphics, this.pageframes[this.currFrame]);
        } 
        graphics.dispose();
        param1Graphics.drawImage(PreviewPage.buffer, 0, 0, this);
        param1Graphics.translate(this.this$0.insets.left, this.this$0.insets.top);
      } else {
        super.paint(param1Graphics);
        param1Graphics.translate(this.this$0.insets.left, this.this$0.insets.top);
        if (this.this$0.current instanceof PainterElement) {
          PainterElementDef painterElementDef = (PainterElementDef)this.this$0.current;
          if (painterElementDef.getAnchorElement() != null) {
            Vector vector = (Vector)this.elemmap.get(painterElementDef.getAnchorElement());
            if (vector != null)
              if ((painterElementDef.getAnchor()).y > 0.0F) {
                Point point = new Point();
                for (byte b1 = 0; b1 < vector.size(); b1++) {
                  Rectangle rectangle1 = (Rectangle)vector.elementAt(b1);
                  point.x = Math.max(rectangle1.x, point.x);
                  point.y = Math.max(rectangle1.y + rectangle1.height, point.y);
                } 
                param1Graphics.drawImage(this.this$0.anchorImg, point.x, point.y, null);
              } else {
                Point point = new Point(0, 2147483647);
                for (byte b1 = 0; b1 < vector.size(); b1++) {
                  Rectangle rectangle1 = (Rectangle)vector.elementAt(b1);
                  point.x = Math.max(rectangle1.x, point.x);
                  point.y = Math.min(rectangle1.y, point.y);
                } 
                param1Graphics.drawImage(this.this$0.anchorImg, point.x, point.y - this.this$0.anchorImg.getHeight(null), null);
              }  
          } 
        } 
      } 
      param1Graphics.setColor(this.this$0.editArea ? Color.darkGray : Color.lightGray);
      for (byte b = 0; b < this.pageframes.length; b++) {
        char c = (this.currFrame == b && this.nonflow.get(b)) ? 4098 : 4113;
        Common.drawRect(param1Graphics, (this.pageframes[b]).x, (this.pageframes[b]).y, (this.pageframes[b]).width, (this.pageframes[b]).height, c);
        if (this.this$0.editArea) {
          param1Graphics.drawString(Integer.toString(b + 1), (this.pageframes[b]).x + 5, (this.pageframes[b]).y + 16);
          if (this.pageareas[b].getBorder() != 0)
            Common.drawRect(param1Graphics, (this.pageframes[b]).x, (this.pageframes[b]).y, (this.pageframes[b]).width, (this.pageframes[b]).height, this.pageareas[b].getBorder()); 
        } 
      } 
      if (!this.this$0.editArea) {
        paintBox(param1Graphics);
        if (this.this$0.tableResizer != null) {
          this.this$0.tableResizer.paint(param1Graphics);
        } else if (this.this$0.sectionResizer != null) {
          this.this$0.sectionResizer.paint(param1Graphics);
        } else if (this.this$0.rubberBand != null) {
          this.this$0.rubberBand.paint(param1Graphics);
        } 
        if (this.drawingElement != null && this.elemBox != null) {
          Common.drawRect(param1Graphics, this.elemBox.x, this.elemBox.y, this.elemBox.width, this.elemBox.height, 4113);
          paintResizeBox(param1Graphics, this.elemBox);
        } 
        if (this.this$0.currPage == this && this.this$0.cursor != null) {
          param1Graphics.setColor(Color.black);
          int i = this.this$0.cursor.x - 1;
          int j = this.this$0.cursor.y;
          if (this.this$0.textmode) {
            if (!this.this$0.editing) {
              int k = Math.min(this.this$0.cursor.height, 16);
              j += (this.this$0.cursor.height - k) / 2;
              int m = j + k;
              param1Graphics.drawLine(i, j + 1, i, m - 1);
              param1Graphics.drawLine(i - 1, j, i - 2, j);
              param1Graphics.drawLine(i + 1, j, i + 2, j);
              param1Graphics.drawLine(i - 1, m, i - 2, m);
              param1Graphics.drawLine(i + 1, m, i + 2, m);
              param1Graphics.setColor(Color.white);
              param1Graphics.drawLine(i, j, i, j);
              param1Graphics.drawLine(i, m, i, m);
            } 
          } else {
            int[] arrayOfInt1 = { i, i - 3, i, i + 3 };
            int[] arrayOfInt2 = { j, j - 4, j - 3, j - 4 };
            param1Graphics.fillPolygon(arrayOfInt1, arrayOfInt2, arrayOfInt1.length);
          } 
        } 
      } 
      param1Graphics.translate(-this.this$0.insets.left, -this.this$0.insets.top);
    }
    
    public void positionCursor() {
      if (this.this$0.currPage != this)
        return; 
      Rectangle rectangle = (this.this$0.target == 0 && this.pageframes.length > 0) ? this.pageframes[0] : getPrintBounds();
      this.this$0.cursor = null;
      if (this.this$0.current != null) {
        BaseElement baseElement = (BaseElement)getPrevElement(this.this$0.current);
        if (baseElement == null) {
          this.this$0.cursor = new Rectangle(rectangle.x, rectangle.y, 1, 12);
        } else if (!baseElement.isLastOnLine()) {
          Vector vector = (Vector)this.elemmap.get(baseElement);
          if (vector != null && vector.size() > 0) {
            Rectangle rectangle1 = (Rectangle)vector.elementAt(vector.size() - 1);
            this.this$0.cursor = new Rectangle(rectangle1.x + rectangle1.width, rectangle1.y, 1, rectangle1.height);
          } 
        } 
        if (this.this$0.cursor == null || this.this$0.cursor.x + 36 > rectangle.x + rectangle.width) {
          Rectangle rectangle1 = getElementBounds(this.this$0.current);
          if (this.this$0.current instanceof PainterElement) {
            Position position = ((PainterElement)this.this$0.current).getAnchor();
            if (position != null && position.y >= 0.0F)
              this.this$0.cursor = new Rectangle(rectangle.x, (int)(rectangle1.y - position.y * 72.0F), 1, rectangle1.height); 
          } 
          if (this.this$0.cursor == null)
            this.this$0.cursor = new Rectangle(rectangle1.x - 1, rectangle1.y, 1, rectangle1.height); 
        } 
      } 
      if (this.this$0.cursor == null && this.this$0.current == null) {
        BaseElement baseElement = (BaseElement)getPrevElement(null);
        if (baseElement != null && !(baseElement instanceof PageLayoutElement)) {
          Vector vector = (Vector)this.elemmap.get(baseElement);
          if (vector != null) {
            Rectangle rectangle1 = (Rectangle)vector.elementAt(vector.size() - 1);
            if (!baseElement.isLastOnLine() && rectangle1.x + rectangle1.width + 36 < rectangle.x + rectangle.width) {
              this.this$0.cursor = new Rectangle(rectangle1.x + rectangle1.width, rectangle1.y, 1, rectangle1.height);
            } else {
              Rectangle rectangle2 = (baseElement.getFrame() == null) ? rectangle : baseElement.getFrame();
              this.this$0.cursor = new Rectangle(rectangle2.x, rectangle1.y + rectangle1.height, 1, 12);
            } 
          } 
        } 
      } 
      if (this.this$0.cursor == null) {
        ReportElement reportElement = getPrevElement(null);
        if (reportElement == null || reportElement instanceof PageLayoutElement)
          this.this$0.cursor = new Rectangle(rectangle.x, rectangle.y, 1, 12); 
      } 
    }
    
    public boolean isCurrentNonFlowFrame() { return (this.this$0.currPage == this && this.currFrame >= 0 && this.nonflow.get(this.currFrame)); }
    
    public void setDrawElement(ReportElement param1ReportElement, SectionElement param1SectionElement) {
      this.drawingElement = (BaseElement)param1ReportElement;
      if (param1SectionElement != null) {
        this.drawingBox = new Rectangle(getElementBounds(param1SectionElement));
        this.drawingSection = param1SectionElement;
      } else {
        this.drawingBox = this.pageframes[this.currFrame];
        this.drawingSection = null;
      } 
    }
    
    private void addSelectedElement(ReportElement param1ReportElement, Paintable param1Paintable) {
      if (this.this$0.currlist.indexOf(param1ReportElement) >= 0)
        return; 
      addToListSorted(param1ReportElement, this.this$0.currlist);
      if (param1ReportElement instanceof PainterElement || ((BaseElement)param1ReportElement).getParent() instanceof FixedContainer) {
        if (param1Paintable == null)
          param1Paintable = (Paintable)((Vector)this.elempaintable.get(param1ReportElement)).elementAt(0); 
        ResizeBox resizeBox = new ResizeBox(this, param1ReportElement, param1Paintable);
        if (this.this$0.resizeBoxes.size() == 0) {
          this.this$0.resizeBoxes.addElement(resizeBox);
        } else {
          ResizeBox resizeBox1 = (ResizeBox)this.this$0.resizeBoxes.elementAt(0);
          if (resizeBox1.page == this) {
            if (!resizeBox1.isSameGroup(resizeBox))
              this.this$0.resizeBoxes.removeAllElements(); 
            this.this$0.resizeBoxes.addElement(resizeBox);
          } 
        } 
      } 
    }
    
    private Rectangle getFixedElementBounds(Paintable param1Paintable) {
      BaseElement baseElement = (BaseElement)param1Paintable.getElement();
      FixedContainer fixedContainer = (FixedContainer)baseElement.getParent();
      Rectangle rectangle1 = new Rectangle(fixedContainer.getBounds(fixedContainer.getElementIndex(baseElement)));
      Rectangle rectangle2 = ((BasePaintable)param1Paintable).getFrame();
      rectangle1.x += rectangle2.x;
      rectangle1.y += rectangle2.y;
      return rectangle1;
    }
    
    private int getNonFlowFrame(BaseElement param1BaseElement) {
      FixedContainer fixedContainer = (FixedContainer)param1BaseElement.getParent();
      for (byte b = 0; b < this.pageareas.length; b++) {
        if (this.pageareas[b].getElements() == fixedContainer)
          return b; 
      } 
      return -1;
    }
    
    private void setFixedElementBounds(BaseElement param1BaseElement, Paintable param1Paintable, Rectangle param1Rectangle) {
      SectionBand sectionBand = (FixedContainer)param1BaseElement.getParent();
      Rectangle rectangle = ((BasePaintable)param1Paintable).getFrame();
      param1Rectangle = new Rectangle(param1Rectangle);
      if (sectionBand instanceof SectionBand) {
        if (!rectangle.contains(param1Rectangle.x, param1Rectangle.y)) {
          String str = ((SectionBand)sectionBand).getBinding(param1BaseElement.getID());
          SectionPaintable sectionPaintable = (SectionPaintable)this.bandmap.get(sectionBand);
          SectionBand sectionBand1 = sectionPaintable.findSectionBand(param1Rectangle);
          sectionBand.removeElement(sectionBand.getElementIndex(param1BaseElement));
          sectionBand1.addElement(param1BaseElement, param1Rectangle);
          sectionBand1.setBinding(param1BaseElement.getID(), str);
          sectionBand = sectionBand1;
          rectangle = sectionPaintable.getSectionBandBounds(sectionBand1);
        } else {
          param1Rectangle.y -= rectangle.y;
        } 
        param1Rectangle.x -= rectangle.x;
        param1Rectangle.x = Math.min(param1Rectangle.x, rectangle.width - param1Rectangle.width);
        param1Rectangle.y = Math.min(param1Rectangle.y, rectangle.height - param1Rectangle.height);
        int i = sectionBand.getElementIndex(param1BaseElement);
        this.this$0.undoMgr.undoBounds(param1BaseElement, sectionBand.getBounds(i));
        sectionBand.setBounds(i, param1Rectangle);
      } else {
        param1Rectangle.x -= rectangle.x;
        param1Rectangle.y -= rectangle.y;
        int i = sectionBand.getElementIndex(param1BaseElement);
        this.this$0.undoMgr.undoBounds(param1BaseElement, sectionBand.getBounds(i));
        sectionBand.setBounds(i, param1Rectangle);
      } 
    }
    
    private void checkResizeCursor(Rectangle param1Rectangle, MouseEvent param1MouseEvent) {
      int i = param1MouseEvent.getX() - this.this$0.insets.left;
      int j = param1MouseEvent.getY() - this.this$0.insets.top;
      if (param1Rectangle == null) {
        for (byte b = 0; b < this.this$0.resizeBoxes.size(); b++) {
          ResizeBox resizeBox = (ResizeBox)this.this$0.resizeBoxes.elementAt(b);
          this.this$0.resizeType.type = Resizer.getResizeType(resizeBox.bounds, i, j);
          if (this.this$0.resizeType.type >= 0) {
            this.this$0.resizeType.bounds = resizeBox.bounds;
            this.this$0.resizeType.paintable = resizeBox.paintable;
            this.this$0.resizeType.element = resizeBox.element;
            this.this$0.resizeType.page = resizeBox.page;
            break;
          } 
        } 
      } else {
        this.this$0.resizeType.type = Resizer.getResizeType(param1Rectangle, i, j);
        this.this$0.resizeType.bounds = param1Rectangle;
        this.this$0.resizeType.paintable = null;
        this.this$0.resizeType.element = null;
        this.this$0.resizeType.page = this.this$0.currPage;
      } 
      if (!this.this$0.textmode && !this.this$0.drawingArea && this.this$0.ordering < 0)
        setCursor(Resizer.getCursor(this.this$0.resizeType.type)); 
    }
    
    public void mouseDragged(MouseEvent param1MouseEvent) {
      if (this.this$0.textmode && !this.this$0.editArea)
        return; 
      if (!this.this$0.editArea && this.this$0.tableResizer != null) {
        this.this$0.tableResizer.processMouseEvent(param1MouseEvent);
        repaint(100L);
        if (this.this$0.tableResizer.isResizing())
          return; 
      } else if (!this.this$0.editArea && this.this$0.sectionResizer != null) {
        this.this$0.sectionResizer.processMouseEvent(param1MouseEvent);
        repaint(100L);
        if (this.this$0.sectionResizer.isResizing())
          return; 
      } 
      if (this.this$0.resizer != null) {
        this.this$0.resizer.processMouseEvent(param1MouseEvent);
        repaint(100L);
      } else if (this.this$0.rubberBand != null) {
        this.this$0.rubberBand.processMouseEvent(param1MouseEvent);
        repaint(100L);
      } 
    }
    
    public void mouseMoved(MouseEvent param1MouseEvent) {
      if (this.this$0.textmode && !this.this$0.editArea)
        return; 
      int i = param1MouseEvent.getX() - this.this$0.insets.left;
      int j = param1MouseEvent.getY() - this.this$0.insets.top;
      if (this.drawingElement != null) {
        setCursor(new Cursor(this.drawingBox.contains(i, j) ? 1 : 0));
        return;
      } 
      if (!this.this$0.editArea && this.this$0.tableResizer != null) {
        this.this$0.tableResizer.processMouseEvent(param1MouseEvent);
        if (this.this$0.tableResizer.isAtResizeLocation())
          return; 
      } else if (!this.this$0.editArea && this.this$0.sectionResizer != null) {
        this.this$0.sectionResizer.processMouseEvent(param1MouseEvent);
        if (this.this$0.sectionResizer.isAtResizeLocation())
          return; 
      } 
      Rectangle rectangle = null;
      if (this.this$0.editArea && this.this$0.ordering < 0 && this.currFrame >= 0)
        rectangle = this.pageframes[this.currFrame]; 
      checkResizeCursor(rectangle, param1MouseEvent);
    }
    
    public void mouseClicked(MouseEvent param1MouseEvent) {
      int i = param1MouseEvent.getX() - this.this$0.insets.left;
      int j = param1MouseEvent.getY() - this.this$0.insets.top;
      int k = findFrame(i, j);
      boolean bool = (k >= 0 && this.nonflow.get(k)) ? 1 : 0;
      if (!this.this$0.editArea && (this.this$0.resizer == null || !this.this$0.resizer.isStarted())) {
        Rectangle rectangle = getPrintBounds();
        boolean bool1 = (j >= rectangle.y && j <= rectangle.y + rectangle.height) ? 1 : 0;
        if (!param1MouseEvent.isControlDown())
          this.this$0.clearSelectedElements(); 
        if (!bool1 && param1MouseEvent.getClickCount() == 2) {
          int[] arrayOfInt = { 256, 0, 512 };
          for (byte b = 0; b < arrayOfInt.length; b++) {
            if (arrayOfInt[b] != this.this$0.target) {
              rectangle = getPrintBounds(arrayOfInt[b]);
              if (rectangle.contains(i, j)) {
                this.this$0.setTarget(arrayOfInt[b]);
                this.this$0.fireEvent();
                break;
              } 
            } 
          } 
        } else {
          BaseElement baseElement = null;
          Rectangle rectangle1 = null;
          Rectangle rectangle2 = null;
          Paintable paintable1 = null;
          Paintable paintable2 = null;
          Paintable paintable3 = null;
          Paintable paintable4 = null;
          int m = 0, n = 10000, i1 = 0;
          Enumeration enumeration1 = this.paintablemap.keys();
          Enumeration enumeration2 = this.paintablemap.elements();
          if (this.pageframes != null)
            for (byte b = 0; b < this.pageframes.length; b++) {
              if (this.pageframes[b].contains(i, j)) {
                rectangle2 = this.pageframes[b];
                break;
              } 
            }  
          while (enumeration1.hasMoreElements()) {
            Rectangle rectangle3 = (Rectangle)enumeration1.nextElement();
            Paintable paintable = (Paintable)enumeration2.nextElement();
            Object object = ((BaseElement)paintable.getElement()).getParent();
            if (bool1 && rectangle3.contains(i, j) && (rectangle1 == null || (rectangle1.contains(rectangle3.x, rectangle3.y) && rectangle1.contains(rectangle3.x + rectangle3.width - 1, rectangle3.y + rectangle3.height - 1)))) {
              baseElement = (BaseElement)paintable.getElement();
              baseElement = (object instanceof ReportElement) ? (BaseElement)baseElement.getParent() : baseElement;
              paintable1 = paintable;
              rectangle1 = rectangle3;
              continue;
            } 
            if (!(object instanceof FixedContainer) && rectangle3.y <= j && rectangle3.y + rectangle3.height > j && bool1) {
              if (rectangle3.x < i && rectangle3.x > m) {
                paintable2 = paintable;
                m = rectangle3.x;
              } else if (rectangle3.x > i && rectangle3.x < n && (rectangle2 == null || (rectangle2.contains(rectangle3.x, rectangle3.y) && rectangle2.contains(rectangle3.x + rectangle3.width - 2, rectangle3.y + rectangle3.height - 2)))) {
                paintable3 = paintable;
                n = rectangle3.x;
              } 
              if (rectangle3.x + rectangle3.width < i && rectangle3.x > i1) {
                paintable4 = paintable;
                i1 = rectangle3.x;
              } 
            } 
          } 
          if (baseElement != null) {
            addSelectedElement(baseElement, paintable1);
            if (param1MouseEvent.getClickCount() == 2) {
              this.this$0.setCurrent(baseElement, this);
              this.this$0.showProperty();
            } else if (this.this$0.textmode && !this.this$0.editing) {
              if (baseElement instanceof inetsoft.report.TableElement) {
                Point point = ((TablePaintable)paintable1).locate(i, j);
                if (point != null)
                  showEditor((TableElementDef)baseElement, point.y, point.x, (TablePaintable)paintable1, param1MouseEvent.getPoint()); 
              } else if (baseElement instanceof TextBased) {
                showEditor(baseElement, false, param1MouseEvent.getPoint(), ((TextBased)baseElement).getText());
              } 
            } 
          } 
          if (!bool && baseElement == null && paintable2 != null)
            baseElement = (BaseElement)getNextElement(paintable2.getElement()); 
          if (!bool && baseElement == null && paintable3 != null) {
            baseElement = (BaseElement)paintable3.getElement();
            baseElement = (baseElement.getParent() instanceof ReportElement) ? (BaseElement)baseElement.getParent() : baseElement;
          } 
          if (!bool && baseElement == null && paintable4 != null) {
            baseElement = (BaseElement)paintable4.getElement();
            baseElement = (baseElement.getParent() instanceof ReportElement) ? (BaseElement)baseElement.getParent() : baseElement;
            if (!(baseElement instanceof inetsoft.report.NewlineElement)) {
              baseElement = (BaseElement)getNextElement(baseElement);
              if (baseElement != null)
                baseElement = (baseElement.getParent() instanceof ReportElement) ? (BaseElement)baseElement.getParent() : baseElement; 
            } 
          } 
          this.this$0.setCurrent(baseElement, this);
          checkResizeCursor(null, param1MouseEvent);
          if (this.this$0.tableResizer != null) {
            this.this$0.tableResizer.processMouseEvent(param1MouseEvent);
          } else if (this.this$0.sectionResizer != null) {
            this.this$0.sectionResizer.processMouseEvent(param1MouseEvent);
          } 
        } 
        repaint(100L);
      } 
      if (this.this$0.editArea)
        if (k >= 0 && this.this$0.ordering >= 0) {
          if (this.this$0.ordering == 0)
            this.this$0.undoMgr.undoPageArea(this, this.editID, this.pageareas); 
          if (this.this$0.ordering != k) {
            Rectangle rectangle = this.pageframes[k];
            PageArea pageArea = this.pageareas[k];
            this.pageframes[k] = this.pageframes[this.this$0.ordering];
            this.pageareas[k] = this.pageareas[this.this$0.ordering];
            this.pageframes[this.this$0.ordering] = rectangle;
            this.pageareas[this.this$0.ordering] = pageArea;
          } 
          this.this$0.ordering++;
          if (this.this$0.ordering >= this.pageframes.length) {
            synchronized (this.this$0) {
              this.this$0.ordering = -1;
              this.this$0.notifyAll();
            } 
            setCursor(new Cursor(0));
          } 
          repaint(100L);
        } else if (k >= 0) {
          checkResizeCursor(this.pageframes[k], param1MouseEvent);
          if (param1MouseEvent.getClickCount() == 2 && this.currFrame >= 0)
            this.this$0.showProperty(); 
        }  
      if (this.this$0.current == null || this.this$0.editArea)
        if (k != this.currFrame) {
          this.currFrame = k;
          this.this$0.setEnabled();
          repaint(100L);
        }  
    }
    
    public void mousePressed(MouseEvent param1MouseEvent) {
      if (param1MouseEvent.isPopupTrigger()) {
        handlePopup(param1MouseEvent);
        return;
      } 
      int i = param1MouseEvent.getX() - this.this$0.insets.left;
      int j = param1MouseEvent.getY() - this.this$0.insets.top;
      if (this.this$0.drawingArea && this.this$0.editArea) {
        this.areaBox = new Rectangle(i, j, 1, 1);
        this.this$0.resizer = new Resizer(new ResizeBox(this, this.areaBox, null, 12), null, this.resolution, this.this$0.insets);
        repaint(100L);
        return;
      } 
      if (this.drawingElement != null && this.drawingBox.contains(i, j)) {
        this.elemBox = new Rectangle(i, j, 1, 1);
        this.this$0.resizer = new Resizer(new ResizeBox(this, this.elemBox, this.drawingBox, 12), null, this.resolution, this.this$0.insets);
        if (this.drawingElement instanceof TextBased)
          this.this$0.resizer.setVUnit(this.drawingElement); 
        repaint(100L);
        return;
      } 
      if (this.this$0.tableResizer != null) {
        this.this$0.tableResizer.processMouseEvent(param1MouseEvent);
      } else if (this.this$0.sectionResizer != null) {
        this.this$0.sectionResizer.processMouseEvent(param1MouseEvent);
      } 
      if (!this.this$0.textmode && !this.this$0.editing && this.this$0.resizeType.type >= 0 && (this.this$0.resizer == null || this.this$0.resizer.getType() != this.this$0.resizeType.type))
        if (this.this$0.resizeType.bounds != null)
          startResize();  
      if (this.this$0.resizer != null) {
        this.this$0.resizer.processMouseEvent(param1MouseEvent);
      } else if (!param1MouseEvent.isControlDown() && !param1MouseEvent.isShiftDown()) {
        this.rubberBox = new Rectangle(i, j, 1, 1);
        this.this$0.rubberBand = new Resizer(new ResizeBox(this, this.rubberBox, null, 12), null, this.resolution, this.this$0.insets);
        this.this$0.rubberBand.setAllowNegative(true);
      } 
      this.this$0.setCurrentPage(this);
      if (this.this$0.reprintLater && !this.this$0.editing) {
        this.this$0.reprintLater = false;
        this.this$0.reprint(this.this$0.current);
      } 
    }
    
    public void mouseReleased(MouseEvent param1MouseEvent) {
      if (param1MouseEvent.isPopupTrigger()) {
        handlePopup(param1MouseEvent);
        return;
      } 
      if (this.this$0.textmode && !this.this$0.editArea)
        return; 
      int i = param1MouseEvent.getX() - this.this$0.insets.left;
      int j = param1MouseEvent.getY() - this.this$0.insets.top;
      if (this.this$0.editArea) {
        if (this.this$0.ordering < 0 && this.this$0.resizer != null) {
          this.this$0.undoMgr.undoPageArea(this, this.editID, this.pageareas);
          this.this$0.resizer.processMouseEvent(param1MouseEvent);
          if (this.this$0.drawingArea && this.areaBox != null) {
            PageArea pageArea = new PageArea(0.0D, 0.0D, 0.0D, 0.0D);
            pageArea.setBounds(this.areaBox, this.printBox, this.resolution);
            insertArea(pageArea);
            synchronized (this.this$0) {
              this.this$0.drawingArea = false;
              this.this$0.notifyAll();
            } 
            this.areaBox = null;
            setCursor(new Cursor(0));
          } else {
            for (byte b = 0; b < this.pageareas.length; b++)
              this.pageareas[b].setBounds(this.pageframes[b], this.printBox, this.resolution); 
          } 
          this.this$0.fireEvent();
          repaint(100L);
          this.this$0.pending = (BaseElement)getElement(0);
        } 
      } else if (this.this$0.tableResizer != null && this.this$0.tableResizer.isResizing()) {
        this.this$0.tableResizer.processMouseEvent(param1MouseEvent);
        if (this.this$0.tableResizer.isResized())
          this.this$0.reprint(this.this$0.current); 
      } else if (this.this$0.sectionResizer != null && this.this$0.sectionResizer.isResizing()) {
        this.this$0.sectionResizer.processMouseEvent(param1MouseEvent);
        if (this.this$0.sectionResizer.isResized())
          this.this$0.reprint(this.this$0.current); 
      } else if (this.drawingElement != null && this.elemBox != null) {
        SectionBand sectionBand = null;
        this.this$0.resizer.processMouseEvent(param1MouseEvent);
        if (this.drawingSection == null) {
          if (this.currFrame < this.pageareas.length) {
            sectionBand = this.pageareas[this.currFrame].getElements();
            if (sectionBand == null) {
              sectionBand = new FixedContainer(this.this$0.sheet);
              this.pageareas[this.currFrame].setElements(sectionBand);
            } 
            this.elemBox.x -= this.drawingBox.x;
            this.elemBox.y -= this.drawingBox.y;
            sectionBand.addElement(this.drawingElement, this.elemBox);
          } 
        } else {
          Vector vector = (Vector)this.elempaintable.get(this.drawingSection);
          SectionPaintable sectionPaintable = (SectionPaintable)vector.elementAt(0);
          String str = this.drawingElement.getProperty("__BINDING__");
          this.drawingElement.setProperty("__BINDING__", null);
          sectionBand = sectionPaintable.findSectionBand(this.elemBox);
          Rectangle rectangle = sectionPaintable.getSectionBandBounds((SectionBand)sectionBand);
          this.elemBox.x -= this.drawingBox.x;
          this.elemBox.x = Math.min(this.elemBox.x, rectangle.width - this.elemBox.width);
          this.elemBox.y = Math.min(this.elemBox.y, rectangle.height - this.elemBox.height);
          sectionBand.addElement(this.drawingElement, this.elemBox);
          ((SectionBand)sectionBand).setBinding(this.drawingElement.getID(), str);
        } 
        this.this$0.undoMgr.undoInsert(this.drawingElement, sectionBand);
        BaseElement baseElement = (this.drawingElement instanceof TextBased) ? this.drawingElement : null;
        this.drawingElement = null;
        this.elemBox = null;
        setCursor(new Cursor(0));
        this.this$0.reprint(null);
        if (baseElement != null)
          showEditor(baseElement, false, null, null); 
      } else if (this.this$0.resizeType.bounds != null && this.this$0.resizer != null) {
        this.this$0.resizer.processMouseEvent(param1MouseEvent);
        if (processResize()) {
          this.this$0.reprint(this.this$0.resizeType.element);
        } else {
          repaint();
        } 
      } else if (this.this$0.rubberBand != null) {
        this.rubberBox = this.this$0.rubberBand.getNormalized();
        if (this.rubberBox.width > 2 && this.rubberBox.height > 2) {
          this.this$0.clearSelectedElements();
          Enumeration enumeration1 = this.paintablemap.keys();
          Enumeration enumeration2 = this.paintablemap.elements();
          ReportElement reportElement = null;
          Point point = new Point(2147483647, 2147483647);
          while (enumeration1.hasMoreElements()) {
            Rectangle rectangle = (Rectangle)enumeration1.nextElement();
            Paintable paintable = (Paintable)enumeration2.nextElement();
            if (rectangle.intersects(this.rubberBox)) {
              addSelectedElement(paintable.getElement(), paintable);
              if (rectangle.y < point.y || (rectangle.y == point.y && rectangle.x < point.x))
                reportElement = paintable.getElement(); 
            } 
          } 
          if (reportElement != null)
            this.this$0.setCurrent(reportElement, this); 
        } 
        this.this$0.rubberBand = null;
        this.rubberBox = null;
        repaint();
      } 
      this.this$0.resizer = null;
    }
    
    private void startResize() {
      ResizeBox resizeBox = this.this$0.resizeType;
      for (byte b = 0; resizeBox != null; b++) {
        if (resizeBox.element != null && resizeBox.element.getParent() instanceof FixedContainer) {
          FixedContainer fixedContainer = (FixedContainer)resizeBox.element.getParent();
          if (fixedContainer instanceof SectionBand) {
            Paintable paintable = (Paintable)this.bandmap.get(fixedContainer);
            resizeBox.bbox = paintable.getBounds();
          } else if (resizeBox.paintable != null) {
            resizeBox.bbox = ((BasePaintable)resizeBox.paintable).getFrame();
          } else {
            resizeBox.bbox = resizeBox.element.getFrame();
          } 
        } else if (this.this$0.editArea) {
          Dimension dimension = getSize();
          this.this$0.resizeType.bbox = new Rectangle(0, 0, dimension.width, dimension.height);
        } else {
          resizeBox.bbox = null;
        } 
        resizeBox = (b < this.this$0.resizeBoxes.size()) ? (ResizeBox)this.this$0.resizeBoxes.elementAt(b) : null;
      } 
      this.this$0.resizer = new Resizer(this.this$0.resizeType, this.this$0.resizeBoxes, this.resolution, this.this$0.insets);
      if (!Resizer.isSnapToGrid() && (this.this$0.resizeType.type & 0x4) != 0 && this.this$0.resizeType.element instanceof TextBased)
        this.this$0.resizer.setVUnit(this.this$0.resizeType.element); 
    }
    
    private boolean processResize() {
      boolean bool = false;
      boolean bool1 = (this.this$0.resizeType.element != null && this.this$0.resizeType.element.getParent() instanceof FixedContainer) ? 1 : 0;
      if (bool1) {
        if (this.this$0.resizer.isLocationChanged() || this.this$0.resizer.isSizeChanged()) {
          for (byte b = 0; b < this.this$0.resizeBoxes.size(); b++) {
            ResizeBox resizeBox = (ResizeBox)this.this$0.resizeBoxes.elementAt(b);
            setFixedElementBounds(resizeBox.element, resizeBox.paintable, resizeBox.bounds);
          } 
          bool = true;
        } 
      } else if (this.this$0.resizeType.element instanceof PainterElement) {
        Rectangle rectangle = this.this$0.resizeType.bounds;
        PainterElementDef painterElementDef = (PainterElementDef)this.this$0.resizeType.element;
        if (this.this$0.resizer.isSizeChanged()) {
          this.this$0.undoMgr.undoResize(painterElementDef, painterElementDef.getSize());
          painterElementDef.setSize(new Size(rectangle.width, rectangle.height, this.resolution));
          bool = true;
          this.this$0.fireEvent();
        } 
        if (!bool1 && this.this$0.resizer.isLocationChanged()) {
          Rectangle rectangle1 = painterElementDef.getFrame();
          int i = rectangle1.y;
          int j = Integer.MAX_VALUE;
          bool = true;
          if (painterElementDef.getWrapping() == 2 || painterElementDef.getWrapping() == 256) {
            j = (getElementBounds(painterElementDef)).y;
            Position position = painterElementDef.getAnchor();
            if (position != null)
              j -= (int)Math.abs(position.y * this.resolution); 
            i = j;
          } else {
            ReportElement reportElement1 = getPrevElement(painterElementDef);
            if (reportElement1 != null) {
              Rectangle rectangle2 = ((BaseElement)reportElement1).getFrame();
              if (!frameEquals(rectangle1, rectangle2))
                reportElement1 = null; 
            } 
            for (ReportElement reportElement2 = reportElement1; reportElement2 != null; reportElement2 = getPrevElement(reportElement2)) {
              Vector vector = (Vector)this.elemmap.get(reportElement2);
              int k = 0;
              if (reportElement2 instanceof PainterElement) {
                PainterElementDef painterElementDef1 = (PainterElementDef)reportElement2;
                Position position = painterElementDef1.getAnchor();
                if (position != null && position.y < 0.0F)
                  k = (int)(position.y * this.resolution); 
              } 
              for (byte b = 0; b < vector.size(); b++) {
                Rectangle rectangle2 = (Rectangle)vector.elementAt(b);
                i = Math.max(i, rectangle2.y + rectangle2.height);
                j = Math.min(j, rectangle2.y + k);
              } 
              if (((BaseElement)reportElement2).isNewline())
                break; 
            } 
          } 
          Position position1 = painterElementDef.getAnchor();
          if (position1 == null)
            position1 = new Position(); 
          Position position2 = new Position(position1);
          i = Math.max(i, rectangle1.y);
          j = (j == Integer.MAX_VALUE) ? rectangle1.y : Math.max(j, rectangle1.y);
          if (rectangle.y > i) {
            position2.y = (rectangle.y - i) / this.resolution;
          } else if (rectangle.y > j) {
            position2.y = (j - rectangle.y) / this.resolution;
          } else {
            position2.y = 0.0F;
          } 
          position2.x = Math.max(rectangle.x - rectangle1.x, 0);
          position2.x = Math.min(position2.x, (rectangle1.width - rectangle.width)) / this.resolution;
          if (position1.x < 0.0F)
            position2.x -= rectangle1.width / this.resolution; 
          this.this$0.undoMgr.undoMove(painterElementDef, painterElementDef.getAnchor());
          painterElementDef.setAnchor(position2);
          this.this$0.fireEvent();
        } 
      } 
      return bool;
    }
    
    private void handlePopup(MouseEvent param1MouseEvent) {
      JPopupMenu jPopupMenu = getPopupMenu(param1MouseEvent.getPoint());
      int i = param1MouseEvent.getX() - this.this$0.insets.left;
      int j = param1MouseEvent.getY() - this.this$0.insets.top;
      jPopupMenu.show((Component)param1MouseEvent.getSource(), i, j);
    }
    
    public void mouseEntered(MouseEvent param1MouseEvent) {}
    
    public void mouseExited(MouseEvent param1MouseEvent) {}
    
    public JPopupMenu getPopupMenu(Point param1Point) {
      JPopupMenu jPopupMenu = new JPopupMenu();
      if (this.this$0.current instanceof SectionElement) {
        jPopupMenu.add(this.this$0.sectionInsertM);
        jPopupMenu.addSeparator();
      } 
      jPopupMenu.add(this.this$0.editM);
      jPopupMenu.add(this.this$0.copyM);
      jPopupMenu.add(this.this$0.cutM);
      jPopupMenu.add(this.this$0.pasteM);
      jPopupMenu.addSeparator();
      jPopupMenu.add(this.this$0.propertyM);
      jPopupMenu.add(this.this$0.scriptM);
      if (param1Point != null && this.this$0.current instanceof inetsoft.report.TableElement) {
        TableXElement tableXElement = (TableXElement)this.this$0.current;
        Vector vector = (Vector)this.elempaintable.get(this.this$0.current);
        Point point = null;
        for (byte b = 0; b < vector.size(); b++) {
          TablePaintable tablePaintable = (TablePaintable)vector.elementAt(b);
          point = tablePaintable.locate(param1Point.x, param1Point.y);
          if (point != null)
            break; 
        } 
        if (point != null) {
          jPopupMenu.addSeparator();
          TableAttr tableAttr1 = tableXElement.getRowAttribute(point.y);
          TableAttr tableAttr2 = tableXElement.getColAttribute(point.x);
          JMenu jMenu1 = null;
          JMenu jMenu2 = null;
          JMenu jMenu3 = new JMenu(Catalog.getString("Alignment"));
          jMenu1 = new JMenu(Catalog.getString("Row"));
          jMenu2 = new JMenu(Catalog.getString("Column"));
          jPopupMenu.add(jMenu3);
          jMenu3.add(jMenu2);
          jMenu3.add(jMenu1);
          for (byte b1 = 0; b1 < this.this$0.align_opts.length; b1++) {
            int i = ((Integer)this.this$0.align_opts[b1][1]).intValue();
            JRadioButtonMenuItem jRadioButtonMenuItem = new JRadioButtonMenuItem((String)this.this$0.align_opts[b1][0]);
            if (tableAttr1 != null && tableAttr1.alignment != null && i == tableAttr1.alignment.intValue())
              jRadioButtonMenuItem.setSelected(true); 
            RowAlignmentListener rowAlignmentListener = new RowAlignmentListener(this.this$0, tableXElement, point.y, ((Integer)this.this$0.align_opts[b1][1]).intValue());
            jRadioButtonMenuItem.addActionListener(rowAlignmentListener);
            jMenu1.add(jRadioButtonMenuItem);
            jRadioButtonMenuItem = new JRadioButtonMenuItem((String)this.this$0.align_opts[b1][0]);
            if (tableAttr2 != null && tableAttr2.alignment != null && i == tableAttr2.alignment.intValue())
              jRadioButtonMenuItem.setSelected(true); 
            ColAlignmentListener colAlignmentListener = new ColAlignmentListener(this.this$0, tableXElement, point.x, ((Integer)this.this$0.align_opts[b1][1]).intValue());
            jRadioButtonMenuItem.addActionListener(colAlignmentListener);
            jMenu2.add(jRadioButtonMenuItem);
          } 
          JMenu jMenu4 = new JMenu(Catalog.getString("Format"));
          jMenu1 = new JMenu(Catalog.getString("Row"));
          jMenu2 = new JMenu(Catalog.getString("Column"));
          jPopupMenu.add(jMenu4);
          jMenu4.add(jMenu2);
          jMenu4.add(jMenu1);
          for (byte b2 = 0; b2 < this.this$0.format_strs.length; b2++) {
            JRadioButtonMenuItem jRadioButtonMenuItem = new JRadioButtonMenuItem(this.this$0.format_strs[b2][0]);
            String str = null;
            if (tableAttr1 != null && tableAttr1.format == this.this$0.format_strs[b2][true]) {
              jRadioButtonMenuItem.setSelected(true);
            } else if (tableAttr1 != null && tableAttr1.format != null && this.this$0.format_strs[b2][true] != null && this.this$0.format_strs[b2][1].equals(tableAttr1.format)) {
              jRadioButtonMenuItem.setSelected(true);
              str = tableAttr1.format_spec;
            } 
            RowFormatListener rowFormatListener = new RowFormatListener(this.this$0, tableXElement, point.y, this.this$0.format_strs[b2][1], str);
            jRadioButtonMenuItem.addActionListener(rowFormatListener);
            jMenu1.add(jRadioButtonMenuItem);
            str = null;
            jRadioButtonMenuItem = new JRadioButtonMenuItem(this.this$0.format_strs[b2][0]);
            if (tableAttr2 != null && tableAttr2.format == this.this$0.format_strs[b2][true]) {
              jRadioButtonMenuItem.setSelected(true);
            } else if (tableAttr2 != null && tableAttr2.format != null && this.this$0.format_strs[b2][true] != null && this.this$0.format_strs[b2][1].equals(tableAttr2.format)) {
              jRadioButtonMenuItem.setSelected(true);
              str = tableAttr2.format_spec;
            } 
            ColFormatListener colFormatListener = new ColFormatListener(this.this$0, tableXElement, point.x, this.this$0.format_strs[b2][1], str);
            jRadioButtonMenuItem.addActionListener(colFormatListener);
            jMenu2.add(jRadioButtonMenuItem);
          } 
          JMenu jMenu5 = new JMenu(Catalog.getString("Presenter"));
          jMenu1 = new JMenu(Catalog.getString("Row"));
          jMenu2 = new JMenu(Catalog.getString("Column"));
          jPopupMenu.add(jMenu5);
          jMenu5.add(jMenu2);
          jMenu5.add(jMenu1);
          for (byte b3 = 0; b3 < this.this$0.presenter_strs.length; b3++) {
            JRadioButtonMenuItem jRadioButtonMenuItem = new JRadioButtonMenuItem(this.this$0.presenter_strs[b3][0]);
            if (tableAttr1 != null && tableAttr1.presenter != null && this.this$0.presenter_strs[b3][0].equals(tableAttr1.presenter))
              jRadioButtonMenuItem.setSelected(true); 
            RowPresenterListener rowPresenterListener = new RowPresenterListener(this.this$0, tableXElement, point.y, this.this$0.presenter_strs[b3][1]);
            jRadioButtonMenuItem.addActionListener(rowPresenterListener);
            jMenu1.add(jRadioButtonMenuItem);
            jRadioButtonMenuItem = new JRadioButtonMenuItem(this.this$0.presenter_strs[b3][0]);
            if (tableAttr2 != null && tableAttr2.presenter != null && this.this$0.presenter_strs[b3][0].equals(tableAttr2.presenter))
              jRadioButtonMenuItem.setSelected(true); 
            ColPresenterListener colPresenterListener = new ColPresenterListener(this.this$0, tableXElement, point.x, this.this$0.presenter_strs[b3][1]);
            jRadioButtonMenuItem.addActionListener(colPresenterListener);
            jMenu2.add(jRadioButtonMenuItem);
          } 
          JMenu jMenu6 = new JMenu(Catalog.getString("Line Wrap"));
          JCheckBoxMenuItem jCheckBoxMenuItem1 = new JCheckBoxMenuItem(Catalog.getString("Row"));
          JCheckBoxMenuItem jCheckBoxMenuItem2 = new JCheckBoxMenuItem(Catalog.getString("Column"));
          jPopupMenu.add(jMenu6);
          jMenu6.add(jCheckBoxMenuItem2);
          jMenu6.add(jCheckBoxMenuItem1);
          jCheckBoxMenuItem2.setSelected((tableAttr2 == null || tableAttr2.linewrap == null || tableAttr2.linewrap.booleanValue()));
          jCheckBoxMenuItem2.addActionListener(new ColWrapListener(this.this$0, tableXElement, point.x));
          jCheckBoxMenuItem1.setSelected((tableAttr1 == null || tableAttr1.linewrap == null || tableAttr1.linewrap.booleanValue()));
          jCheckBoxMenuItem1.addActionListener(new RowWrapListener(this.this$0, tableXElement, point.y));
        } 
      } 
      return jPopupMenu;
    }
    
    private int findFrame(int param1Int1, int param1Int2) {
      int i = -1;
      for (int j = this.pageframes.length - 1; j >= 0; j--) {
        if (this.pageframes[j].contains(param1Int1, param1Int2) && (i < 0 || (this.pageframes[i].contains((this.pageframes[j]).x, (this.pageframes[j]).y) && this.pageframes[i].contains((this.pageframes[j]).x + (this.pageframes[j]).width, (this.pageframes[j]).y + (this.pageframes[j]).height))))
          i = j; 
      } 
      return i;
    }
    
    private boolean frameEquals(Rectangle param1Rectangle1, Rectangle param1Rectangle2) {
      if (param1Rectangle1.equals(param1Rectangle2))
        return true; 
      for (byte b = 0; b < this.pageframes.length; b++) {
        if (this.pageframes[b].equals(param1Rectangle1) || this.pageframes[b].equals(param1Rectangle2))
          return false; 
      } 
      return true;
    }
    
    private void paintBox(Graphics param1Graphics) {
      Color color = param1Graphics.getColor();
      param1Graphics.setColor(Color.black);
      for (byte b = 0; b < this.this$0.currlist.size(); b++) {
        for (byte b1 = 0; b1 < this.this$0.resizeBoxes.size(); b1++) {
          if (this.this$0.resizeBoxes.elementAt(b1).equals(this.this$0.currlist.elementAt(b)))
            break label22; 
        } 
        Vector vector = (Vector)this.elemmap.get(this.this$0.currlist.elementAt(b));
        if (vector != null) {
          byte b2;
          label22: for (b2 = 0; b2 < vector.size(); b2++) {
            Rectangle rectangle = (Rectangle)vector.elementAt(b2);
            Point point1 = new Point(rectangle.x - 1, rectangle.y - 1);
            Point point2 = new Point(rectangle.x + rectangle.width + 1, rectangle.y + rectangle.height + 1);
            int i = Math.min(Math.min(rectangle.width, rectangle.height) / 10, 5);
            i = Math.max(i, 2);
            param1Graphics.drawLine(point1.x, point1.y, point1.x + i, point1.y);
            param1Graphics.drawLine(point1.x, point1.y, point1.x, point1.y + i);
            param1Graphics.drawLine(point1.x, point2.y, point1.x + i, point2.y);
            param1Graphics.drawLine(point1.x, point2.y, point1.x, point2.y - i);
            param1Graphics.drawLine(point2.x, point1.y, point2.x - i, point1.y);
            param1Graphics.drawLine(point2.x, point1.y, point2.x, point1.y + i);
            param1Graphics.drawLine(point2.x, point2.y, point2.x - i, point2.y);
            param1Graphics.drawLine(point2.x, point2.y, point2.x, point2.y - i);
          } 
        } 
      } 
      paintResizeBoxes(param1Graphics);
      param1Graphics.setColor(color);
    }
    
    private void paintResizeBoxes(Graphics param1Graphics) {
      for (byte b = 0; b < this.this$0.resizeBoxes.size(); b++) {
        ResizeBox resizeBox = (ResizeBox)this.this$0.resizeBoxes.elementAt(b);
        if (resizeBox.page == this) {
          Rectangle rectangle = resizeBox.bounds;
          paintResizeBox(param1Graphics, rectangle);
        } 
      } 
    }
    
    private void paintResizeBox(Graphics param1Graphics, Rectangle param1Rectangle) {
      if (this.this$0.textmode)
        return; 
      param1Graphics.drawRect(param1Rectangle.x, param1Rectangle.y, param1Rectangle.width - 1, param1Rectangle.height - 1);
      if (param1Rectangle.width < 12 || param1Rectangle.height < 12)
        return; 
      int i = param1Rectangle.x + (param1Rectangle.width - 4) / 2;
      int j = param1Rectangle.y + (param1Rectangle.height - 4) / 2;
      param1Graphics.fillRect(i, param1Rectangle.y, 4, 4);
      param1Graphics.fillRect(param1Rectangle.x, param1Rectangle.y, 4, 4);
      if (param1Rectangle.height > 16)
        param1Graphics.fillRect(param1Rectangle.x, j, 4, 4); 
      param1Graphics.fillRect(param1Rectangle.x, param1Rectangle.y + param1Rectangle.height - 4, 4, 4);
      param1Graphics.fillRect(i, param1Rectangle.y + param1Rectangle.height - 4, 4, 4);
      param1Graphics.fillRect(param1Rectangle.x + param1Rectangle.width - 4, param1Rectangle.y + param1Rectangle.height - 4, 4, 4);
      if (param1Rectangle.height > 16)
        param1Graphics.fillRect(param1Rectangle.x + param1Rectangle.width - 4, j, 4, 4); 
      param1Graphics.fillRect(param1Rectangle.x + param1Rectangle.width - 4, param1Rectangle.y, 4, 4);
    }
    
    void showEditor(ReportElement param1ReportElement, boolean param1Boolean, Point param1Point, String param1String) {
      this.this$0.textEditor.stop();
      this.this$0.cellEditor.stop();
      Rectangle rectangle1 = null;
      Vector vector = (Vector)this.elemmap.get(param1ReportElement);
      if (param1Boolean || vector == null) {
        if (this.this$0.cursor == null)
          return; 
        rectangle1 = new Rectangle(this.this$0.cursor.x, this.this$0.cursor.y, 50, 16);
      } else {
        rectangle1 = new Rectangle(10000, 10000, 1, 1);
        for (byte b = 0; b < vector.size(); b++) {
          Rectangle rectangle = (Rectangle)vector.elementAt(b);
          rectangle1.x = Math.min(rectangle1.x, rectangle.x);
          rectangle1.y = Math.min(rectangle1.y, rectangle.y);
          rectangle1.width = Math.max(rectangle1.width, rectangle.x + rectangle.width);
          rectangle1.height = Math.max(rectangle1.height, rectangle.y + rectangle.height);
        } 
        rectangle1.width -= rectangle1.x;
        rectangle1.height -= rectangle1.y;
        rectangle1.width = Math.max(rectangle1.width, 12);
      } 
      add(this.this$0.textEditor);
      Rectangle rectangle2 = ((BaseElement)param1ReportElement).getFrame();
      this.this$0.editing = true;
      this.this$0.textEditor.setVisible(true);
      this.this$0.textEditor.setParam((TextBased)param1ReportElement, param1Boolean, rectangle1, (rectangle2 == null) ? getPrintBounds() : rectangle2, param1Point, param1String);
      this.this$0.textEditor.requestFocus();
      repaint(100L);
    }
    
    void showEditor(TableElementDef param1TableElementDef, int param1Int1, int param1Int2, TablePaintable param1TablePaintable, Point param1Point) {
      if (param1TableElementDef.getProperty("query") != null)
        return; 
      this.this$0.textEditor.stop();
      this.this$0.cellEditor.stop();
      add(this.this$0.cellEditor);
      this.this$0.editing = true;
      this.this$0.cellEditor.setVisible(true);
      this.this$0.cellEditor.setParam(param1TableElementDef, param1Int1, param1Int2, param1TablePaintable, param1Point);
      this.this$0.cellEditor.requestFocus();
      repaint(100L);
    }
    
    public String toString() { return Catalog.getString("Page") + " " + (this.pgnum + 1) + " [" + this.elemlist.size() + "]"; }
    
    Rectangle getPrintBounds() { return getPrintBounds(this.this$0.target); }
    
    Rectangle getPrintBounds(int param1Int) {
      switch (param1Int) {
        case 256:
          return this.this$0.sheet.getHeaderBounds(getPageSize(), this.resolution);
        case 0:
          return this.printBox;
        case 512:
          return this.this$0.sheet.getFooterBounds(getPageSize(), this.resolution);
      } 
      return null;
    }
    
    void rename(String param1String1, String param1String2) {
      Enumeration enumeration1 = this.elemmap.keys();
      while (enumeration1.hasMoreElements()) {
        ReportElement reportElement = (ReportElement)enumeration1.nextElement();
        if (reportElement.getID().equals(param1String1) || reportElement.getID().equals(param1String2)) {
          Object object = this.elemmap.get(reportElement);
          this.elemmap.remove(reportElement);
          reportElement.setID(param1String2);
          if (object != null)
            this.elemmap.put(reportElement, object); 
        } 
      } 
      enumeration1 = this.elempaintable.keys();
      Enumeration enumeration2 = this.elempaintable.elements();
      while (enumeration1.hasMoreElements()) {
        ReportElement reportElement = (ReportElement)enumeration1.nextElement();
        Object object = enumeration2.nextElement();
        if (reportElement.getID().equals(param1String1) || reportElement.getID().equals(param1String2)) {
          this.elempaintable.remove(reportElement);
          reportElement.setID(param1String2);
          this.elempaintable.put(reportElement, object);
        } 
      } 
    }
    
    private void addToListSorted(ReportElement param1ReportElement, Vector param1Vector) {
      Integer integer = (Integer)this.this$0.ordermap.get(param1ReportElement.getID());
      Hashtable hashtable = null;
      if (integer != null) {
        if (param1Vector == null)
          param1Vector = this.elemlist; 
        hashtable = this.this$0.ordermap;
      } else {
        integer = (Integer)this.this$0.hdrordermap.get(param1ReportElement.getID());
        if (integer != null) {
          if (param1Vector == null)
            param1Vector = this.headerlist; 
          hashtable = this.this$0.hdrordermap;
        } else {
          integer = (Integer)this.this$0.ftrordermap.get(param1ReportElement.getID());
          if (integer != null) {
            if (param1Vector == null)
              param1Vector = this.footerlist; 
            hashtable = this.this$0.ftrordermap;
          } 
        } 
      } 
      if (hashtable == null) {
        hashtable = this.this$0.ordermap;
        integer = new Integer(0);
      } 
      if (param1Vector != null) {
        int i = param1Vector.size() - 1;
        for (; i >= 0; i--) {
          ReportElement reportElement = (ReportElement)param1Vector.elementAt(i);
          Integer integer1 = (Integer)hashtable.get(reportElement.getID());
          if (integer1 == null || integer.intValue() >= integer1.intValue())
            break; 
        } 
        param1Vector.insertElementAt(param1ReportElement, i + 1);
      } else {
        this.elemlist.addElement(param1ReportElement);
      } 
    }
  }
  
  protected void setEnabled() {
    this.cutM.setEnabled(((!this.editArea && getCurrent() != null) || (this.editArea && this.currPage != null && this.currPage.getCurrentFrame() >= 0)));
    this.copyM.setEnabled((getCurrent() != null));
    this.pasteM.setEnabled(isPasteable());
    this.editM.setEnabled(getCurrent() instanceof TextBased);
    this.propertyM.setEnabled(((!this.editArea && getCurrent() != null) || (this.editArea && this.currPage != null && this.currPage.getCurrentFrame() >= 0)));
  }
  
  private void populateOrderMap(Hashtable paramHashtable, Vector paramVector) {
    paramHashtable.clear();
    for (byte b = 0; b < paramVector.size(); b++) {
      Object object = paramVector.elementAt(b);
      if (object instanceof Vector) {
        Vector vector = (Vector)object;
        for (byte b1 = 0; b1 < vector.size(); b1++)
          paramHashtable.put(((ReportElement)vector.elementAt(b1)).getID(), new Integer(b1)); 
      } else if (object instanceof FixedContainer) {
        FixedContainer fixedContainer = (FixedContainer)object;
        for (byte b1 = 0; b1 < fixedContainer.getElementCount(); b1++)
          paramHashtable.put(fixedContainer.getElement(b1).getID(), new Integer(b1)); 
      } 
    } 
  }
  
  public String toString() { return Catalog.getString("Report Template") + " [" + this.pages.size() + "]"; }
  
  public UndoMgr getUndoMgr() { return this.undoMgr; }
  
  static Object clipboard = null;
  
  protected XStyleSheet sheet;
  
  protected SectionInsertMenu sectionInsertM;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\DesignPane.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */