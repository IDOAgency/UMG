/*    */ package inetsoft.report.design;
/*    */ 
/*    */ import inetsoft.report.ReportElement;
/*    */ import inetsoft.report.internal.PainterElementDef;
/*    */ import inetsoft.report.locale.Catalog;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PainterProperty
/*    */   extends TextProperty
/*    */ {
/*    */   PainterElementDef elem;
/*    */   FixedPane fixed;
/*    */   
/*    */   public PainterProperty(DesignView paramDesignView) {
/* 35 */     super(paramDesignView, inetsoft.report.PainterElement.class);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 65 */     this.fixed = new FixedPane();
/*    */     setTitle(Catalog.getString("Painter Properties"));
/*    */     this.folder.insertTab(Catalog.getString("Layout"), null, this.fixed, Catalog.getString("Size and Wrapping"), 0);
/*    */   }
/*    */   
/*    */   public void setElement(ReportElement paramReportElement) {
/*    */     this.elem = (PainterElementDef)paramReportElement;
/*    */     super.setElement(paramReportElement);
/*    */     this.fixed.setElement(this.elem);
/*    */   }
/*    */   
/*    */   public boolean populateElement() {
/*    */     if (!super.populateElement())
/*    */       return false; 
/*    */     this.fixed.populateElement();
/*    */     return true;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\PainterProperty.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */