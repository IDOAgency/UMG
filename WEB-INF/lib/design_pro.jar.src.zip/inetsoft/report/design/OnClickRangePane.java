package inetsoft.report.design;

import inetsoft.report.TableElement;
import inetsoft.report.internal.j2d.NumField;
import inetsoft.report.locale.Catalog;
import inetsoft.widget.Grid2Layout;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.Vector;
import javax.swing.AbstractListModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

class OnClickRangePane extends JPanel {
  ItemListener rowListener;
  
  ItemListener colListener;
  
  ActionListener newListener;
  
  ActionListener updateListener;
  
  ActionListener deleteListener;
  
  JList rangeLT;
  
  RangeModel model;
  
  NumField rowTF;
  
  NumField colTF;
  
  JCheckBox allRowRB;
  
  JCheckBox allColRB;
  
  JCheckBox lastRowRB;
  
  JCheckBox lastColRB;
  
  JButton newB;
  
  JButton updateB;
  
  JButton deleteB;
  
  boolean changed;
  
  TableElement elem;
  
  public OnClickRangePane() {
    this.rowListener = new ItemListener(this) {
        private final OnClickRangePane this$0;
        
        public void itemStateChanged(ItemEvent param1ItemEvent) {
          if (((JCheckBox)param1ItemEvent.getSource()).isSelected())
            ((param1ItemEvent.getSource() == this.this$0.allRowRB) ? this.this$0.lastRowRB : this.this$0.allRowRB).setSelected(false); 
          this.this$0.setEnabled();
        }
      };
    this.colListener = new ItemListener(this) {
        private final OnClickRangePane this$0;
        
        public void itemStateChanged(ItemEvent param1ItemEvent) {
          if (((JCheckBox)param1ItemEvent.getSource()).isSelected())
            ((param1ItemEvent.getSource() == this.this$0.allColRB) ? this.this$0.lastColRB : this.this$0.allColRB).setSelected(false); 
          this.this$0.setEnabled();
        }
      };
    this.newListener = new ActionListener(this) {
        private final OnClickRangePane this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.model.add(this.this$0.getPoint()); }
      };
    this.updateListener = new ActionListener(this) {
        private final OnClickRangePane this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.model.setAt(this.this$0.getPoint(), this.this$0.rangeLT.getSelectedIndex()); }
      };
    this.deleteListener = new ActionListener(this) {
        private final OnClickRangePane this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          this.this$0.model.removeAt(this.this$0.rangeLT.getSelectedIndex());
          this.this$0.setEnabled();
        }
      };
    this.rangeLT = new JList();
    this.model = null;
    this.rowTF = new NumField(3, true);
    this.colTF = new NumField(3, true);
    this.allRowRB = new JCheckBox(Catalog.getString("All"));
    this.allColRB = new JCheckBox(Catalog.getString("All"));
    this.lastRowRB = new JCheckBox(Catalog.getString("Last"));
    this.lastColRB = new JCheckBox(Catalog.getString("Last"));
    this.newB = new JButton(Catalog.getString("New"));
    this.updateB = new JButton(Catalog.getString("Update"));
    this.deleteB = new JButton(Catalog.getString("Delete"));
    this.changed = false;
    setLayout(new BorderLayout(5, 5));
    JScrollPane jScrollPane = new JScrollPane(this.rangeLT);
    jScrollPane.setPreferredSize(new Dimension(100, 60));
    add(jScrollPane, "Center");
    add(new JLabel(Catalog.getString("Row") + " - " + Catalog.getString("Column")), "North");
    JPanel jPanel1 = new JPanel();
    jPanel1.setLayout(new BorderLayout());
    add(jPanel1, "East");
    JPanel jPanel2 = new JPanel();
    Grid2Layout grid2Layout = new Grid2Layout();
    jPanel2.setLayout(grid2Layout);
    jPanel2.add(new JLabel(Catalog.getString("Row") + ":", 4), grid2Layout.at(0, 0, 1, 1, 20));
    jPanel2.add(this.rowTF, grid2Layout.at(0, 1, 1, 1, 16));
    jPanel2.add(this.allRowRB, grid2Layout.at(0, 2, 1, 1, 16));
    jPanel2.add(this.lastRowRB, grid2Layout.at(0, 3, 1, 1, 16));
    jPanel2.add(new JLabel(Catalog.getString("Column") + ":", 4), grid2Layout.at(1, 0, 1, 1, 20));
    jPanel2.add(this.colTF, grid2Layout.at(1, 1, 1, 1, 16));
    jPanel2.add(this.allColRB, grid2Layout.at(1, 2, 1, 1, 16));
    jPanel2.add(this.lastColRB, grid2Layout.at(1, 3, 1, 1, 16));
    jPanel1.add(jPanel2, "Center");
    jPanel2 = new JPanel();
    jPanel2.add(this.newB);
    jPanel2.add(this.updateB);
    jPanel2.add(this.deleteB);
    jPanel1.add(jPanel2, "South");
    this.rangeLT.addListSelectionListener(new ListSelectionListener(this) {
          private final OnClickRangePane this$0;
          
          public void valueChanged(ListSelectionEvent param1ListSelectionEvent) {
            this.this$0.setEnabled();
            int i = this.this$0.rangeLT.getSelectedIndex();
            if (i < 0)
              return; 
            Point point = this.this$0.model.getAt(i);
            switch (point.x) {
              case -1:
                this.this$0.allColRB.setSelected(true);
                break;
              case 2147483647:
                this.this$0.lastColRB.setSelected(true);
                break;
              default:
                this.this$0.colTF.setValue(point.x);
                this.this$0.allColRB.setSelected(false);
                this.this$0.lastColRB.setSelected(false);
                break;
            } 
            switch (point.y) {
              case -1:
                this.this$0.allRowRB.setSelected(true);
                return;
              case 2147483647:
                this.this$0.lastRowRB.setSelected(true);
                return;
            } 
            this.this$0.rowTF.setValue(point.y);
            this.this$0.allRowRB.setSelected(false);
            this.this$0.lastRowRB.setSelected(false);
          }
        });
    this.allRowRB.addItemListener(this.rowListener);
    this.lastRowRB.addItemListener(this.rowListener);
    this.allColRB.addItemListener(this.colListener);
    this.lastColRB.addItemListener(this.colListener);
    this.newB.addActionListener(this.newListener);
    this.updateB.addActionListener(this.updateListener);
    this.deleteB.addActionListener(this.deleteListener);
    setEnabled();
  }
  
  public void setElement(TableElement paramTableElement) {
    this.elem = paramTableElement;
    this.rangeLT.setModel(this.model = new RangeModel(this, paramTableElement));
  }
  
  public boolean populateElement() {
    if (this.elem != null)
      this.elem.setOnClickRange(this.model.getRange()); 
    return true;
  }
  
  public boolean isChanged() { return this.changed; }
  
  public void setChanged(boolean paramBoolean) { this.changed = paramBoolean; }
  
  private void setEnabled() {
    this.updateB.setEnabled((this.rangeLT.getSelectedIndex() >= 0));
    this.deleteB.setEnabled((this.rangeLT.getSelectedIndex() >= 0));
    this.rowTF.setEnabled((!this.allRowRB.isSelected() && !this.lastRowRB.isSelected()));
    this.colTF.setEnabled((!this.allColRB.isSelected() && !this.lastColRB.isSelected()));
  }
  
  private Point getPoint() {
    Point point = new Point();
    if (this.allRowRB.isSelected()) {
      point.y = -1;
    } else if (this.lastRowRB.isSelected()) {
      point.y = Integer.MAX_VALUE;
    } else {
      point.y = this.rowTF.intValue();
    } 
    if (this.allColRB.isSelected()) {
      point.x = -1;
    } else if (this.lastColRB.isSelected()) {
      point.x = Integer.MAX_VALUE;
    } else {
      point.x = this.colTF.intValue();
    } 
    return point;
  }
  
  class RangeModel extends AbstractListModel {
    Vector ranges;
    
    private final OnClickRangePane this$0;
    
    public RangeModel(OnClickRangePane this$0, TableElement param1TableElement) {
      this.this$0 = this$0;
      this.ranges = new Vector();
      Point[] arrayOfPoint = param1TableElement.getOnClickRange();
      if (arrayOfPoint != null)
        for (byte b = 0; b < arrayOfPoint.length; b++)
          this.ranges.addElement(arrayOfPoint[b]);  
    }
    
    public void removeAt(int param1Int) {
      this.ranges.removeElementAt(param1Int);
      fireIntervalRemoved(this, param1Int, param1Int);
    }
    
    public void setAt(Point param1Point, int param1Int) {
      this.ranges.setElementAt(param1Point, param1Int);
      fireContentsChanged(this, param1Int, param1Int);
    }
    
    public Point getAt(int param1Int) { return (Point)this.ranges.elementAt(param1Int); }
    
    public void add(Point param1Point) {
      int i = this.ranges.size();
      this.ranges.addElement(param1Point);
      fireIntervalAdded(this, i, i);
    }
    
    public Point[] getRange() {
      if (this.ranges.size() > 0) {
        Point[] arrayOfPoint = new Point[this.ranges.size()];
        this.ranges.copyInto(arrayOfPoint);
        return arrayOfPoint;
      } 
      return null;
    }
    
    public int getSize() { return this.ranges.size(); }
    
    public Object getElementAt(int param1Int) {
      Point point = (Point)this.ranges.elementAt(param1Int);
      return toString(point.y) + " - " + toString(point.x);
    }
    
    private String toString(int param1Int) {
      switch (param1Int) {
        case -1:
          return "All";
        case 2147483647:
          return "Last";
      } 
      return Integer.toString(param1Int);
    }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\OnClickRangePane.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */