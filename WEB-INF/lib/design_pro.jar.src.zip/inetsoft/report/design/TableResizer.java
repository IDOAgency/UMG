/*     */ package inetsoft.report.design;
/*     */ 
/*     */ import inetsoft.report.Common;
/*     */ import inetsoft.report.internal.TableElementDef;
/*     */ import inetsoft.report.internal.TablePaintable;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Cursor;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class TableResizer
/*     */ {
/*     */   TableElementDef te;
/*     */   TablePaintable[] tables;
/*     */   int oloc;
/*     */   Integer loc;
/*     */   Point cell;
/*     */   int inside;
/*     */   boolean resized;
/*     */   boolean atResize;
/*     */   Cursor resizeCursor;
/*     */   Cursor defaultCursor;
/*     */   
/*     */   public TableResizer(Vector paramVector) {
/* 153 */     this.oloc = 0;
/* 154 */     this.loc = null;
/* 155 */     this.cell = null;
/* 156 */     this.inside = -1;
/* 157 */     this.resized = false;
/* 158 */     this.atResize = false;
/* 159 */     this.resizeCursor = new Cursor(11);
/* 160 */     this.defaultCursor = new Cursor(0);
/*     */     this.tables = new TablePaintable[paramVector.size()];
/*     */     paramVector.copyInto(this.tables);
/*     */     this.te = (TableElementDef)this.tables[0].getElement();
/*     */   }
/*     */   
/*     */   public boolean isResized() { return this.resized; }
/*     */   
/*     */   public boolean isAtResizeLocation() { return this.atResize; }
/*     */   
/*     */   public boolean isResizing() { return (this.loc != null); }
/*     */   
/*     */   public void processMouseEvent(MouseEvent paramMouseEvent) {
/*     */     if (paramMouseEvent.getID() == 503) {
/*     */       this.inside = -1;
/*     */       for (byte b = 0; b < this.tables.length; b++) {
/*     */         Rectangle rectangle = this.tables[b].getBounds();
/*     */         rectangle.width += 2;
/*     */         rectangle.height += 2;
/*     */         if (rectangle.contains(paramMouseEvent.getX(), paramMouseEvent.getY())) {
/*     */           this.inside = b;
/*     */           break;
/*     */         } 
/*     */       } 
/*     */       if (this.inside < 0)
/*     */         return; 
/*     */     } 
/*     */     Component component = (Component)paramMouseEvent.getSource();
/*     */     if (paramMouseEvent.getID() == 501) {
/*     */       if (this.cell != null) {
/*     */         this.oloc = paramMouseEvent.getX();
/*     */         this.loc = new Integer(this.oloc);
/*     */       } 
/*     */     } else if (paramMouseEvent.getID() == 506) {
/*     */       if (this.cell != null)
/*     */         this.loc = new Integer(paramMouseEvent.getX()); 
/*     */     } else if (paramMouseEvent.getID() == 503) {
/*     */       if ((this.cell = this.tables[this.inside].locateBorder(paramMouseEvent.getX(), paramMouseEvent.getY())) != null && this.cell.x >= 0) {
/*     */         component.setCursor(this.resizeCursor);
/*     */         this.atResize = true;
/*     */       } else {
/*     */         this.cell = null;
/*     */         component.setCursor(this.defaultCursor);
/*     */         this.atResize = false;
/*     */       } 
/*     */     } else if (paramMouseEvent.getID() == 502 && this.loc != null && this.cell != null) {
/*     */       int[] arrayOfInt = this.te.getFixedWidths();
/*     */       int i = this.loc.intValue() - this.oloc;
/*     */       if (arrayOfInt == null) {
/*     */         arrayOfInt = new int[this.te.getTable().getColCount()];
/*     */         for (byte b = 0; b < arrayOfInt.length; b++)
/*     */           arrayOfInt[b] = (int)this.te.getColWidth(b); 
/*     */       } 
/*     */       arrayOfInt[this.cell.x] = arrayOfInt[this.cell.x] + i;
/*     */       if (this.cell.x < arrayOfInt.length - 1)
/*     */         arrayOfInt[this.cell.x + 1] = arrayOfInt[this.cell.x + 1] - i; 
/*     */       this.te.setFixedWidths(arrayOfInt);
/*     */       this.te.setLayout(0);
/*     */       this.loc = null;
/*     */       this.cell = null;
/*     */       this.resized = true;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void paint(Graphics paramGraphics) {
/*     */     if (this.loc != null && this.inside >= 0) {
/*     */       Rectangle rectangle = this.tables[this.inside].getBounds();
/*     */       paramGraphics.setColor(Color.black);
/*     */       Common.drawVLine(paramGraphics, this.loc.intValue(), rectangle.y, (rectangle.y + rectangle.height), 4113, 0, 0);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\TableResizer.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */