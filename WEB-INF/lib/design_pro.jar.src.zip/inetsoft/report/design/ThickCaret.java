/*    */ package inetsoft.report.design;
/*    */ 
/*    */ import java.awt.Graphics;
/*    */ import java.awt.Rectangle;
/*    */ import javax.swing.plaf.TextUI;
/*    */ import javax.swing.text.BadLocationException;
/*    */ import javax.swing.text.DefaultCaret;
/*    */ import javax.swing.text.Position;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ThickCaret
/*    */   extends DefaultCaret
/*    */ {
/* 28 */   public ThickCaret() { setBlinkRate(500); }
/*    */ 
/*    */   
/*    */   public void paint(Graphics paramGraphics) {
/* 32 */     if (isVisible())
/*    */       try {
/* 34 */         TextUI textUI = getComponent().getUI();
/* 35 */         Rectangle rectangle = textUI.modelToView(getComponent(), getDot(), Position.Bias.Forward);
/*    */         
/* 37 */         paramGraphics.setColor(getComponent().getCaretColor());
/* 38 */         paramGraphics.drawLine(rectangle.x, rectangle.y, rectangle.x, rectangle.y + rectangle.height - 1);
/* 39 */         paramGraphics.drawLine(rectangle.x + 1, rectangle.y, rectangle.x + 1, rectangle.y + rectangle.height - 1);
/* 40 */       } catch (BadLocationException badLocationException) {} 
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\ThickCaret.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */