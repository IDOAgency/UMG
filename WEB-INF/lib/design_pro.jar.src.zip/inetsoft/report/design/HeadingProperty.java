/*    */ package inetsoft.report.design;
/*    */ 
/*    */ import inetsoft.report.ReportElement;
/*    */ import inetsoft.report.internal.HeadingElementDef;
/*    */ import inetsoft.report.internal.j2d.NumField;
/*    */ import inetsoft.report.internal.j2d.Property2Panel;
/*    */ import inetsoft.report.locale.Catalog;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HeadingProperty
/*    */   extends TextProperty
/*    */ {
/*    */   HeadingElementDef elem;
/*    */   NumField level;
/*    */   
/*    */   public HeadingProperty(DesignView paramDesignView) {
/* 36 */     super(paramDesignView, inetsoft.report.HeadingElement.class);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 71 */     this.level = new NumField(3, true);
/*    */     setTitle(Catalog.getString("Heading Properties"));
/*    */     Property2Panel property2Panel = new Property2Panel();
/*    */     property2Panel.add(Catalog.getString("Heading"), new Object[][] { { Catalog.getString("Level") + ":", this.level } });
/*    */     this.folder.addTab(Catalog.getString("Heading"), null, property2Panel, Catalog.getString("Heading Level"));
/*    */   }
/*    */   
/*    */   public void setElement(ReportElement paramReportElement) {
/*    */     super.setElement(paramReportElement);
/*    */     this.elem = (HeadingElementDef)paramReportElement;
/*    */     this.level.setValue(this.elem.getLevel());
/*    */   }
/*    */   
/*    */   public boolean populateElement() {
/*    */     if (!super.populateElement())
/*    */       return false; 
/*    */     this.elem.setLevel(this.level.intValue());
/*    */     return true;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\HeadingProperty.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */