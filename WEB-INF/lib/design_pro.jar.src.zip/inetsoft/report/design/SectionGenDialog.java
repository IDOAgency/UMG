/*     */ package inetsoft.report.design;
/*     */ 
/*     */ import inetsoft.report.internal.SectionXElement;
/*     */ import inetsoft.report.internal.j2d.NumField;
/*     */ import inetsoft.report.locale.Catalog;
/*     */ import inetsoft.widget.Grid2Layout;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.FlowLayout;
/*     */ import java.awt.Insets;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.util.Vector;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTabbedPane;
/*     */ import javax.swing.JTextField;
/*     */ 
/*     */ 
/*     */ class SectionGenDialog
/*     */   extends JDialog
/*     */ {
/*     */   ActionListener moreListener;
/*     */   ActionListener okListener;
/*     */   ActionListener cancelListener;
/*     */   JButton moreB;
/*     */   JButton okB;
/*     */   JButton cancelB;
/*     */   JScrollPane paneCR;
/*     */   
/*     */   public static boolean show(DesignFrame paramDesignFrame, SectionXElement paramSectionXElement) {
/*  36 */     SectionGenDialog sectionGenDialog = new SectionGenDialog(paramDesignFrame, paramSectionXElement);
/*  37 */     sectionGenDialog.pack();
/*  38 */     sectionGenDialog.setVisible(true);
/*     */     
/*  40 */     return sectionGenDialog.ok;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   JPanel pane;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Grid2Layout layout;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Vector cols;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Vector widths;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   SectionOptionPane optionPane;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean ok;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   SectionXElement section;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SectionGenDialog(DesignFrame paramDesignFrame, SectionXElement paramSectionXElement) {
/*  85 */     this.moreListener = new ActionListener(this) { private final SectionGenDialog this$0;
/*     */         public void actionPerformed(ActionEvent param1ActionEvent) {
/*  87 */           int i = this.this$0.cols.size() + 1;
/*  88 */           JTextField jTextField = new JTextField(10);
/*  89 */           SectionGenDialog$2 sectionGenDialog$2 = new SectionGenDialog$2(this, 3, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 107 */           this.this$0.pane.add(jTextField, this.this$0.layout.at(i, 0));
/* 108 */           this.this$0.pane.add(sectionGenDialog$2, this.this$0.layout.at(i, 1));
/*     */           
/* 110 */           this.this$0.cols.addElement(jTextField);
/* 111 */           this.this$0.widths.addElement(sectionGenDialog$2);
/*     */           
/* 113 */           if (this.this$0.paneCR != null) {
/* 114 */             this.this$0.paneCR.validate();
/* 115 */             this.this$0.paneCR.getViewport().scrollRectToVisible(sectionGenDialog$2.getBounds());
/*     */           } 
/*     */           
/* 118 */           jTextField.requestFocus();
/*     */         } }
/*     */       ;
/*     */     
/* 122 */     this.okListener = new ActionListener(this) {
/*     */         public void actionPerformed(ActionEvent param1ActionEvent) {
/* 124 */           Vector vector = new Vector();
/*     */           
/* 126 */           for (byte b = 0; b < this.this$0.cols.size(); b++) {
/* 127 */             JTextField jTextField = (JTextField)this.this$0.cols.elementAt(b);
/* 128 */             NumField numField = (NumField)this.this$0.widths.elementAt(b);
/*     */             
/* 130 */             if (jTextField.getText().length() > 0) {
/* 131 */               String[] arrayOfString = new String[2];
/* 132 */               arrayOfString[0] = jTextField.getText();
/* 133 */               arrayOfString[1] = this.this$0.getString(numField.intValue());
/*     */               
/* 135 */               vector.addElement(arrayOfString);
/*     */             } 
/*     */           } 
/*     */           
/* 139 */           if (vector.size() > 0) {
/* 140 */             this.this$0.section.setTable(new SectionGenDialog$4(this, vector));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 149 */             this.this$0.ok = true;
/*     */           } 
/*     */           
/*     */           try {
/* 153 */             this.this$0.optionPane.process();
/*     */           } catch (Exception exception) {
/* 155 */             JOptionPane.showMessageDialog(null, exception.toString());
/*     */           } 
/*     */           
/* 158 */           this.this$0.section.setTable(null);
/*     */           
/* 160 */           this.this$0.dispose();
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         private final SectionGenDialog this$0;
/*     */       };
/* 174 */     this.cancelListener = new ActionListener(this) { private final SectionGenDialog this$0;
/*     */         
/* 176 */         public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.dispose(); }
/*     */          }
/*     */       ;
/*     */     
/* 180 */     this.moreB = new JButton(Catalog.getString("More"));
/* 181 */     this.okB = new JButton(Catalog.getString("OK"));
/* 182 */     this.cancelB = new JButton(Catalog.getString("Cancel"));
/*     */ 
/*     */     
/* 185 */     this.pane = new JPanel();
/* 186 */     this.layout = new Grid2Layout(new Insets(2, 5, 2, 5));
/* 187 */     this.cols = new Vector();
/* 188 */     this.widths = new Vector();
/*     */ 
/*     */ 
/*     */     
/* 192 */     this.ok = false;
/*     */     setModal(true);
/*     */     this.section = paramSectionXElement;
/*     */     this.pane.setLayout(this.layout);
/*     */     this.pane.add(new JLabel("Column Name"), this.layout.at(0, 0));
/*     */     this.pane.add(new JLabel("Column Width"), this.layout.at(0, 1));
/*     */     this.moreListener.actionPerformed(null);
/*     */     JPanel jPanel1 = new JPanel();
/*     */     jPanel1.setLayout(new BorderLayout());
/*     */     jPanel1.add(this.pane, "North");
/*     */     this.paneCR = new JScrollPane(jPanel1);
/*     */     JTabbedPane jTabbedPane = new JTabbedPane();
/*     */     jTabbedPane.setPreferredSize(new Dimension(300, 200));
/*     */     jTabbedPane.add(this.paneCR, Catalog.getString("Fields"));
/*     */     this.optionPane = new SectionOptionPane(paramSectionXElement, paramDesignFrame);
/*     */     jTabbedPane.add(this.optionPane, Catalog.getString("Options"));
/*     */     getContentPane().add(jTabbedPane, "Center");
/*     */     JPanel jPanel2 = new JPanel();
/*     */     jPanel2.setLayout(new FlowLayout());
/*     */     jPanel2.add(this.moreB);
/*     */     jPanel2.add(this.okB);
/*     */     jPanel2.add(this.cancelB);
/*     */     getContentPane().add(jPanel2, "South");
/*     */     this.moreB.addActionListener(this.moreListener);
/*     */     this.okB.addActionListener(this.okListener);
/*     */     this.cancelB.addActionListener(this.cancelListener);
/*     */   }
/*     */   
/*     */   private String getString(int paramInt) {
/*     */     StringBuffer stringBuffer = new StringBuffer();
/*     */     for (byte b = 0; b < paramInt; b++)
/*     */       stringBuffer.append('X'); 
/*     */     return stringBuffer.toString();
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\SectionGenDialog.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */