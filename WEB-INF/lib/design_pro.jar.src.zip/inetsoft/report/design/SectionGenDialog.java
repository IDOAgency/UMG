package inetsoft.report.design;

import inetsoft.report.internal.SectionXElement;
import inetsoft.report.internal.j2d.NumField;
import inetsoft.report.locale.Catalog;
import inetsoft.widget.Grid2Layout;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;

class SectionGenDialog extends JDialog {
  ActionListener moreListener;
  
  ActionListener okListener;
  
  ActionListener cancelListener;
  
  JButton moreB;
  
  JButton okB;
  
  JButton cancelB;
  
  JScrollPane paneCR;
  
  JPanel pane;
  
  Grid2Layout layout;
  
  Vector cols;
  
  Vector widths;
  
  SectionOptionPane optionPane;
  
  boolean ok;
  
  SectionXElement section;
  
  public static boolean show(DesignFrame paramDesignFrame, SectionXElement paramSectionXElement) {
    SectionGenDialog sectionGenDialog = new SectionGenDialog(paramDesignFrame, paramSectionXElement);
    sectionGenDialog.pack();
    sectionGenDialog.setVisible(true);
    return sectionGenDialog.ok;
  }
  
  public SectionGenDialog(DesignFrame paramDesignFrame, SectionXElement paramSectionXElement) {
    this.moreListener = new ActionListener(this) {
        private final SectionGenDialog this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          int i = this.this$0.cols.size() + 1;
          JTextField jTextField = new JTextField(10);
          SectionGenDialog$2 sectionGenDialog$2 = new SectionGenDialog$2(this, 3, true);
          this.this$0.pane.add(jTextField, this.this$0.layout.at(i, 0));
          this.this$0.pane.add(sectionGenDialog$2, this.this$0.layout.at(i, 1));
          this.this$0.cols.addElement(jTextField);
          this.this$0.widths.addElement(sectionGenDialog$2);
          if (this.this$0.paneCR != null) {
            this.this$0.paneCR.validate();
            this.this$0.paneCR.getViewport().scrollRectToVisible(sectionGenDialog$2.getBounds());
          } 
          jTextField.requestFocus();
        }
      };
    this.okListener = new ActionListener(this) {
        private final SectionGenDialog this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          Vector vector = new Vector();
          for (byte b = 0; b < this.this$0.cols.size(); b++) {
            JTextField jTextField = (JTextField)this.this$0.cols.elementAt(b);
            NumField numField = (NumField)this.this$0.widths.elementAt(b);
            if (jTextField.getText().length() > 0) {
              String[] arrayOfString = new String[2];
              arrayOfString[0] = jTextField.getText();
              arrayOfString[1] = this.this$0.getString(numField.intValue());
              vector.addElement(arrayOfString);
            } 
          } 
          if (vector.size() > 0) {
            this.this$0.section.setTable(new SectionGenDialog$4(this, vector));
            this.this$0.ok = true;
          } 
          try {
            this.this$0.optionPane.process();
          } catch (Exception exception) {
            JOptionPane.showMessageDialog(null, exception.toString());
          } 
          this.this$0.section.setTable(null);
          this.this$0.dispose();
        }
      };
    this.cancelListener = new ActionListener(this) {
        private final SectionGenDialog this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.dispose(); }
      };
    this.moreB = new JButton(Catalog.getString("More"));
    this.okB = new JButton(Catalog.getString("OK"));
    this.cancelB = new JButton(Catalog.getString("Cancel"));
    this.pane = new JPanel();
    this.layout = new Grid2Layout(new Insets(2, 5, 2, 5));
    this.cols = new Vector();
    this.widths = new Vector();
    this.ok = false;
    setModal(true);
    this.section = paramSectionXElement;
    this.pane.setLayout(this.layout);
    this.pane.add(new JLabel("Column Name"), this.layout.at(0, 0));
    this.pane.add(new JLabel("Column Width"), this.layout.at(0, 1));
    this.moreListener.actionPerformed(null);
    JPanel jPanel1 = new JPanel();
    jPanel1.setLayout(new BorderLayout());
    jPanel1.add(this.pane, "North");
    this.paneCR = new JScrollPane(jPanel1);
    JTabbedPane jTabbedPane = new JTabbedPane();
    jTabbedPane.setPreferredSize(new Dimension(300, 200));
    jTabbedPane.add(this.paneCR, Catalog.getString("Fields"));
    this.optionPane = new SectionOptionPane(paramSectionXElement, paramDesignFrame);
    jTabbedPane.add(this.optionPane, Catalog.getString("Options"));
    getContentPane().add(jTabbedPane, "Center");
    JPanel jPanel2 = new JPanel();
    jPanel2.setLayout(new FlowLayout());
    jPanel2.add(this.moreB);
    jPanel2.add(this.okB);
    jPanel2.add(this.cancelB);
    getContentPane().add(jPanel2, "South");
    this.moreB.addActionListener(this.moreListener);
    this.okB.addActionListener(this.okListener);
    this.cancelB.addActionListener(this.cancelListener);
  }
  
  private String getString(int paramInt) {
    StringBuffer stringBuffer = new StringBuffer();
    for (byte b = 0; b < paramInt; b++)
      stringBuffer.append('X'); 
    return stringBuffer.toString();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\SectionGenDialog.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */