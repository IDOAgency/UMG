package inetsoft.report.design;

import inetsoft.report.ReportElement;
import inetsoft.report.Size;
import inetsoft.report.StyleSheet;
import java.awt.Font;
import java.awt.Point;
import javax.swing.JPopupMenu;

public interface DesignView {
  public static final int H_SPACING = 256;
  
  public static final int V_SPACING = 512;
  
  StyleSheet getStyleSheet();
  
  void setPageWidth(double paramDouble);
  
  double getPageWidth();
  
  void setPageHeight(double paramDouble);
  
  double getPageHeight();
  
  void setPageSize(Size paramSize);
  
  void setOrientation(int paramInt);
  
  int getOrientation();
  
  void setPageResolution(int paramInt);
  
  int getPageResolution();
  
  void setShowGrid(boolean paramBoolean);
  
  boolean isShowGrid();
  
  void setShowRuler(boolean paramBoolean);
  
  boolean isShowRuler();
  
  void setCurrentFont(Font paramFont);
  
  void setCurrentAlignment(int paramInt);
  
  void setCurrentJustify(boolean paramBoolean);
  
  void align(int paramInt);
  
  void distribute(int paramInt);
  
  void changeSizes(int paramInt1, int paramInt2);
  
  void setTextMode(boolean paramBoolean);
  
  boolean isTextMode();
  
  int getUndoCount();
  
  void undo();
  
  void setEditArea(boolean paramBoolean);
  
  void setEditArea(String paramString);
  
  boolean isEditArea();
  
  void setTarget(int paramInt);
  
  int getTarget();
  
  void print(StyleSheet paramStyleSheet);
  
  boolean isChanged();
  
  void setChanged(boolean paramBoolean);
  
  UndoMgr getUndoMgr();
  
  void insertTable(int paramInt1, int paramInt2, boolean paramBoolean);
  
  void insertText(boolean paramBoolean);
  
  void insertTextBox(boolean paramBoolean);
  
  void insertSection(boolean paramBoolean);
  
  void insertChart(int paramInt, boolean paramBoolean);
  
  void insertImage(boolean paramBoolean);
  
  void insertPainter(boolean paramBoolean);
  
  void insertContainer(boolean paramBoolean);
  
  void insertTOC(boolean paramBoolean);
  
  void insertHeading(int paramInt, boolean paramBoolean);
  
  void insertSeparator(boolean paramBoolean);
  
  void insertBullet(boolean paramBoolean);
  
  void insertTab(boolean paramBoolean);
  
  void insertLinefeed(boolean paramBoolean);
  
  void insertBreak(boolean paramBoolean);
  
  void insertSpace(boolean paramBoolean);
  
  void insertPageBreak(boolean paramBoolean);
  
  void insertCondPageBreak(boolean paramBoolean);
  
  void insertAreaBreak(boolean paramBoolean);
  
  void insertArea(boolean paramBoolean);
  
  void insert(ReportElement paramReportElement, boolean paramBoolean);
  
  void copy();
  
  void cut();
  
  void paste();
  
  boolean isPasteable();
  
  void orderAreas(boolean paramBoolean);
  
  void setColumns(int paramInt);
  
  ReportElement getCurrent();
  
  ReportElement[] getSelectedElements();
  
  void setSelectedElements(ReportElement[] paramArrayOfReportElement);
  
  boolean isAlignable();
  
  boolean isDistributable();
  
  DesignPane.DesignPage getCurrentPage();
  
  JPopupMenu getPopupMenu(Point paramPoint);
  
  void showProperty();
  
  void showPageNumber(int paramInt);
  
  void showPageSize(Size paramSize);
  
  void showStatus(String paramString);
  
  void reprint(ReportElement paramReportElement);
  
  int getPageCount();
  
  ReportElement getElement(String paramString);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\DesignView.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */