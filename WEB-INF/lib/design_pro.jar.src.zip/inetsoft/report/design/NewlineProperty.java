/*    */ package inetsoft.report.design;
/*    */ 
/*    */ import inetsoft.report.ReportElement;
/*    */ import inetsoft.report.internal.NewlineElementDef;
/*    */ import inetsoft.report.internal.j2d.NumField;
/*    */ import inetsoft.report.internal.j2d.Property2Panel;
/*    */ import inetsoft.report.locale.Catalog;
/*    */ import java.awt.Font;
/*    */ import javax.swing.ButtonGroup;
/*    */ import javax.swing.JRadioButton;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NewlineProperty
/*    */   extends PropertyDialog
/*    */ {
/*    */   NewlineElementDef elem;
/*    */   NumField num;
/*    */   NumField points;
/*    */   JRadioButton linefeed;
/*    */   JRadioButton newline;
/*    */   
/*    */   public NewlineProperty(DesignView paramDesignView) {
/* 36 */     super(paramDesignView);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 88 */     this.num = new NumField(5, true);
/* 89 */     this.points = new NumField(3, true);
/* 90 */     this.linefeed = new JRadioButton(Catalog.getString("Break"));
/* 91 */     this.newline = new JRadioButton(Catalog.getString("Newline"));
/*    */     setTitle(Catalog.getString("Newline Properties"));
/*    */     Property2Panel property2Panel = new Property2Panel();
/*    */     property2Panel.add(Catalog.getString("Newline"), new Object[][] { { Catalog.getString("Number of Newlines") + ":", this.num }, { Catalog.getString("Newline Size") + ":", this.points, Catalog.getString("points") } });
/*    */     property2Panel.add(Catalog.getString("Newline/Break"), new Object[][] { { this.newline, this.linefeed } });
/*    */     this.folder.addTab(Catalog.getString("Newline"), null, property2Panel, Catalog.getString("Newlines"));
/*    */     ButtonGroup buttonGroup = new ButtonGroup();
/*    */     buttonGroup.add(this.linefeed);
/*    */     buttonGroup.add(this.newline);
/*    */   }
/*    */   
/*    */   public void setElement(ReportElement paramReportElement) {
/*    */     this.elem = (NewlineElementDef)paramReportElement;
/*    */     super.setElement(paramReportElement);
/*    */     this.num.setValue(this.elem.getCount());
/*    */     this.points.setValue(this.elem.getFont().getSize());
/*    */     this.linefeed.setSelected(this.elem.isBreak());
/*    */     this.newline.setSelected(!this.linefeed.isSelected());
/*    */   }
/*    */   
/*    */   public boolean populateElement() {
/*    */     if (!super.populateElement())
/*    */       return false; 
/*    */     this.elem.setCount(this.num.intValue());
/*    */     this.elem.setFont(new Font("Dialog", 0, this.points.intValue()));
/*    */     this.elem.setBreak(this.linefeed.isSelected());
/*    */     return true;
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\NewlineProperty.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */