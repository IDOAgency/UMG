/*    */ package inetsoft.report.design;
/*    */ 
/*    */ import inetsoft.report.internal.TableXElement;
/*    */ import inetsoft.report.locale.Catalog;
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.awt.event.ActionListener;
/*    */ import javax.swing.JMenuItem;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class RowFormatListener
/*    */   implements ActionListener
/*    */ {
/*    */   DesignPane pane;
/*    */   TableXElement xtable;
/*    */   int index;
/*    */   String format;
/*    */   String spec;
/*    */   
/*    */   public RowFormatListener(DesignPane paramDesignPane, TableXElement paramTableXElement, int paramInt, String paramString1, String paramString2) {
/* 80 */     this.pane = paramDesignPane;
/* 81 */     this.xtable = paramTableXElement;
/* 82 */     this.index = paramInt;
/* 83 */     this.format = paramString1;
/* 84 */     this.spec = paramString2;
/*    */   }
/*    */   
/*    */   public void actionPerformed(ActionEvent paramActionEvent) {
/* 88 */     if (((JMenuItem)paramActionEvent.getSource()).isSelected()) {
/* 89 */       if (this.format != null && (this.format.equals("DateFormat") || this.format.equals("DecimalFormat")))
/*    */       {
/* 91 */         this.spec = InputDialog.show(Catalog.getString("Format") + ":", this.spec);
/*    */       }
/*    */       
/* 94 */       this.xtable.setRowFormat(this.index, this.format, (this.spec != null && this.spec.length() > 0) ? this.spec : null);
/*    */       
/* 96 */       this.pane.reprint(this.xtable);
/* 97 */       this.pane.setChanged(true);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\RowFormatListener.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */