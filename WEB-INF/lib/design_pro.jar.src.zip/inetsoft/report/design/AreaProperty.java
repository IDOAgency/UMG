/*     */ package inetsoft.report.design;
/*     */ 
/*     */ import inetsoft.report.PageArea;
/*     */ import inetsoft.report.internal.j2d.NumField;
/*     */ import inetsoft.report.internal.j2d.Property2Panel;
/*     */ import inetsoft.report.locale.Catalog;
/*     */ import inetsoft.widget.ColorComboBox;
/*     */ import java.awt.Insets;
/*     */ import java.awt.event.ItemEvent;
/*     */ import java.awt.event.ItemListener;
/*     */ import javax.swing.JCheckBox;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AreaProperty
/*     */   extends PropertyDialog
/*     */ {
/*     */   PageArea area;
/*     */   LineCombo line;
/*     */   NumField top;
/*     */   NumField left;
/*     */   NumField bottom;
/*     */   NumField right;
/*     */   NumField x;
/*     */   NumField y;
/*     */   NumField width;
/*     */   NumField height;
/*     */   ColorComboBox bcolor;
/*     */   JCheckBox flow;
/*     */   JCheckBox repeat;
/*     */   
/*     */   public AreaProperty(DesignView paramDesignView) {
/*  37 */     super(paramDesignView);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 112 */     this.line = new LineCombo(true);
/* 113 */     this.top = new NumField(3, true);
/* 114 */     this.left = new NumField(3, true);
/* 115 */     this.bottom = new NumField(3, true);
/* 116 */     this.right = new NumField(3, true);
/* 117 */     this.x = new NumField(3, false);
/* 118 */     this.y = new NumField(3, false);
/* 119 */     this.width = new NumField(3, false);
/* 120 */     this.height = new NumField(3, false);
/* 121 */     this.bcolor = new ColorComboBox();
/* 122 */     this.flow = new JCheckBox(Catalog.getString("Flow Area"));
/* 123 */     this.repeat = new JCheckBox(Catalog.getString("Repeat Contents"));
/*     */     setTitle(Catalog.getString("Area Properties"));
/*     */     Property2Panel property2Panel = new Property2Panel();
/*     */     property2Panel.add(Catalog.getString("Border"), new Object[][] { { Catalog.getString("Line") + ":", this.line, Catalog.getString("Color") + ":", this.bcolor } });
/*     */     property2Panel.add(Catalog.getString("Bounds"), new Object[][] { { Catalog.getString("X") + "\":", this.x, Catalog.getString("Y") + "\":", this.y, Catalog.getString("Width") + "\":", this.width, Catalog.getString("Height") + "\":", this.height }, { this.flow, null, null, this.repeat, null, null } });
/*     */     property2Panel.add(Catalog.getString("Padding Space"), new Object[][] { { Catalog.getString("Top") + ":", this.top, Catalog.getString("Left") + ":", this.left, Catalog.getString("Bottom") + ":", this.bottom, Catalog.getString("Right") + ":", this.right } });
/*     */     this.folder.addTab(Catalog.getString("Area"), null, property2Panel, Catalog.getString("Area"));
/*     */     this.flow.addItemListener(new ItemListener(this) {
/*     */           private final AreaProperty this$0;
/*     */           
/*     */           public void itemStateChanged(ItemEvent param1ItemEvent) { this.this$0.repeat.setEnabled(!this.this$0.flow.isSelected()); }
/*     */         });
/*     */   }
/*     */   
/*     */   public void setElement(PageArea paramPageArea) {
/*     */     this.area = paramPageArea;
/*     */     setElement(null);
/*     */     this.line.setSelectedLineStyle(this.area.getBorder());
/*     */     Insets insets = paramPageArea.getInsets();
/*     */     this.top.setValue(insets.top);
/*     */     this.left.setValue(insets.left);
/*     */     this.bottom.setValue(insets.bottom);
/*     */     this.right.setValue(insets.right);
/*     */     this.x.setValue(paramPageArea.x);
/*     */     this.y.setValue(paramPageArea.y);
/*     */     this.width.setValue(paramPageArea.width);
/*     */     this.height.setValue(paramPageArea.height);
/*     */     this.bcolor.setSelectedColor(paramPageArea.getBorderColor());
/*     */     this.flow.setSelected(paramPageArea.isFlow());
/*     */     this.repeat.setSelected(paramPageArea.isRepeat());
/*     */   }
/*     */   
/*     */   public boolean populateElement() {
/*     */     this.area.setBorder(this.line.getSelectedLineStyle());
/*     */     Insets insets = new Insets(this.top.intValue(), this.left.intValue(), this.bottom.intValue(), this.right.intValue());
/*     */     this.area.setInsets(insets);
/*     */     this.area.x = this.x.doubleValue();
/*     */     this.area.y = this.y.doubleValue();
/*     */     this.area.width = this.width.doubleValue();
/*     */     this.area.height = this.height.doubleValue();
/*     */     this.area.setBorderColor(this.bcolor.getSelectedColor());
/*     */     this.area.setFlow(this.flow.isSelected());
/*     */     this.area.setRepeat(this.repeat.isSelected());
/*     */     return true;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\AreaProperty.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */