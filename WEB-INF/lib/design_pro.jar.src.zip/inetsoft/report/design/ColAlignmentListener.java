/*    */ package inetsoft.report.design;
/*    */ 
/*    */ import inetsoft.report.internal.TableXElement;
/*    */ import java.awt.event.ActionEvent;
/*    */ import java.awt.event.ActionListener;
/*    */ import javax.swing.JMenuItem;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ColAlignmentListener
/*    */   implements ActionListener
/*    */ {
/*    */   DesignPane pane;
/*    */   TableXElement xtable;
/*    */   int index;
/*    */   int align;
/*    */   
/*    */   public ColAlignmentListener(DesignPane paramDesignPane, TableXElement paramTableXElement, int paramInt1, int paramInt2) {
/* 56 */     this.pane = paramDesignPane;
/* 57 */     this.xtable = paramTableXElement;
/* 58 */     this.index = paramInt1;
/* 59 */     this.align = paramInt2;
/*    */   }
/*    */   
/*    */   public void actionPerformed(ActionEvent paramActionEvent) {
/* 63 */     if (((JMenuItem)paramActionEvent.getSource()).isSelected()) {
/* 64 */       this.xtable.setColAlignment(this.index, this.align);
/* 65 */       this.pane.reprint(this.xtable);
/* 66 */       this.pane.setChanged(true);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\ColAlignmentListener.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */