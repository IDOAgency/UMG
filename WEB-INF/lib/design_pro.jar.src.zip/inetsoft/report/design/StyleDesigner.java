package inetsoft.report.design;

import inetsoft.report.Common;
import inetsoft.report.Margin;
import inetsoft.report.StyleSheet;
import inetsoft.report.internal.j2d.Common2D;
import inetsoft.report.internal.j2d.Property2Panel;
import inetsoft.report.lens.DefaultTableLens;
import inetsoft.report.locale.Catalog;
import inetsoft.report.style.XTableStyle;
import inetsoft.widget.ColorComboBox;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FileDialog;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JToolBar;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

public class StyleDesigner extends JPanel {
  ActionListener newListener;
  
  ActionListener openListener;
  
  ActionListener saveListener;
  
  ActionListener saveAsListener;
  
  ActionListener resetListener;
  
  XTableStyle style;
  
  String oname;
  
  JPanel mainPane;
  
  TableView table;
  
  Image top_border;
  
  Image left_border;
  
  Image bottom_border;
  
  Image right_border;
  
  DefaultTableLens model;
  
  Object[][] table_data;
  
  JPanel folder;
  
  CardLayout folder_layout;
  
  BorderPane top_border_pnl;
  
  BorderPane left_border_pnl;
  
  BorderPane bottom_border_pnl;
  
  BorderPane right_border_pnl;
  
  HeaderPane header_row_pnl;
  
  HeaderPane header_col_pnl;
  
  HeaderPane trailer_row_pnl;
  
  HeaderPane trailer_col_pnl;
  
  BodyPane body_pnl;
  
  JTextField name;
  
  String filename;
  
  boolean changed;
  
  boolean ok;
  
  private StyleDesigner() {
    this.newListener = new ActionListener(this) {
        private final StyleDesigner this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          this.this$0.filename = null;
          this.this$0.style.clear();
          this.this$0.refresh();
        }
      };
    this.openListener = new ActionListener(this) {
        private final StyleDesigner this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          FileDialog fileDialog = new FileDialog(new Frame(), Catalog.getString("Open Style"), 0);
          fileDialog.setVisible(true);
          if (fileDialog.getFile() != null)
            try {
              this.this$0.style.parse(new FileInputStream(fileDialog.getDirectory() + fileDialog.getFile()));
              this.this$0.refresh();
            } catch (Exception exception) {
              exception.printStackTrace();
              JOptionPane.showMessageDialog(null, exception.toString(), Catalog.getString("Error"), 0);
            }  
        }
      };
    this.saveListener = new ActionListener(this) {
        private final StyleDesigner this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          if (this.this$0.filename == null) {
            this.this$0.saveAsListener.actionPerformed(param1ActionEvent);
          } else {
            try {
              FileOutputStream fileOutputStream = new FileOutputStream(this.this$0.filename);
              this.this$0.style.export(fileOutputStream);
              this.this$0.changed = false;
              fileOutputStream.close();
            } catch (Exception exception) {
              exception.printStackTrace();
              JOptionPane.showMessageDialog(null, exception.toString(), Catalog.getString("Error"), 0);
            } 
          } 
        }
      };
    this.saveAsListener = new ActionListener(this) {
        private final StyleDesigner this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          FileDialog fileDialog = new FileDialog(new Frame(), Catalog.getString("Save Style"), 1);
          fileDialog.setVisible(true);
          if (fileDialog.getFile() != null) {
            this.this$0.filename = fileDialog.getDirectory() + fileDialog.getFile();
            this.this$0.saveListener.actionPerformed(null);
          } 
        }
      };
    this.resetListener = new ActionListener(this) {
        private final StyleDesigner this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          this.this$0.style.clear();
          this.this$0.refresh();
        }
      };
    this.oname = "";
    this.mainPane = new JPanel();
    this.table_data = new Object[][] { { "Region", "1st Qtr", "2nd Qtr", "Total" }, { "East", "$200", "$300", "$500" }, { "Central", "$60", "$50", "$110" }, { "West", "$180", "$400", "$580" }, { "Total", "$440", "$750", "$1190" } };
    this.folder = new JPanel();
    this.name = new JTextField(15);
    this.changed = false;
    this.ok = false;
    setLayout(new BorderLayout());
    try {
      this.top_border = Common.getImage(this, "images/top-border.gif");
      this.left_border = Common.getImage(this, "images/left-border.gif");
      this.bottom_border = Common.getImage(this, "images/bottom-border.gif");
      this.right_border = Common.getImage(this, "images/right-border.gif");
      MediaTracker mediaTracker = new MediaTracker(this);
      mediaTracker.addImage(this.top_border, 0);
      mediaTracker.addImage(this.left_border, 0);
      mediaTracker.addImage(this.bottom_border, 0);
      mediaTracker.addImage(this.right_border, 0);
      mediaTracker.waitForAll();
    } catch (Exception exception) {
      exception.printStackTrace();
      JOptionPane.showMessageDialog(null, exception.toString(), Catalog.getString("Error"), 0);
      System.exit(1);
    } 
    JPanel jPanel1 = new JPanel();
    jPanel1.setBackground(Color.white);
    jPanel1.setLayout(new BorderLayout());
    ImageCanvas imageCanvas;
    jPanel1.add(imageCanvas = new ImageCanvas(this, this.top_border), "North");
    imageCanvas.addMouseListener(new FolderListener(this, "Top border"));
    jPanel1.add(imageCanvas = new ImageCanvas(this, this.left_border), "West");
    imageCanvas.addMouseListener(new FolderListener(this, "Left border"));
    jPanel1.add(imageCanvas = new ImageCanvas(this, this.bottom_border), "South");
    imageCanvas.addMouseListener(new FolderListener(this, "Bottom border"));
    jPanel1.add(imageCanvas = new ImageCanvas(this, this.right_border), "East");
    imageCanvas.addMouseListener(new FolderListener(this, "Right border"));
    this.model = new DefaultTableLens();
    this.model.setData(this.table_data);
    this.model.setHeaderRowCount(1);
    this.model.setHeaderColCount(1);
    this.style = new XTableStyle(this.model);
    jPanel1.add(this.table = new TableView(5.0D), "Center");
    this.table.setTable(this.style);
    this.table.addMouseListener(new MouseAdapter(this) {
          private final StyleDesigner this$0;
          
          public void mousePressed(MouseEvent param1MouseEvent) {
            Point point = this.this$0.table.locateCell(param1MouseEvent.getX(), param1MouseEvent.getY());
            if (point != null) {
              String str = null;
              if (point.y == 0) {
                this.this$0.folder_layout.show(this.this$0.folder, str = "Header row");
              } else if (point.x == 0) {
                this.this$0.folder_layout.show(this.this$0.folder, str = "Header column");
              } else if (point.y == this.this$0.model.getRowCount() - 1) {
                this.this$0.folder_layout.show(this.this$0.folder, str = "Trailer row");
              } else if (point.x == this.this$0.model.getColCount() - 1) {
                this.this$0.folder_layout.show(this.this$0.folder, str = "Trailer column");
              } else {
                this.this$0.folder_layout.show(this.this$0.folder, str = "Body");
              } 
            } 
          }
        });
    this.mainPane.setBackground(Color.white);
    this.mainPane.add(jPanel1);
    add(this.mainPane, "Center");
    JPanel jPanel2 = new JPanel();
    JPanel jPanel3 = new JPanel();
    jPanel2.setLayout(new BorderLayout(10, 10));
    jPanel3.setLayout(new FlowLayout(0, 10, 10));
    jPanel3.add(new JLabel(Catalog.getString("Name") + ": "));
    jPanel3.add(this.name);
    jPanel2.add(jPanel3, "North");
    jPanel2.add(this.folder, "Center");
    add(jPanel2, "North");
    this.name.setText("XTableStyle");
    this.name.getDocument().addDocumentListener(new DocumentListener(this) {
          private final StyleDesigner this$0;
          
          public void insertUpdate(DocumentEvent param1DocumentEvent) { this.this$0.style.setName(this.this$0.name.getText()); }
          
          public void removeUpdate(DocumentEvent param1DocumentEvent) { insertUpdate(param1DocumentEvent); }
          
          public void changedUpdate(DocumentEvent param1DocumentEvent) {}
        });
    this.folder.setLayout(this.folder_layout = new CardLayout(5, 5));
    this.folder.add(this.top_border_pnl = new BorderPane(this, Catalog.getString("Top Border"), "top-border"), "Top border");
    this.folder.add(this.left_border_pnl = new BorderPane(this, Catalog.getString("Left Border"), "left-border"), "Left border");
    this.folder.add(this.bottom_border_pnl = new BorderPane(this, Catalog.getString("Bottom Border"), "bottom-border"), "Bottom border");
    this.folder.add(this.right_border_pnl = new BorderPane(this, Catalog.getString("Right Border"), "right-border"), "Right border");
    this.folder.add(this.header_row_pnl = new HeaderPane(this, Catalog.getString("Header Row"), "header-row"), "Header row");
    this.folder.add(this.header_col_pnl = new HeaderPane(this, Catalog.getString("Header Column"), "header-col"), "Header column");
    this.folder.add(this.trailer_row_pnl = new HeaderPane(this, Catalog.getString("Trailer Row"), "trailer-row"), "Trailer row");
    this.folder.add(this.trailer_col_pnl = new HeaderPane(this, Catalog.getString("Trailer column"), "trailer-col"), "Trailer column");
    this.folder.add(this.body_pnl = new BodyPane(this, Catalog.getString("Body")), "Body");
    this.folder_layout.show(this.folder, "Body");
  }
  
  private JDialog createDialog(Frame paramFrame) {
    JDialog jDialog = new JDialog(paramFrame, true);
    jDialog.getContentPane().setLayout(new BorderLayout());
    if (isMain) {
      JToolBar jToolBar = new JToolBar();
      JButton jButton;
      jToolBar.add(jButton = Common2D.createToolButton(this, "images/new.gif"));
      jButton.setToolTipText(Catalog.getString("New style"));
      jButton.addActionListener(this.newListener);
      jToolBar.add(jButton = Common2D.createToolButton(this, "images/open.gif"));
      jButton.setToolTipText(Catalog.getString("Open style file"));
      jButton.addActionListener(this.openListener);
      jToolBar.add(jButton = Common2D.createToolButton(this, "images/save.gif"));
      jButton.setToolTipText(Catalog.getString("Save style file"));
      jButton.addActionListener(this.saveListener);
      jDialog.getContentPane().add(jToolBar, "North");
    } 
    jDialog.addWindowListener(new WindowAdapter(this) {
          private final StyleDesigner this$0;
          
          public void windowClosing(WindowEvent param1WindowEvent) { this.this$0.quit(); }
        });
    if (isMain) {
      JMenuBar jMenuBar = new JMenuBar();
      JMenu jMenu1 = new JMenu(Catalog.getString("File"));
      jMenuBar.add(jMenu1);
      JMenuItem jMenuItem;
      jMenu1.add(jMenuItem = new JMenuItem(Catalog.getString("New")));
      jMenuItem.setMnemonic('N');
      jMenuItem.addActionListener(this.newListener);
      jMenu1.add(jMenuItem = new JMenuItem(Catalog.getString("Open")));
      jMenuItem.setMnemonic('O');
      jMenuItem.addActionListener(this.openListener);
      jMenu1.addSeparator();
      jMenu1.add(jMenuItem = new JMenuItem(Catalog.getString("Save")));
      jMenuItem.setMnemonic('S');
      jMenuItem.addActionListener(this.saveListener);
      jMenu1.add(jMenuItem = new JMenuItem(Catalog.getString("Save As")));
      jMenuItem.setMnemonic('A');
      jMenuItem.addActionListener(this.saveAsListener);
      jMenu1.addSeparator();
      jMenu1.add(jMenuItem = new JMenuItem(Catalog.getString("Exit")));
      jMenuItem.setMnemonic('x');
      jMenuItem.addActionListener(new ActionListener(this) {
            private final StyleDesigner this$0;
            
            public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.quit(); }
          });
      JMenu jMenu2 = new JMenu(Catalog.getString("Edit"));
      jMenuBar.add(jMenu2);
      jMenu2.add(jMenuItem = new JMenuItem(Catalog.getString("Clear All")));
      jMenuItem.setMnemonic('C');
      jMenuItem.addActionListener(this.resetListener);
      jDialog.setJMenuBar(jMenuBar);
    } 
    if (!isMain) {
      JPanel jPanel = new JPanel();
      jPanel.setLayout(new FlowLayout(1, 20, 5));
      JButton jButton;
      jPanel.add(jButton = new JButton(Catalog.getString("OK")));
      jButton.addActionListener(new ActionListener(this, jDialog) {
            private final JDialog val$dialog;
            
            private final StyleDesigner this$0;
            
            public void actionPerformed(ActionEvent param1ActionEvent) {
              String str = this.this$0.name.getText();
              if (str.length() == 0) {
                JOptionPane.showMessageDialog(null, Catalog.getString("Style name must be specified!"));
                return;
              } 
              if (!this.this$0.oname.equals(str) && StyleTree.get(str) != null)
                switch (JOptionPane.showConfirmDialog(null, Catalog.getString("Style exists, overwrite?"))) {
                  case 1:
                  case 2:
                    return;
                }  
              this.this$0.ok = true;
              this.val$dialog.dispose();
            }
          });
      jPanel.add(jButton = new JButton(Catalog.getString("Reset")));
      jButton.addActionListener(this.resetListener);
      jPanel.add(jButton = new JButton(Catalog.getString("Cancel")));
      jButton.addActionListener(new ActionListener(this, jDialog) {
            private final JDialog val$dialog;
            
            private final StyleDesigner this$0;
            
            public void actionPerformed(ActionEvent param1ActionEvent) {
              this.this$0.ok = false;
              this.val$dialog.dispose();
            }
          });
      jDialog.getContentPane().add(jPanel, "South");
    } 
    return jDialog;
  }
  
  public void setStyle(String paramString) {
    this.filename = paramString;
    try {
      FileInputStream fileInputStream = new FileInputStream(paramString);
      this.style.parse(fileInputStream);
      fileInputStream.close();
      refresh();
    } catch (Exception exception) {
      exception.printStackTrace();
      JOptionPane.showMessageDialog(null, exception.toString(), Catalog.getString("Error"), 0);
    } 
  }
  
  public void setStyle(XTableStyle paramXTableStyle) {
    this.style = paramXTableStyle;
    this.oname = paramXTableStyle.getName();
    paramXTableStyle.setTable(this.model);
    this.table.setTable(paramXTableStyle);
    refresh();
  }
  
  public XTableStyle getStyle() { return this.style; }
  
  public void refresh() {
    this.top_border_pnl.refresh();
    this.left_border_pnl.refresh();
    this.bottom_border_pnl.refresh();
    this.right_border_pnl.refresh();
    this.header_row_pnl.refresh();
    this.header_col_pnl.refresh();
    this.trailer_row_pnl.refresh();
    this.trailer_col_pnl.refresh();
    this.body_pnl.refresh();
    this.name.setText(this.style.getName());
    validate();
    this.table.reprint();
    this.table.repaint(100L);
  }
  
  public void quit() {
    if (this.changed)
      switch (JOptionPane.showConfirmDialog(new Frame(), exitMsg)) {
        case 0:
          this.saveListener.actionPerformed(null);
          break;
        case 2:
          return;
      }  
    if (isMain)
      System.exit(0); 
  }
  
  public void setAttribute(String paramString, Object paramObject) {
    this.style.put(paramString, paramObject);
    this.changed = true;
    this.table.reprint();
    this.table.repaint(100L);
    validate();
  }
  
  public Object getAttribute(String paramString) { return this.style.get(paramString); }
  
  public static XTableStyle show(Frame paramFrame, XTableStyle paramXTableStyle) {
    StyleDesigner styleDesigner = new StyleDesigner();
    dialog = styleDesigner.createDialog(paramFrame);
    dialog.getContentPane().add(styleDesigner, "Center");
    if (paramXTableStyle != null)
      styleDesigner.setStyle((XTableStyle)paramXTableStyle.clone()); 
    dialog.pack();
    dialog.setVisible(true);
    return styleDesigner.ok ? styleDesigner.getStyle() : null;
  }
  
  public static void main(String[] paramArrayOfString) {
    isMain = true;
    Common2D.setLookAndFeel();
    StyleSheet.setPrinterMargin(new Margin());
    StyleDesigner styleDesigner = new StyleDesigner();
    dialog = styleDesigner.createDialog(new Frame());
    dialog.getContentPane().add(styleDesigner, "Center");
    if (paramArrayOfString.length == 1)
      styleDesigner.setStyle(paramArrayOfString[0]); 
    dialog.pack();
    dialog.setVisible(true);
  }
  
  public static void pack() { dialog.pack(); }
  
  class FolderListener extends MouseAdapter {
    private String name;
    
    private final StyleDesigner this$0;
    
    public FolderListener(StyleDesigner this$0, String param1String) {
      this.this$0 = this$0;
      this.name = param1String;
    }
    
    public void mousePressed(MouseEvent param1MouseEvent) { this.this$0.folder_layout.show(this.this$0.folder, this.name); }
  }
  
  class ImageCanvas extends Component {
    private Image image;
    
    private final StyleDesigner this$0;
    
    public ImageCanvas(StyleDesigner this$0, Image param1Image) {
      this.this$0 = this$0;
      this.image = param1Image;
    }
    
    public Dimension getPreferredSize() { return new Dimension(this.image.getWidth(null), this.image.getHeight(null)); }
    
    public void paint(Graphics param1Graphics) {
      Dimension dimension = getSize();
      int i = (dimension.width - this.image.getWidth(null)) / 2;
      int j = (dimension.height - this.image.getHeight(null)) / 2;
      param1Graphics.drawImage(this.image, i, j, this);
    }
  }
  
  class ColorCanvas extends ColorComboBox {
    private final StyleDesigner this$0;
    
    public ColorCanvas(StyleDesigner this$0, String param1String, Color param1Color) {
      this.this$0 = this$0;
      setSelectedColor(param1Color);
      addActionListener(new StyleDesigner$7(this, param1String));
    }
  }
  
  class BorderPane extends Property2Panel {
    LineCombo line_style;
    
    StyleDesigner.ColorCanvas color_canvas;
    
    String border;
    
    private final StyleDesigner this$0;
    
    public BorderPane(StyleDesigner this$0, String param1String1, String param1String2) {
      this.this$0 = this$0;
      this.border = param1String2;
      this.line_style = new LineCombo(false);
      Color color = (Color)this$0.getAttribute(this.border + ".color");
      this.color_canvas = new StyleDesigner.ColorCanvas(this$0, this.border + ".color", color);
      add(param1String1, new Object[][] { { Catalog.getString("BorderStyle") + ":", this.line_style }, { Catalog.getString("Color") + ":", this.color_canvas } });
      this.line_style.addItemListener(new StyleDesigner$8(this));
      refresh();
    }
    
    public void refresh() {
      Object object = this.this$0.getAttribute(this.border + ".border");
      if (object != null) {
        this.line_style.setSelectedLineStyle(((Integer)object).intValue());
      } else {
        this.line_style.setSelectedLineStyle(-1);
      } 
      this.color_canvas.setSelectedColor((Color)this.this$0.getAttribute(this.border + ".color"));
    }
  }
  
  class HeaderPane extends Property2Panel {
    LineCombo line_style;
    
    StyleDesigner.ColorCanvas border_color;
    
    StyleDesigner.ColorCanvas fg_canvas;
    
    StyleDesigner.ColorCanvas bg_canvas;
    
    FontCanvas font_canvas;
    
    AlignCombo align_combo;
    
    String header;
    
    private final StyleDesigner this$0;
    
    public HeaderPane(StyleDesigner this$0, String param1String1, String param1String2) {
      this.this$0 = this$0;
      this.header = param1String2;
      this.line_style = new LineCombo(false);
      Color color = (Color)this$0.getAttribute(this.header + ".bcolor");
      this.border_color = new StyleDesigner.ColorCanvas(this$0, this.header + ".bcolor", color);
      this.line_style.addItemListener(new StyleDesigner$9(this));
      color = (Color)this$0.getAttribute(this.header + ".foreground");
      this.fg_canvas = new StyleDesigner.ColorCanvas(this$0, this.header + ".foreground", color);
      color = (Color)this$0.getAttribute(this.header + ".background");
      this.bg_canvas = new StyleDesigner.ColorCanvas(this$0, this.header + ".background", color);
      Font font = (Font)this$0.getAttribute(this.header + ".font");
      this.font_canvas = new FontCanvas(font);
      this.font_canvas.addActionListener(new StyleDesigner.FontListener(this$0, this.header + ".font"));
      Integer integer = (Integer)this$0.getAttribute(this.header + ".alignment");
      this.align_combo = new AlignCombo(3, (integer == null) ? 0 : integer.intValue());
      this.align_combo.addItemListener(new StyleDesigner.AlignListener(this$0, this.header + ".alignment"));
      add(param1String1, new Object[][] { { Catalog.getString("Border Style") + ":", this.line_style, Catalog.getString("Color") + ":", this.border_color }, { Catalog.getString("Foreground") + ":", this.fg_canvas, Catalog.getString("Background") + ":", this.bg_canvas }, { Catalog.getString("Font") + ":", this.font_canvas, Catalog.getString("Alignment") + ":", this.align_combo } });
      refresh();
    }
    
    public void refresh() {
      Object object = this.this$0.getAttribute(this.header + ".border");
      if (object != null) {
        this.line_style.setSelectedLineStyle(((Integer)object).intValue());
      } else {
        this.line_style.setSelectedLineStyle(-1);
      } 
      this.border_color.setSelectedColor((Color)this.this$0.getAttribute(this.header + ".bcolor"));
      this.fg_canvas.setSelectedColor((Color)this.this$0.getAttribute(this.header + ".foreground"));
      this.bg_canvas.setSelectedColor((Color)this.this$0.getAttribute(this.header + ".background"));
      this.font_canvas.setDisplayFont((Font)this.this$0.getAttribute(this.header + ".font"));
      this.align_combo.selectOption((Integer)this.this$0.getAttribute(this.header + ".alignment"));
    }
  }
  
  class BodyPane extends Property2Panel {
    String header;
    
    LineCombo row_border;
    
    LineCombo col_border;
    
    StyleDesigner.ColorCanvas rcolor_canvas;
    
    StyleDesigner.ColorCanvas ccolor_canvas;
    
    StyleDesigner.ColorCanvas fg_canvas;
    
    StyleDesigner.ColorCanvas bg_canvas;
    
    FontCanvas font_canvas;
    
    AlignCombo align_combo;
    
    private final StyleDesigner this$0;
    
    public BodyPane(StyleDesigner this$0, String param1String) {
      this.this$0 = this$0;
      this.header = "body";
      this.row_border = new LineCombo(false);
      this.row_border.addItemListener(new StyleDesigner$10(this));
      Color color = (Color)this$0.getAttribute(this.header + ".rcolor");
      this.rcolor_canvas = new StyleDesigner.ColorCanvas(this$0, this.header + ".rcolor", color);
      this.col_border = new LineCombo(false);
      this.col_border.addItemListener(new StyleDesigner$11(this));
      color = (Color)this$0.getAttribute(this.header + ".ccolor");
      this.ccolor_canvas = new StyleDesigner.ColorCanvas(this$0, this.header + ".ccolor", color);
      color = (Color)this$0.getAttribute(this.header + ".foreground");
      this.fg_canvas = new StyleDesigner.ColorCanvas(this$0, this.header + ".foreground", color);
      color = (Color)this$0.getAttribute(this.header + ".background");
      this.bg_canvas = new StyleDesigner.ColorCanvas(this$0, this.header + ".background", color);
      Font font = (Font)this$0.getAttribute(this.header + ".font");
      this.font_canvas = new FontCanvas(font);
      this.font_canvas.addActionListener(new StyleDesigner.FontListener(this$0, this.header + ".font"));
      Integer integer = (Integer)this$0.getAttribute(this.header + ".alignment");
      this.align_combo = new AlignCombo(3, (integer == null) ? 0 : integer.intValue());
      this.align_combo.addItemListener(new StyleDesigner.AlignListener(this$0, this.header + ".alignment"));
      add(param1String, new Object[][] { { Catalog.getString("Row Border") + ":", this.row_border, Catalog.getString("Row Border Color") + ":", this.rcolor_canvas }, { Catalog.getString("Column Border") + ":", this.col_border, Catalog.getString("Column Border Color") + ":", this.ccolor_canvas }, { Catalog.getString("Foreground") + ":", this.fg_canvas, Catalog.getString("Background") + ":", this.bg_canvas }, { Catalog.getString("Font") + ":", this.font_canvas, Catalog.getString("Alignment") + ":", this.align_combo } });
    }
    
    public void refresh() {
      Object object = this.this$0.getAttribute(this.header + ".row-border");
      if (object != null) {
        this.row_border.setSelectedLineStyle(((Integer)object).intValue());
      } else {
        this.row_border.setSelectedLineStyle(-1);
      } 
      object = this.this$0.getAttribute(this.header + ".col-border");
      if (object != null) {
        this.col_border.setSelectedLineStyle(((Integer)object).intValue());
      } else {
        this.col_border.setSelectedLineStyle(-1);
      } 
      this.rcolor_canvas.setSelectedColor((Color)this.this$0.getAttribute(this.header + ".rcolor"));
      this.ccolor_canvas.setSelectedColor((Color)this.this$0.getAttribute(this.header + ".ccolor"));
      this.fg_canvas.setSelectedColor((Color)this.this$0.getAttribute(this.header + ".foreground"));
      this.bg_canvas.setSelectedColor((Color)this.this$0.getAttribute(this.header + ".background"));
      this.font_canvas.setDisplayFont((Font)this.this$0.getAttribute(this.header + ".font"));
      this.align_combo.selectOption((Integer)this.this$0.getAttribute(this.header + ".alignment"));
    }
  }
  
  class AlignListener implements ItemListener {
    private String attr;
    
    private final StyleDesigner this$0;
    
    public AlignListener(StyleDesigner this$0, String param1String) {
      this.this$0 = this$0;
      this.attr = param1String;
    }
    
    public void itemStateChanged(ItemEvent param1ItemEvent) { this.this$0.setAttribute(this.attr, new Integer(((AlignCombo)param1ItemEvent.getSource()).getSelectedOption())); }
  }
  
  class FontListener implements ActionListener {
    private String attr;
    
    private final StyleDesigner this$0;
    
    public FontListener(StyleDesigner this$0, String param1String) {
      this.this$0 = this$0;
      this.attr = param1String;
    }
    
    public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.setAttribute(this.attr, ((FontCanvas)param1ActionEvent.getSource()).getDisplayFont()); }
  }
  
  static boolean isMain = false;
  
  static JDialog dialog;
  
  class SpaceHolder extends Component {
    private final StyleDesigner this$0;
    
    SpaceHolder(StyleDesigner this$0) { this.this$0 = this$0; }
  }
  
  static String exitMsg = Catalog.getString("Unsaved changes. Save before closing?");
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\StyleDesigner.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */