/*     */ package inetsoft.report.design;
/*     */ 
/*     */ import inetsoft.report.Position;
/*     */ import inetsoft.report.Size;
/*     */ import inetsoft.report.internal.PainterElementDef;
/*     */ import inetsoft.report.internal.j2d.NumField;
/*     */ import inetsoft.report.internal.j2d.Property2Panel;
/*     */ import inetsoft.report.locale.Catalog;
/*     */ import java.awt.Insets;
/*     */ import java.awt.event.ItemEvent;
/*     */ import java.awt.event.ItemListener;
/*     */ import java.net.URL;
/*     */ import javax.swing.ButtonGroup;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JRadioButton;
/*     */ import javax.swing.JToggleButton;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FixedPane
/*     */   extends Property2Panel
/*     */ {
/*     */   public FixedPane() {
/*  38 */     URL uRL = getClass().getResource("images/nowrap.gif");
/*  39 */     this.nowrap = new JToggleButton(new ImageIcon(uRL));
/*  40 */     this.nowrap.setBorderPainted(true);
/*     */     
/*  42 */     uRL = getClass().getResource("images/lwrap.gif");
/*  43 */     this.lwrap = new JToggleButton(new ImageIcon(uRL));
/*     */     
/*  45 */     uRL = getClass().getResource("images/rwrap.gif");
/*  46 */     this.rwrap = new JToggleButton(new ImageIcon(uRL));
/*     */     
/*  48 */     uRL = getClass().getResource("images/bothwrap.gif");
/*  49 */     this.bothwrap = new JToggleButton(new ImageIcon(uRL));
/*     */     
/*  51 */     uRL = getClass().getResource("images/tbwrap.gif");
/*  52 */     this.tbwrap = new JToggleButton(new ImageIcon(uRL));
/*     */     
/*  54 */     this.wrapGroup.add(this.nowrap);
/*  55 */     this.wrapGroup.add(this.lwrap);
/*  56 */     this.wrapGroup.add(this.rwrap);
/*  57 */     this.wrapGroup.add(this.bothwrap);
/*  58 */     this.wrapGroup.add(this.tbwrap);
/*     */     
/*  60 */     this.anchorGroup.add(this.leftA);
/*  61 */     this.anchorGroup.add(this.rightA);
/*     */     
/*  63 */     this.breakable = new JRadioButton(Catalog.getString("Breakable"));
/*  64 */     this.nobreak = new JRadioButton(Catalog.getString("Non-break"));
/*  65 */     this.layoutGroup.add(this.breakable);
/*  66 */     this.layoutGroup.add(this.nobreak);
/*     */     
/*  68 */     add(Catalog.getString("Size"), new Object[][] { { Catalog.getString("Width") + "\":", this.width, Catalog.getString("Height") + "\":", this.height } });
/*     */ 
/*     */     
/*  71 */     add(Catalog.getString("Margin"), new Object[][] { { Catalog.getString("Top") + ":", this.top, Catalog.getString("Left") + ":", this.left, Catalog.getString("Bottom") + ":", this.bottom, Catalog.getString("Right") + ":", this.right } });
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  76 */     add(Catalog.getString("Wrapping"), new Object[][] { { this.nowrap, this.lwrap, this.rwrap, this.bothwrap, this.tbwrap } });
/*     */     
/*  78 */     add(Catalog.getString("Pagenation"), new Object[][] { { this.breakable, this.nobreak } });
/*     */     
/*  80 */     add(Catalog.getString("Anchor"), new Object[][] { { this.anchored }, { Catalog.getString("X") + "\"", this.anchorx, { this.leftA, this.rightA } }, { Catalog.getString("Y") + "\"", this.anchory } });
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  85 */     this.anchored.addItemListener(new ItemListener(this) { private final FixedPane this$0;
/*     */           
/*  87 */           public void itemStateChanged(ItemEvent param1ItemEvent) { this.this$0.setEnable(); } }
/*     */       );
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setElement(PainterElementDef paramPainterElementDef) {
/*  96 */     this.elem = paramPainterElementDef;
/*     */     
/*  98 */     Position position = paramPainterElementDef.getAnchor();
/*  99 */     this.anchored.setSelected((position != null));
/* 100 */     this.leftA.setSelected((position == null || position.x >= 0.0F));
/* 101 */     this.rightA.setSelected(!this.leftA.isSelected());
/* 102 */     this.anchorx.setValue((position == null) ? 0.0F : position.x);
/* 103 */     this.anchory.setValue((position == null) ? 0.0F : position.y);
/*     */     
/* 105 */     this.width.setText((paramPainterElementDef.getSize() == null) ? "" : Double.toString((paramPainterElementDef.getSize()).width));
/*     */     
/* 107 */     this.height.setText((paramPainterElementDef.getSize() == null) ? "" : Double.toString((paramPainterElementDef.getSize()).height));
/*     */ 
/*     */     
/* 110 */     switch (paramPainterElementDef.getLayout()) {
/*     */       case 1:
/* 112 */         this.breakable.setSelected(true);
/*     */         break;
/*     */       case 0:
/* 115 */         this.nobreak.setSelected(true);
/*     */         break;
/*     */     } 
/*     */     
/* 119 */     switch (paramPainterElementDef.getWrapping()) {
/*     */       case 0:
/* 121 */         this.nowrap.setSelected(true);
/*     */         break;
/*     */       case 1:
/* 124 */         this.lwrap.setSelected(true);
/*     */         break;
/*     */       case 2:
/* 127 */         this.rwrap.setSelected(true);
/*     */         break;
/*     */       case 3:
/* 130 */         this.bothwrap.setSelected(true);
/*     */         break;
/*     */       case 256:
/* 133 */         this.tbwrap.setSelected(true);
/*     */         break;
/*     */     } 
/*     */     
/* 137 */     Insets insets = paramPainterElementDef.getMargin();
/* 138 */     this.top.setValue((insets == null) ? 0 : insets.top);
/* 139 */     this.left.setValue((insets == null) ? 0 : insets.left);
/* 140 */     this.bottom.setValue((insets == null) ? 0 : insets.bottom);
/* 141 */     this.right.setValue((insets == null) ? 0 : insets.right);
/*     */     
/* 143 */     setEnable();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void populateElement() {
/* 150 */     if (this.width.getText().length() > 0 && this.height.getText().length() > 0) {
/* 151 */       this.elem.setSize(new Size(Float.valueOf(this.width.getText()).floatValue(), Float.valueOf(this.height.getText()).floatValue()));
/*     */     }
/*     */     else {
/*     */       
/* 155 */       this.elem.setSize(null);
/*     */     } 
/*     */     
/* 158 */     float f1 = this.anchorx.floatValue();
/* 159 */     float f2 = this.anchory.floatValue();
/*     */     
/* 161 */     if (this.elem.getFrame() != null) {
/* 162 */       if (this.leftA.isSelected() && f1 < 0.0F) {
/* 163 */         f1 = (this.elem.getFrame()).width / 72.0F + f1;
/*     */       }
/* 165 */       else if (this.rightA.isSelected() && f1 >= 0.0F && this.elem.getPreferredSize() != null) {
/*     */         
/* 167 */         f1 = Math.min(f1 - (this.elem.getFrame()).width / 72.0F, -(this.elem.getPreferredSize()).width / 72.0F);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 172 */     this.elem.reset();
/* 173 */     this.elem.setAnchor(this.anchored.isSelected() ? new Position(f1, f2) : null);
/*     */     
/* 175 */     if (this.breakable.isSelected()) {
/* 176 */       this.elem.setWrapping(1);
/*     */     }
/* 178 */     else if (this.nobreak.isSelected()) {
/* 179 */       this.elem.setWrapping(0);
/*     */     } 
/*     */     
/* 182 */     if (this.nowrap.isSelected()) {
/* 183 */       this.elem.setWrapping(0);
/*     */     }
/* 185 */     else if (this.lwrap.isSelected()) {
/* 186 */       this.elem.setWrapping(1);
/*     */     }
/* 188 */     else if (this.rwrap.isSelected()) {
/* 189 */       this.elem.setWrapping(2);
/*     */     }
/* 191 */     else if (this.bothwrap.isSelected()) {
/* 192 */       this.elem.setWrapping(3);
/*     */     }
/* 194 */     else if (this.tbwrap.isSelected()) {
/* 195 */       this.elem.setWrapping(256);
/*     */     } 
/*     */     
/* 198 */     Insets insets = new Insets(this.top.intValue(), this.left.intValue(), this.bottom.intValue(), this.right.intValue());
/*     */     
/* 200 */     this.elem.setMargin(insets);
/*     */   }
/*     */   
/*     */   public void setEnable() {
/* 204 */     this.anchorx.setEnabled(this.anchored.isSelected());
/* 205 */     this.anchory.setEnabled(this.anchored.isSelected());
/* 206 */     this.leftA.setEnabled(this.anchored.isSelected());
/* 207 */     this.rightA.setEnabled(this.anchored.isSelected());
/*     */   }
/*     */   
/* 210 */   NumField width = new NumField(3, false, true);
/* 211 */   NumField height = new NumField(3, false, true); JToggleButton nowrap;
/*     */   JToggleButton lwrap;
/*     */   JToggleButton rwrap;
/*     */   JToggleButton bothwrap;
/* 215 */   ButtonGroup wrapGroup = new ButtonGroup(); JToggleButton tbwrap; JRadioButton breakable; JRadioButton nobreak; PainterElementDef elem;
/* 216 */   ButtonGroup layoutGroup = new ButtonGroup();
/* 217 */   ButtonGroup anchorGroup = new ButtonGroup();
/* 218 */   JCheckBox anchored = new JCheckBox(Catalog.getString("Anchor to last paragraph(Y) and page(X)"));
/*     */   
/* 220 */   JRadioButton leftA = new JRadioButton(Catalog.getString("From Left"));
/*     */   
/* 222 */   JRadioButton rightA = new JRadioButton(Catalog.getString("From Right"));
/*     */   
/* 224 */   NumField anchorx = new NumField(5, false);
/* 225 */   NumField anchory = new NumField(5, false);
/* 226 */   NumField top = new NumField(3, true);
/* 227 */   NumField left = new NumField(3, true);
/* 228 */   NumField bottom = new NumField(3, true);
/* 229 */   NumField right = new NumField(3, true);
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\FixedPane.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */