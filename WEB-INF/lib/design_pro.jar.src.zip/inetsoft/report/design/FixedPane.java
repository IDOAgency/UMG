package inetsoft.report.design;

import inetsoft.report.Position;
import inetsoft.report.Size;
import inetsoft.report.internal.PainterElementDef;
import inetsoft.report.internal.j2d.NumField;
import inetsoft.report.internal.j2d.Property2Panel;
import inetsoft.report.locale.Catalog;
import java.awt.Insets;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.net.URL;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JCheckBox;
import javax.swing.JRadioButton;
import javax.swing.JToggleButton;

public class FixedPane extends Property2Panel {
  public FixedPane() {
    URL uRL = getClass().getResource("images/nowrap.gif");
    this.nowrap = new JToggleButton(new ImageIcon(uRL));
    this.nowrap.setBorderPainted(true);
    uRL = getClass().getResource("images/lwrap.gif");
    this.lwrap = new JToggleButton(new ImageIcon(uRL));
    uRL = getClass().getResource("images/rwrap.gif");
    this.rwrap = new JToggleButton(new ImageIcon(uRL));
    uRL = getClass().getResource("images/bothwrap.gif");
    this.bothwrap = new JToggleButton(new ImageIcon(uRL));
    uRL = getClass().getResource("images/tbwrap.gif");
    this.tbwrap = new JToggleButton(new ImageIcon(uRL));
    this.wrapGroup.add(this.nowrap);
    this.wrapGroup.add(this.lwrap);
    this.wrapGroup.add(this.rwrap);
    this.wrapGroup.add(this.bothwrap);
    this.wrapGroup.add(this.tbwrap);
    this.anchorGroup.add(this.leftA);
    this.anchorGroup.add(this.rightA);
    this.breakable = new JRadioButton(Catalog.getString("Breakable"));
    this.nobreak = new JRadioButton(Catalog.getString("Non-break"));
    this.layoutGroup.add(this.breakable);
    this.layoutGroup.add(this.nobreak);
    add(Catalog.getString("Size"), new Object[][] { { Catalog.getString("Width") + "\":", this.width, Catalog.getString("Height") + "\":", this.height } });
    add(Catalog.getString("Margin"), new Object[][] { { Catalog.getString("Top") + ":", this.top, Catalog.getString("Left") + ":", this.left, Catalog.getString("Bottom") + ":", this.bottom, Catalog.getString("Right") + ":", this.right } });
    add(Catalog.getString("Wrapping"), new Object[][] { { this.nowrap, this.lwrap, this.rwrap, this.bothwrap, this.tbwrap } });
    add(Catalog.getString("Pagenation"), new Object[][] { { this.breakable, this.nobreak } });
    add(Catalog.getString("Anchor"), new Object[][] { { this.anchored }, { Catalog.getString("X") + "\"", this.anchorx, { this.leftA, this.rightA } }, { Catalog.getString("Y") + "\"", this.anchory } });
    this.anchored.addItemListener(new ItemListener(this) {
          private final FixedPane this$0;
          
          public void itemStateChanged(ItemEvent param1ItemEvent) { this.this$0.setEnable(); }
        });
  }
  
  public void setElement(PainterElementDef paramPainterElementDef) {
    this.elem = paramPainterElementDef;
    Position position = paramPainterElementDef.getAnchor();
    this.anchored.setSelected((position != null));
    this.leftA.setSelected((position == null || position.x >= 0.0F));
    this.rightA.setSelected(!this.leftA.isSelected());
    this.anchorx.setValue((position == null) ? 0.0F : position.x);
    this.anchory.setValue((position == null) ? 0.0F : position.y);
    this.width.setText((paramPainterElementDef.getSize() == null) ? "" : Double.toString((paramPainterElementDef.getSize()).width));
    this.height.setText((paramPainterElementDef.getSize() == null) ? "" : Double.toString((paramPainterElementDef.getSize()).height));
    switch (paramPainterElementDef.getLayout()) {
      case 1:
        this.breakable.setSelected(true);
        break;
      case 0:
        this.nobreak.setSelected(true);
        break;
    } 
    switch (paramPainterElementDef.getWrapping()) {
      case 0:
        this.nowrap.setSelected(true);
        break;
      case 1:
        this.lwrap.setSelected(true);
        break;
      case 2:
        this.rwrap.setSelected(true);
        break;
      case 3:
        this.bothwrap.setSelected(true);
        break;
      case 256:
        this.tbwrap.setSelected(true);
        break;
    } 
    Insets insets = paramPainterElementDef.getMargin();
    this.top.setValue((insets == null) ? 0 : insets.top);
    this.left.setValue((insets == null) ? 0 : insets.left);
    this.bottom.setValue((insets == null) ? 0 : insets.bottom);
    this.right.setValue((insets == null) ? 0 : insets.right);
    setEnable();
  }
  
  public void populateElement() {
    if (this.width.getText().length() > 0 && this.height.getText().length() > 0) {
      this.elem.setSize(new Size(Float.valueOf(this.width.getText()).floatValue(), Float.valueOf(this.height.getText()).floatValue()));
    } else {
      this.elem.setSize(null);
    } 
    float f1 = this.anchorx.floatValue();
    float f2 = this.anchory.floatValue();
    if (this.elem.getFrame() != null)
      if (this.leftA.isSelected() && f1 < 0.0F) {
        f1 = (this.elem.getFrame()).width / 72.0F + f1;
      } else if (this.rightA.isSelected() && f1 >= 0.0F && this.elem.getPreferredSize() != null) {
        f1 = Math.min(f1 - (this.elem.getFrame()).width / 72.0F, -(this.elem.getPreferredSize()).width / 72.0F);
      }  
    this.elem.reset();
    this.elem.setAnchor(this.anchored.isSelected() ? new Position(f1, f2) : null);
    if (this.breakable.isSelected()) {
      this.elem.setWrapping(1);
    } else if (this.nobreak.isSelected()) {
      this.elem.setWrapping(0);
    } 
    if (this.nowrap.isSelected()) {
      this.elem.setWrapping(0);
    } else if (this.lwrap.isSelected()) {
      this.elem.setWrapping(1);
    } else if (this.rwrap.isSelected()) {
      this.elem.setWrapping(2);
    } else if (this.bothwrap.isSelected()) {
      this.elem.setWrapping(3);
    } else if (this.tbwrap.isSelected()) {
      this.elem.setWrapping(256);
    } 
    Insets insets = new Insets(this.top.intValue(), this.left.intValue(), this.bottom.intValue(), this.right.intValue());
    this.elem.setMargin(insets);
  }
  
  public void setEnable() {
    this.anchorx.setEnabled(this.anchored.isSelected());
    this.anchory.setEnabled(this.anchored.isSelected());
    this.leftA.setEnabled(this.anchored.isSelected());
    this.rightA.setEnabled(this.anchored.isSelected());
  }
  
  NumField width = new NumField(3, false, true);
  
  NumField height = new NumField(3, false, true);
  
  JToggleButton nowrap;
  
  JToggleButton lwrap;
  
  JToggleButton rwrap;
  
  JToggleButton bothwrap;
  
  JToggleButton tbwrap;
  
  JRadioButton breakable;
  
  JRadioButton nobreak;
  
  PainterElementDef elem;
  
  ButtonGroup wrapGroup = new ButtonGroup();
  
  ButtonGroup layoutGroup = new ButtonGroup();
  
  ButtonGroup anchorGroup = new ButtonGroup();
  
  JCheckBox anchored = new JCheckBox(Catalog.getString("Anchor to last paragraph(Y) and page(X)"));
  
  JRadioButton leftA = new JRadioButton(Catalog.getString("From Left"));
  
  JRadioButton rightA = new JRadioButton(Catalog.getString("From Right"));
  
  NumField anchorx = new NumField(5, false);
  
  NumField anchory = new NumField(5, false);
  
  NumField top = new NumField(3, true);
  
  NumField left = new NumField(3, true);
  
  NumField bottom = new NumField(3, true);
  
  NumField right = new NumField(3, true);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\FixedPane.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */