package inetsoft.report.design;

import java.awt.AWTEventMulticaster;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Frame;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JList;
import javax.swing.JScrollPane;
import javax.swing.JWindow;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

class ListMenu extends JWindow {
  protected ActionListener actionListener;
  
  ListSelectionListener selectListener;
  
  JList list;
  
  public ListMenu(Frame paramFrame, JList paramJList) {
    super(paramFrame);
    this.selectListener = new ListSelectionListener(this) {
        private final ListMenu this$0;
        
        public void valueChanged(ListSelectionEvent param1ListSelectionEvent) { this.this$0.fire(new ActionEvent(this.this$0, 1001, (String)this.this$0.list.getSelectedValue())); }
      };
    this.list = paramJList;
    getContentPane().setLayout(new BorderLayout());
    getContentPane().add(new JScrollPane(paramJList), "Center");
    paramJList.addListSelectionListener(this.selectListener);
  }
  
  public void show(Component paramComponent) {
    Point point = paramComponent.getLocationOnScreen();
    point.y += (paramComponent.getSize()).height;
    pack();
    setLocation(point);
    setVisible(true);
    setLocation(point);
  }
  
  public void addActionListener(ActionListener paramActionListener) { this.actionListener = AWTEventMulticaster.add(this.actionListener, paramActionListener); }
  
  public void removeActionListener(ActionListener paramActionListener) { this.actionListener = AWTEventMulticaster.remove(this.actionListener, paramActionListener); }
  
  private void fire(ActionEvent paramActionEvent) {
    if (this.actionListener != null)
      this.actionListener.actionPerformed(paramActionEvent); 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\ListMenu.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */