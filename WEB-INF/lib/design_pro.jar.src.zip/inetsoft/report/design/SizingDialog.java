/*     */ package inetsoft.report.design;
/*     */ 
/*     */ import inetsoft.report.internal.j2d.NumField;
/*     */ import inetsoft.report.internal.j2d.Property2Panel;
/*     */ import inetsoft.report.locale.Catalog;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.FlowLayout;
/*     */ import java.awt.Frame;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import javax.swing.ButtonGroup;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ 
/*     */ class SizingDialog
/*     */   extends JDialog {
/*     */   ActionListener okListener;
/*     */   ActionListener cancelListener;
/*     */   JCheckBox vmaxRB;
/*     */   
/*     */   public SizingDialog(Frame paramFrame, DesignView paramDesignView) {
/*  26 */     super(paramFrame);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  84 */     this.okListener = new ActionListener(this) {
/*     */         public void actionPerformed(ActionEvent param1ActionEvent) {
/*  86 */           int i = 0, j = 0;
/*     */           
/*  88 */           if (this.this$0.vmaxRB.isSelected()) {
/*  89 */             j = Integer.MAX_VALUE;
/*     */           }
/*  91 */           else if (this.this$0.vminRB.isSelected()) {
/*  92 */             j = Integer.MIN_VALUE;
/*     */           }
/*  94 */           else if (this.this$0.vsizeRB.isSelected()) {
/*  95 */             j = this.this$0.vsizeTF.intValue();
/*     */           } 
/*     */           
/*  98 */           if (this.this$0.hmaxRB.isSelected()) {
/*  99 */             i = Integer.MAX_VALUE;
/*     */           }
/* 101 */           else if (this.this$0.hminRB.isSelected()) {
/* 102 */             i = Integer.MIN_VALUE;
/*     */           }
/* 104 */           else if (this.this$0.hsizeRB.isSelected()) {
/* 105 */             i = this.this$0.hsizeTF.intValue();
/*     */           } 
/*     */           
/* 108 */           this.this$0.view.changeSizes(i, j);
/*     */           
/* 110 */           this.this$0.dispose();
/*     */         }
/*     */         private final SizingDialog this$0;
/*     */       };
/* 114 */     this.cancelListener = new ActionListener(this)
/*     */       {
/* 116 */         public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.dispose(); }
/*     */ 
/*     */ 
/*     */         
/*     */         private final SizingDialog this$0;
/*     */       };
/* 122 */     this.vsizeTF = new NumField(3, true);
/* 123 */     this.hsizeTF = new NumField(3, true);
/* 124 */     this.hgroup = new ButtonGroup(); this.vgroup = new ButtonGroup();
/* 125 */     this.okB = new JButton(Catalog.getString("OK"));
/* 126 */     this.cancelB = new JButton(Catalog.getString("Cancel"));
/*     */     setModal(true);
/*     */     this.view = paramDesignView;
/*     */     ImageIcon imageIcon1 = new ImageIcon(getClass().getResource("images/hmax-size.gif"));
/*     */     ImageIcon imageIcon2 = new ImageIcon(getClass().getResource("images/hmin-size.gif"));
/*     */     ImageIcon imageIcon3 = new ImageIcon(getClass().getResource("images/vmax-size.gif"));
/*     */     ImageIcon imageIcon4 = new ImageIcon(getClass().getResource("images/vmin-size.gif"));
/*     */     this.hmaxRB = new JCheckBox(Catalog.getString("Largest"));
/*     */     this.hminRB = new JCheckBox(Catalog.getString("Smallest"));
/*     */     this.hsizeRB = new JCheckBox(Catalog.getString("Width"));
/*     */     this.vmaxRB = new JCheckBox(Catalog.getString("Largest"));
/*     */     this.vminRB = new JCheckBox(Catalog.getString("Smallest"));
/*     */     this.vsizeRB = new JCheckBox(Catalog.getString("Height"));
/*     */     getContentPane().setLayout(new BorderLayout(5, 5));
/*     */     Property2Panel property2Panel = new Property2Panel();
/*     */     property2Panel.add(Catalog.getString("Horizontal"), new Object[][] { { { new JLabel(imageIcon1), this.hmaxRB }, { new JLabel(imageIcon2), this.hminRB }, { this.hsizeRB, this.hsizeTF } } });
/*     */     property2Panel.add(Catalog.getString("Vertical"), new Object[][] { { { new JLabel(imageIcon3), this.vmaxRB }, { new JLabel(imageIcon4), this.vminRB }, { this.vsizeRB, this.vsizeTF } } });
/*     */     getContentPane().add(property2Panel, "Center");
/*     */     JPanel jPanel = new JPanel();
/*     */     jPanel.setLayout(new FlowLayout());
/*     */     jPanel.add(this.okB);
/*     */     jPanel.add(this.cancelB);
/*     */     getContentPane().add(jPanel, "South");
/*     */     this.okB.addActionListener(this.okListener);
/*     */     this.cancelB.addActionListener(this.cancelListener);
/*     */     this.hgroup.add(this.hmaxRB);
/*     */     this.hgroup.add(this.hminRB);
/*     */     this.hgroup.add(this.hsizeRB);
/*     */     this.vgroup.add(this.vmaxRB);
/*     */     this.vgroup.add(this.vminRB);
/*     */     this.vgroup.add(this.vsizeRB);
/*     */   }
/*     */   
/*     */   JCheckBox vminRB;
/*     */   JCheckBox vsizeRB;
/*     */   JCheckBox hmaxRB;
/*     */   JCheckBox hminRB;
/*     */   JCheckBox hsizeRB;
/*     */   NumField vsizeTF;
/*     */   NumField hsizeTF;
/*     */   ButtonGroup hgroup;
/*     */   ButtonGroup vgroup;
/*     */   JButton okB;
/*     */   JButton cancelB;
/*     */   DesignView view;
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\SizingDialog.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */