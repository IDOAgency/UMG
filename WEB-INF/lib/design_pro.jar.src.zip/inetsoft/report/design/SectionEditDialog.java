package inetsoft.report.design;

import inetsoft.report.SectionBand;
import inetsoft.report.SectionElement;
import inetsoft.report.SectionLens;
import inetsoft.report.StyleSheet;
import inetsoft.report.internal.BaseElement;
import inetsoft.report.lens.DefaultSectionLens;
import inetsoft.report.locale.Catalog;
import inetsoft.widget.VFlowLayout;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

class SectionEditDialog extends JDialog {
  ActionListener insertListener;
  
  ActionListener deleteListener;
  
  ActionListener closeListener;
  
  SectionElement elem;
  
  JList bandlist;
  
  JButton insertB;
  
  JButton deleteB;
  
  JButton closeB;
  
  DesignView view;
  
  public SectionEditDialog(Frame paramFrame, DesignView paramDesignView) {
    super(paramFrame);
    this.insertListener = new ActionListener(this) {
        private final SectionEditDialog this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          int i = this.this$0.bandlist.getSelectedIndex();
          SectionLens sectionLens = this.this$0.elem.getSection();
          byte b = 0;
          for (Object object = sectionLens.getSectionContent(); object != null; 
            sectionLens = (SectionLens)object, b++, 
            object = ((SectionLens)object).getSectionContent()) {
            if (b >= i) {
              StyleSheet styleSheet = ((BaseElement)this.this$0.elem).getStyleSheet();
              DefaultSectionLens defaultSectionLens = new DefaultSectionLens(new SectionBand(styleSheet), (SectionBand)null, new SectionBand(styleSheet));
              if (object instanceof SectionBand) {
                defaultSectionLens.setSectionContent((SectionBand)object);
              } else {
                defaultSectionLens.setSectionContent((SectionLens)object);
              } 
              ((DefaultSectionLens)sectionLens).setSectionContent(defaultSectionLens);
              break;
            } 
          } 
          this.this$0.populateList();
          this.this$0.view.setChanged(true);
          this.this$0.view.reprint(this.this$0.elem);
        }
      };
    this.deleteListener = new ActionListener(this) {
        private final SectionEditDialog this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          int i = this.this$0.bandlist.getSelectedIndex();
          SectionLens sectionLens = this.this$0.elem.getSection();
          byte b = 1;
          for (Object object = sectionLens.getSectionContent(); object != null; 
            sectionLens = (SectionLens)object, b++, 
            object = ((SectionLens)object).getSectionContent()) {
            if (b >= i) {
              if (object instanceof SectionLens) {
                Object object1 = ((SectionLens)object).getSectionContent();
                if (object1 instanceof SectionBand) {
                  ((DefaultSectionLens)sectionLens).setSectionContent((SectionBand)object1);
                  break;
                } 
                ((DefaultSectionLens)sectionLens).setSectionContent((SectionLens)object1);
              } 
              break;
            } 
          } 
          this.this$0.populateList();
          this.this$0.view.setChanged(true);
          this.this$0.view.reprint(this.this$0.elem);
        }
      };
    this.closeListener = new ActionListener(this) {
        private final SectionEditDialog this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.dispose(); }
      };
    this.bandlist = new JList();
    this.insertB = new JButton(Catalog.getString("Insert"));
    this.deleteB = new JButton(Catalog.getString("Delete"));
    this.closeB = new JButton(Catalog.getString("Close"));
    this.view = paramDesignView;
    getContentPane().setLayout(new BorderLayout(5, 5));
    JScrollPane jScrollPane = new JScrollPane(this.bandlist);
    jScrollPane.setPreferredSize(new Dimension(200, 100));
    getContentPane().add(jScrollPane, "Center");
    JPanel jPanel = new JPanel();
    jPanel.setLayout(new VFlowLayout(16, 5, 15));
    jPanel.add(this.insertB);
    jPanel.add(this.deleteB);
    jPanel.add(this.closeB);
    getContentPane().add(jPanel, "East");
    this.insertB.addActionListener(this.insertListener);
    this.deleteB.addActionListener(this.deleteListener);
    this.closeB.addActionListener(this.closeListener);
    this.bandlist.addListSelectionListener(new ListSelectionListener(this) {
          private final SectionEditDialog this$0;
          
          public void valueChanged(ListSelectionEvent param1ListSelectionEvent) { this.this$0.setEnabled(); }
        });
    setEnabled();
  }
  
  public void setSection(SectionElement paramSectionElement) {
    this.elem = paramSectionElement;
    populateList();
  }
  
  private void populateList() {
    SectionLens sectionLens = this.elem.getSection();
    DefaultListModel defaultListModel = new DefaultListModel();
    byte b = 1;
    defaultListModel.addElement("Section");
    Object object = sectionLens.getSectionContent();
    for (; object instanceof SectionLens; object = ((SectionLens)object).getSectionContent())
      defaultListModel.addElement("Group #" + b++); 
    this.bandlist.setModel(defaultListModel);
  }
  
  private void setEnabled() {
    int i = this.bandlist.getSelectedIndex();
    this.insertB.setEnabled((i >= 0));
    this.deleteB.setEnabled((i > 0));
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\SectionEditDialog.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */