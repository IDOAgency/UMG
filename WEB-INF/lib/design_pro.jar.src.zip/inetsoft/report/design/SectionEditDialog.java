/*     */ package inetsoft.report.design;
/*     */ 
/*     */ import inetsoft.report.SectionBand;
/*     */ import inetsoft.report.SectionElement;
/*     */ import inetsoft.report.SectionLens;
/*     */ import inetsoft.report.StyleSheet;
/*     */ import inetsoft.report.internal.BaseElement;
/*     */ import inetsoft.report.lens.DefaultSectionLens;
/*     */ import inetsoft.report.locale.Catalog;
/*     */ import inetsoft.widget.VFlowLayout;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Frame;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import javax.swing.DefaultListModel;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JList;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.event.ListSelectionEvent;
/*     */ import javax.swing.event.ListSelectionListener;
/*     */ 
/*     */ class SectionEditDialog extends JDialog {
/*     */   ActionListener insertListener;
/*     */   ActionListener deleteListener;
/*     */   ActionListener closeListener;
/*     */   SectionElement elem;
/*     */   
/*     */   public SectionEditDialog(Frame paramFrame, DesignView paramDesignView) {
/*  32 */     super(paramFrame);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  93 */     this.insertListener = new ActionListener(this) { private final SectionEditDialog this$0;
/*     */         public void actionPerformed(ActionEvent param1ActionEvent) {
/*  95 */           int i = this.this$0.bandlist.getSelectedIndex();
/*  96 */           SectionLens sectionLens = this.this$0.elem.getSection();
/*  97 */           byte b = 0;
/*     */           
/*  99 */           for (Object object = sectionLens.getSectionContent(); object != null; 
/* 100 */             sectionLens = (SectionLens)object, b++, 
/* 101 */             object = ((SectionLens)object).getSectionContent()) {
/* 102 */             if (b >= i) {
/* 103 */               StyleSheet styleSheet = ((BaseElement)this.this$0.elem).getStyleSheet();
/* 104 */               DefaultSectionLens defaultSectionLens = new DefaultSectionLens(new SectionBand(styleSheet), (SectionBand)null, new SectionBand(styleSheet));
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 109 */               if (object instanceof SectionBand) {
/* 110 */                 defaultSectionLens.setSectionContent((SectionBand)object);
/*     */               } else {
/*     */                 
/* 113 */                 defaultSectionLens.setSectionContent((SectionLens)object);
/*     */               } 
/*     */               
/* 116 */               ((DefaultSectionLens)sectionLens).setSectionContent(defaultSectionLens);
/*     */               
/*     */               break;
/*     */             } 
/*     */           } 
/* 121 */           this.this$0.populateList();
/* 122 */           this.this$0.view.setChanged(true);
/* 123 */           this.this$0.view.reprint(this.this$0.elem);
/*     */         } }
/*     */       ;
/*     */     
/* 127 */     this.deleteListener = new ActionListener(this) {
/*     */         public void actionPerformed(ActionEvent param1ActionEvent) {
/* 129 */           int i = this.this$0.bandlist.getSelectedIndex();
/* 130 */           SectionLens sectionLens = this.this$0.elem.getSection();
/* 131 */           byte b = 1;
/*     */           
/* 133 */           for (Object object = sectionLens.getSectionContent(); object != null; 
/* 134 */             sectionLens = (SectionLens)object, b++, 
/* 135 */             object = ((SectionLens)object).getSectionContent()) {
/* 136 */             if (b >= i) {
/* 137 */               if (object instanceof SectionLens) {
/* 138 */                 Object object1 = ((SectionLens)object).getSectionContent();
/*     */                 
/* 140 */                 if (object1 instanceof SectionBand) {
/* 141 */                   ((DefaultSectionLens)sectionLens).setSectionContent((SectionBand)object1);
/*     */                   
/*     */                   break;
/*     */                 } 
/* 145 */                 ((DefaultSectionLens)sectionLens).setSectionContent((SectionLens)object1);
/*     */               } 
/*     */ 
/*     */               
/*     */               break;
/*     */             } 
/*     */           } 
/*     */ 
/*     */           
/* 154 */           this.this$0.populateList();
/* 155 */           this.this$0.view.setChanged(true);
/* 156 */           this.this$0.view.reprint(this.this$0.elem);
/*     */         }
/*     */         private final SectionEditDialog this$0;
/*     */       };
/* 160 */     this.closeListener = new ActionListener(this) { private final SectionEditDialog this$0;
/*     */         
/* 162 */         public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.dispose(); }
/*     */          }
/*     */       ;
/*     */ 
/*     */     
/* 167 */     this.bandlist = new JList();
/* 168 */     this.insertB = new JButton(Catalog.getString("Insert"));
/* 169 */     this.deleteB = new JButton(Catalog.getString("Delete"));
/* 170 */     this.closeB = new JButton(Catalog.getString("Close"));
/*     */     this.view = paramDesignView;
/*     */     getContentPane().setLayout(new BorderLayout(5, 5));
/*     */     JScrollPane jScrollPane = new JScrollPane(this.bandlist);
/*     */     jScrollPane.setPreferredSize(new Dimension(200, 100));
/*     */     getContentPane().add(jScrollPane, "Center");
/*     */     JPanel jPanel = new JPanel();
/*     */     jPanel.setLayout(new VFlowLayout(16, 5, 15));
/*     */     jPanel.add(this.insertB);
/*     */     jPanel.add(this.deleteB);
/*     */     jPanel.add(this.closeB);
/*     */     getContentPane().add(jPanel, "East");
/*     */     this.insertB.addActionListener(this.insertListener);
/*     */     this.deleteB.addActionListener(this.deleteListener);
/*     */     this.closeB.addActionListener(this.closeListener);
/*     */     this.bandlist.addListSelectionListener(new ListSelectionListener(this) {
/*     */           private final SectionEditDialog this$0;
/*     */           
/*     */           public void valueChanged(ListSelectionEvent param1ListSelectionEvent) { this.this$0.setEnabled(); }
/*     */         });
/*     */     setEnabled();
/*     */   }
/*     */   JList bandlist;
/*     */   JButton insertB;
/*     */   JButton deleteB;
/*     */   JButton closeB;
/*     */   DesignView view;
/*     */   
/*     */   public void setSection(SectionElement paramSectionElement) {
/*     */     this.elem = paramSectionElement;
/*     */     populateList();
/*     */   }
/*     */   
/*     */   private void populateList() {
/*     */     SectionLens sectionLens = this.elem.getSection();
/*     */     DefaultListModel defaultListModel = new DefaultListModel();
/*     */     byte b = 1;
/*     */     defaultListModel.addElement("Section");
/*     */     Object object = sectionLens.getSectionContent();
/*     */     for (; object instanceof SectionLens; object = ((SectionLens)object).getSectionContent())
/*     */       defaultListModel.addElement("Group #" + b++); 
/*     */     this.bandlist.setModel(defaultListModel);
/*     */   }
/*     */   
/*     */   private void setEnabled() {
/*     */     int i = this.bandlist.getSelectedIndex();
/*     */     this.insertB.setEnabled((i >= 0));
/*     */     this.deleteB.setEnabled((i > 0));
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\SectionEditDialog.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */