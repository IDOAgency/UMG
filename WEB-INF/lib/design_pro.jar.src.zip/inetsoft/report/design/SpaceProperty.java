package inetsoft.report.design;

import inetsoft.report.ReportElement;
import inetsoft.report.SpaceElement;
import inetsoft.report.internal.j2d.NumField;
import inetsoft.report.internal.j2d.Property2Panel;
import inetsoft.report.locale.Catalog;

public class SpaceProperty extends PropertyDialog {
  SpaceElement elem;
  
  NumField num;
  
  public SpaceProperty(DesignView paramDesignView) {
    super(paramDesignView);
    this.num = new NumField(5, true);
    setTitle(Catalog.getString("Space Properties"));
    Property2Panel property2Panel = new Property2Panel();
    property2Panel.add(Catalog.getString("Space"), new Object[][] { { Catalog.getString("Number of Points") + ":", this.num } });
    this.folder.addTab(Catalog.getString("Space"), null, property2Panel, Catalog.getString("Spaces"));
  }
  
  public void setElement(ReportElement paramReportElement) {
    this.elem = (SpaceElement)paramReportElement;
    super.setElement(paramReportElement);
    this.num.setValue(this.elem.getSpace());
  }
  
  public boolean populateElement() {
    if (!super.populateElement())
      return false; 
    this.elem.setSpace(this.num.intValue());
    return true;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\SpaceProperty.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */