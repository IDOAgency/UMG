package inetsoft.report.design;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Properties;

public class DesignEnv {
  public static String getProperty(String paramString) {
    init();
    return prop.getProperty(paramString);
  }
  
  public static String getProperty(String paramString1, String paramString2) {
    init();
    return prop.getProperty(paramString1, paramString2);
  }
  
  public static void setProperty(String paramString1, String paramString2) {
    init();
    prop.put(paramString1, paramString2);
  }
  
  public static Properties getProperties() {
    init();
    return prop;
  }
  
  static String getHome() {
    String str = System.getProperty("home");
    if (str == null)
      str = System.getProperty("user.home"); 
    return str;
  }
  
  static void init() {
    if (prop == null) {
      prop = new Properties();
      try {
        FileInputStream fileInputStream = new FileInputStream(getHome() + "/.stylereport");
        if (fileInputStream != null) {
          prop.load(fileInputStream);
          fileInputStream.close();
          return;
        } 
      } catch (Exception exception) {}
    } 
  }
  
  static void save() {
    try {
      FileOutputStream fileOutputStream = new FileOutputStream(getHome() + "/.stylereport");
      prop.save(fileOutputStream, null);
      fileOutputStream.close();
    } catch (Exception exception) {
      System.err.println("Failed to save designer configuration file!");
      System.err.println("Directory: " + getHome());
      exception.printStackTrace();
    } 
  }
  
  static Properties prop = null;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\DesignEnv.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */