/*    */ package inetsoft.report.design;
/*    */ 
/*    */ import java.io.FileInputStream;
/*    */ import java.io.FileOutputStream;
/*    */ import java.util.Properties;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DesignEnv
/*    */ {
/*    */   public static String getProperty(String paramString) {
/* 28 */     init();
/* 29 */     return prop.getProperty(paramString);
/*    */   }
/*    */   
/*    */   public static String getProperty(String paramString1, String paramString2) {
/* 33 */     init();
/* 34 */     return prop.getProperty(paramString1, paramString2);
/*    */   }
/*    */   
/*    */   public static void setProperty(String paramString1, String paramString2) {
/* 38 */     init();
/* 39 */     prop.put(paramString1, paramString2);
/*    */   }
/*    */   
/*    */   public static Properties getProperties() {
/* 43 */     init();
/* 44 */     return prop;
/*    */   }
/*    */   
/*    */   static String getHome() {
/* 48 */     String str = System.getProperty("home");
/* 49 */     if (str == null) {
/* 50 */       str = System.getProperty("user.home");
/*    */     }
/*    */     
/* 53 */     return str;
/*    */   }
/*    */   
/*    */   static void init() {
/* 57 */     if (prop == null) {
/* 58 */       prop = new Properties();
/*    */       
/*    */       try {
/* 61 */         FileInputStream fileInputStream = new FileInputStream(getHome() + "/.stylereport");
/*    */         
/* 63 */         if (fileInputStream != null) {
/* 64 */           prop.load(fileInputStream);
/* 65 */           fileInputStream.close();
/*    */           return;
/*    */         } 
/* 68 */       } catch (Exception exception) {}
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   static void save() {
/*    */     try {
/* 75 */       FileOutputStream fileOutputStream = new FileOutputStream(getHome() + "/.stylereport");
/*    */ 
/*    */       
/* 78 */       prop.save(fileOutputStream, null);
/* 79 */       fileOutputStream.close();
/*    */     } catch (Exception exception) {
/* 81 */       System.err.println("Failed to save designer configuration file!");
/* 82 */       System.err.println("Directory: " + getHome());
/* 83 */       exception.printStackTrace();
/*    */     } 
/*    */   }
/*    */   
/* 87 */   static Properties prop = null;
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\DesignEnv.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */