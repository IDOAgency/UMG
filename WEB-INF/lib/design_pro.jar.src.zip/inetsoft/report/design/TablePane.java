/*     */ package inetsoft.report.design;
/*     */ 
/*     */ import inetsoft.report.ChartLens;
/*     */ import inetsoft.report.FormLens;
/*     */ import inetsoft.report.TableLens;
/*     */ import inetsoft.report.internal.ChartXElement;
/*     */ import inetsoft.report.internal.FormXElement;
/*     */ import inetsoft.report.internal.TableXElement;
/*     */ import inetsoft.report.internal.Tabular;
/*     */ import inetsoft.report.internal.j2d.Property2Panel;
/*     */ import inetsoft.report.lens.swing11.TableModelLens;
/*     */ import inetsoft.report.locale.Catalog;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.table.DefaultTableCellRenderer;
/*     */ import javax.swing.table.TableCellEditor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class TablePane
/*     */   extends JPanel
/*     */ {
/*     */   public static final int TABLE = 1;
/*     */   public static final int CHART = 2;
/*     */   public static final int FORM = 3;
/*     */   
/*     */   public TablePane(int paramInt) {
/*  42 */     String str1 = null, str2 = null;
/*     */     
/*  44 */     if (paramInt == 2) {
/*  45 */       str2 = Catalog.getString("Size");
/*  46 */       str1 = Catalog.getString("Datasets");
/*  47 */       this.hrow = this.hcol = 1;
/*     */     }
/*  49 */     else if (paramInt == 1) {
/*  50 */       str1 = Catalog.getString("Rows");
/*  51 */       str2 = Catalog.getString("Columns");
/*  52 */       this.hrow = 1; this.hcol = 0;
/*     */     }
/*  54 */     else if (paramInt == 3) {
/*  55 */       str1 = Catalog.getString("Fields");
/*  56 */       str2 = null;
/*  57 */       this.cols.setText("2");
/*  58 */       this.cols.setVisible(false);
/*  59 */       this.hrow = 0; this.hcol = 1;
/*     */     } 
/*     */     
/*  62 */     setLayout(new BorderLayout());
/*  63 */     Property2Panel property2Panel = new Property2Panel();
/*     */     
/*  65 */     if (paramInt == 1) {
/*  66 */       property2Panel.add(Catalog.getString("Table"), new Object[][] { { str1, this.rows, str2, this.cols }, { Catalog.getString("Header Rows") + ":", this.hrows, Catalog.getString("Header Columns") + ":", this.hcols }, { this.dim, "", this.embed } });
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/*  73 */       property2Panel.add(Catalog.getString("Data"), new Object[][] { { str1, this.rows, str2, this.cols }, { this.dim, "", this.embed } });
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  78 */     add(property2Panel, "North");
/*  79 */     this.dim.addActionListener(this.dimListener);
/*     */     
/*  81 */     this.table = new JTable(this.model);
/*     */ 
/*     */     
/*  84 */     if (paramInt != 3) {
/*  85 */       this.table.setAutoResizeMode(0);
/*     */     }
/*     */     
/*  88 */     this.table.setTableHeader(null);
/*  89 */     JScrollPane jScrollPane = new JScrollPane(this.table);
/*  90 */     add(jScrollPane, "Center");
/*  91 */     jScrollPane.setPreferredSize(new Dimension(400, 200));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setElement(Tabular paramTabular) {
/*  98 */     this.elem = paramTabular;
/*     */     
/* 100 */     this.embed.setSelected(paramTabular.isEmbedded());
/* 101 */     if (paramTabular instanceof TableXElement) {
/* 102 */       TableXElement tableXElement = (TableXElement)paramTabular;
/* 103 */       TableLens tableLens = tableXElement.getTable();
/* 104 */       this.hrows.setText(Integer.toString(this.hrow = tableLens.getHeaderRowCount()));
/* 105 */       this.hcols.setText(Integer.toString(this.hcol = tableLens.getHeaderColCount()));
/* 106 */       this.rows.setText(Integer.toString(tableLens.getRowCount()));
/* 107 */       this.cols.setText(Integer.toString(tableLens.getColCount()));
/*     */       
/* 109 */       this.model.setData(tableLens);
/*     */     }
/* 111 */     else if (paramTabular instanceof ChartXElement) {
/* 112 */       ChartXElement chartXElement = (ChartXElement)paramTabular;
/* 113 */       ChartLens chartLens = chartXElement.getChart();
/* 114 */       this.hrows.setText(Integer.toString(this.hrow));
/* 115 */       this.hcols.setText(Integer.toString(this.hcol));
/* 116 */       this.rows.setText(Integer.toString(chartLens.getDatasetCount()));
/* 117 */       this.cols.setText(Integer.toString(chartLens.getDatasetSize()));
/*     */       
/* 119 */       this.model.setData(chartLens);
/*     */     }
/* 121 */     else if (paramTabular instanceof FormXElement) {
/* 122 */       FormXElement formXElement = (FormXElement)paramTabular;
/* 123 */       FormLens formLens = formXElement.getForm();
/* 124 */       this.hrows.setText(Integer.toString(this.hrow));
/* 125 */       this.hcols.setText(Integer.toString(this.hcol));
/* 126 */       this.rows.setText(Integer.toString(formLens.getFieldCount()));
/* 127 */       this.cols.setText(Integer.toString(2));
/*     */       
/* 129 */       this.model.setData(formLens);
/*     */     } 
/*     */     
/* 132 */     for (byte b = 0; b < this.table.getColumnCount(); b++) {
/* 133 */       this.table.getColumnModel().getColumn(b).setPreferredWidth(100);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void populateElement() {
/* 142 */     TableCellEditor tableCellEditor = this.table.getCellEditor();
/* 143 */     if (tableCellEditor != null) {
/* 144 */       tableCellEditor.stopCellEditing();
/*     */     }
/*     */     
/* 147 */     this.elem.setEmbedded(this.embed.isSelected());
/*     */     
/* 149 */     if (this.elem instanceof TableXElement) {
/* 150 */       TableXElement tableXElement = (TableXElement)this.elem;
/* 151 */       TableModelLens tableModelLens = new TableModelLens(this.model.getData(), false);
/* 152 */       tableModelLens.setHeaderRowCount(Integer.parseInt(this.hrows.getText()));
/* 153 */       tableModelLens.setHeaderColCount(Integer.parseInt(this.hcols.getText()));
/* 154 */       tableXElement.setData(tableModelLens);
/*     */     }
/* 156 */     else if (this.elem instanceof ChartXElement) {
/* 157 */       ChartXElement chartXElement = (ChartXElement)this.elem;
/* 158 */       TableModelLens tableModelLens = new TableModelLens(this.model.getData(), false);
/* 159 */       tableModelLens.setHeaderRowCount(1);
/* 160 */       tableModelLens.setHeaderColCount(1);
/* 161 */       chartXElement.setData(tableModelLens);
/*     */     }
/* 163 */     else if (this.elem instanceof FormXElement) {
/* 164 */       FormXElement formXElement = (FormXElement)this.elem;
/* 165 */       formXElement.setData(new TableModelLens(this.model.getData(), false));
/*     */     } 
/*     */   }
/*     */   
/* 169 */   class Renderer extends DefaultTableCellRenderer { Renderer(TablePane this$0) { this.this$0 = this$0; }
/*     */ 
/*     */     
/*     */     private final TablePane this$0;
/*     */     
/*     */     public Component getTableCellRendererComponent(JTable param1JTable, Object param1Object, boolean param1Boolean1, boolean param1Boolean2, int param1Int1, int param1Int2) {
/* 175 */       Component component = super.getTableCellRendererComponent(param1JTable, param1Object, param1Boolean1, param1Boolean2, param1Int1, param1Int2);
/*     */ 
/*     */ 
/*     */       
/* 179 */       if ((param1Int1 >= this.this$0.hrow && param1Int2 >= this.this$0.hcol) || (param1Int1 < this.this$0.hrow && param1Int2 < this.this$0.hcol)) {
/* 180 */         component.setBackground(Color.white);
/*     */       } else {
/*     */         
/* 183 */         component.setBackground(Color.lightGray);
/*     */       } 
/*     */       
/* 186 */       component.setForeground(Color.black);
/*     */       
/* 188 */       return component;
/*     */     } }
/*     */ 
/*     */   
/* 192 */   ActionListener dimListener = new ActionListener(this) {
/*     */       public void actionPerformed(ActionEvent param1ActionEvent) {
/* 194 */         int i = Integer.parseInt(this.this$0.rows.getText());
/* 195 */         int j = Integer.parseInt(this.this$0.cols.getText());
/*     */         
/* 197 */         if (this.this$0.elem instanceof ChartXElement) {
/* 198 */           i++; j++;
/*     */         } 
/*     */         
/* 201 */         this.this$0.model.setDimension(i, j);
/*     */       }
/*     */       private final TablePane this$0;
/*     */     };
/*     */   int hrow; int hcol;
/*     */   JTable table;
/* 207 */   JTextField rows = new JTextField(3); JTextField cols = new JTextField(3);
/* 208 */   JButton dim = new JButton(Catalog.getString("Set Dimension"));
/* 209 */   JTextField hrows = new JTextField(3);
/* 210 */   JTextField hcols = new JTextField(3);
/* 211 */   JCheckBox embed = new JCheckBox(Catalog.getString("Embed Data"));
/*     */   
/* 213 */   TableData model = new TableData();
/*     */   Tabular elem;
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\TablePane.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */