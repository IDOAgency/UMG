package inetsoft.report.design;

import inetsoft.report.ChartLens;
import inetsoft.report.FormLens;
import inetsoft.report.TableLens;
import inetsoft.report.internal.ChartXElement;
import inetsoft.report.internal.FormXElement;
import inetsoft.report.internal.TableXElement;
import inetsoft.report.internal.Tabular;
import inetsoft.report.internal.j2d.Property2Panel;
import inetsoft.report.lens.swing11.TableModelLens;
import inetsoft.report.locale.Catalog;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableCellEditor;

class TablePane extends JPanel {
  public static final int TABLE = 1;
  
  public static final int CHART = 2;
  
  public static final int FORM = 3;
  
  public TablePane(int paramInt) {
    String str1 = null, str2 = null;
    if (paramInt == 2) {
      str2 = Catalog.getString("Size");
      str1 = Catalog.getString("Datasets");
      this.hrow = this.hcol = 1;
    } else if (paramInt == 1) {
      str1 = Catalog.getString("Rows");
      str2 = Catalog.getString("Columns");
      this.hrow = 1;
      this.hcol = 0;
    } else if (paramInt == 3) {
      str1 = Catalog.getString("Fields");
      str2 = null;
      this.cols.setText("2");
      this.cols.setVisible(false);
      this.hrow = 0;
      this.hcol = 1;
    } 
    setLayout(new BorderLayout());
    Property2Panel property2Panel = new Property2Panel();
    if (paramInt == 1) {
      property2Panel.add(Catalog.getString("Table"), new Object[][] { { str1, this.rows, str2, this.cols }, { Catalog.getString("Header Rows") + ":", this.hrows, Catalog.getString("Header Columns") + ":", this.hcols }, { this.dim, "", this.embed } });
    } else {
      property2Panel.add(Catalog.getString("Data"), new Object[][] { { str1, this.rows, str2, this.cols }, { this.dim, "", this.embed } });
    } 
    add(property2Panel, "North");
    this.dim.addActionListener(this.dimListener);
    this.table = new JTable(this.model);
    if (paramInt != 3)
      this.table.setAutoResizeMode(0); 
    this.table.setTableHeader(null);
    JScrollPane jScrollPane = new JScrollPane(this.table);
    add(jScrollPane, "Center");
    jScrollPane.setPreferredSize(new Dimension(400, 200));
  }
  
  public void setElement(Tabular paramTabular) {
    this.elem = paramTabular;
    this.embed.setSelected(paramTabular.isEmbedded());
    if (paramTabular instanceof TableXElement) {
      TableXElement tableXElement = (TableXElement)paramTabular;
      TableLens tableLens = tableXElement.getTable();
      this.hrows.setText(Integer.toString(this.hrow = tableLens.getHeaderRowCount()));
      this.hcols.setText(Integer.toString(this.hcol = tableLens.getHeaderColCount()));
      this.rows.setText(Integer.toString(tableLens.getRowCount()));
      this.cols.setText(Integer.toString(tableLens.getColCount()));
      this.model.setData(tableLens);
    } else if (paramTabular instanceof ChartXElement) {
      ChartXElement chartXElement = (ChartXElement)paramTabular;
      ChartLens chartLens = chartXElement.getChart();
      this.hrows.setText(Integer.toString(this.hrow));
      this.hcols.setText(Integer.toString(this.hcol));
      this.rows.setText(Integer.toString(chartLens.getDatasetCount()));
      this.cols.setText(Integer.toString(chartLens.getDatasetSize()));
      this.model.setData(chartLens);
    } else if (paramTabular instanceof FormXElement) {
      FormXElement formXElement = (FormXElement)paramTabular;
      FormLens formLens = formXElement.getForm();
      this.hrows.setText(Integer.toString(this.hrow));
      this.hcols.setText(Integer.toString(this.hcol));
      this.rows.setText(Integer.toString(formLens.getFieldCount()));
      this.cols.setText(Integer.toString(2));
      this.model.setData(formLens);
    } 
    for (byte b = 0; b < this.table.getColumnCount(); b++)
      this.table.getColumnModel().getColumn(b).setPreferredWidth(100); 
  }
  
  public void populateElement() {
    TableCellEditor tableCellEditor = this.table.getCellEditor();
    if (tableCellEditor != null)
      tableCellEditor.stopCellEditing(); 
    this.elem.setEmbedded(this.embed.isSelected());
    if (this.elem instanceof TableXElement) {
      TableXElement tableXElement = (TableXElement)this.elem;
      TableModelLens tableModelLens = new TableModelLens(this.model.getData(), false);
      tableModelLens.setHeaderRowCount(Integer.parseInt(this.hrows.getText()));
      tableModelLens.setHeaderColCount(Integer.parseInt(this.hcols.getText()));
      tableXElement.setData(tableModelLens);
    } else if (this.elem instanceof ChartXElement) {
      ChartXElement chartXElement = (ChartXElement)this.elem;
      TableModelLens tableModelLens = new TableModelLens(this.model.getData(), false);
      tableModelLens.setHeaderRowCount(1);
      tableModelLens.setHeaderColCount(1);
      chartXElement.setData(tableModelLens);
    } else if (this.elem instanceof FormXElement) {
      FormXElement formXElement = (FormXElement)this.elem;
      formXElement.setData(new TableModelLens(this.model.getData(), false));
    } 
  }
  
  class Renderer extends DefaultTableCellRenderer {
    private final TablePane this$0;
    
    Renderer(TablePane this$0) { this.this$0 = this$0; }
    
    public Component getTableCellRendererComponent(JTable param1JTable, Object param1Object, boolean param1Boolean1, boolean param1Boolean2, int param1Int1, int param1Int2) {
      Component component = super.getTableCellRendererComponent(param1JTable, param1Object, param1Boolean1, param1Boolean2, param1Int1, param1Int2);
      if ((param1Int1 >= this.this$0.hrow && param1Int2 >= this.this$0.hcol) || (param1Int1 < this.this$0.hrow && param1Int2 < this.this$0.hcol)) {
        component.setBackground(Color.white);
      } else {
        component.setBackground(Color.lightGray);
      } 
      component.setForeground(Color.black);
      return component;
    }
  }
  
  ActionListener dimListener = new ActionListener(this) {
      private final TablePane this$0;
      
      public void actionPerformed(ActionEvent param1ActionEvent) {
        int i = Integer.parseInt(this.this$0.rows.getText());
        int j = Integer.parseInt(this.this$0.cols.getText());
        if (this.this$0.elem instanceof ChartXElement) {
          i++;
          j++;
        } 
        this.this$0.model.setDimension(i, j);
      }
    };
  
  int hrow;
  
  int hcol;
  
  JTable table;
  
  JTextField rows = new JTextField(3);
  
  JTextField cols = new JTextField(3);
  
  JButton dim = new JButton(Catalog.getString("Set Dimension"));
  
  JTextField hrows = new JTextField(3);
  
  JTextField hcols = new JTextField(3);
  
  JCheckBox embed = new JCheckBox(Catalog.getString("Embed Data"));
  
  TableData model = new TableData();
  
  Tabular elem;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\TablePane.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */