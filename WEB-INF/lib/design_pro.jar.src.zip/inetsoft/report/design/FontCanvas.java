/*     */ package inetsoft.report.design;
/*     */ 
/*     */ import inetsoft.report.Common;
/*     */ import inetsoft.report.StyleFont;
/*     */ import inetsoft.report.locale.Catalog;
/*     */ import java.awt.AWTEventMulticaster;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.FlowLayout;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComponent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class FontCanvas
/*     */   extends JComponent
/*     */ {
/*     */   protected ActionListener actionListener;
/*     */   Font font;
/*     */   
/*  35 */   public FontCanvas() { this(new Font("Serif", 0, 10)); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDisplayFont(Font paramFont) {
/*     */     setFont(paramFont);
/*     */     this.font = paramFont;
/*     */     repaint(100L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FontCanvas(Font paramFont) {
/* 125 */     this.actionListener = null; this.font = paramFont; setLayout(new FlowLayout(0, 3, 0)); add(new DisplayArea(this)); JButton jButton = new JButton("..."); Font font1 = new Font("Serif", 0, 10); jButton.setFont(font1); jButton.setPreferredSize(new Dimension((int)Common.stringWidth("...", font1) + 8, 18)); jButton.setFocusPainted(false); add(jButton);
/*     */     jButton.addActionListener(new ActionListener(this) { private final FontCanvas this$0; public void actionPerformed(ActionEvent param1ActionEvent) { Font font = FontChooser.showDialog(this.this$0, Catalog.getString("Select Font"), (this.this$0.font == null) ? this.this$0.getFont() : this.this$0.font);
/*     */             if (font != null) {
/*     */               this.this$0.font = font;
/*     */               this.this$0.processActionEvent(new ActionEvent(this.this$0, 1001, "select"));
/*     */               this.this$0.repaint(100L);
/*     */             }  } });
/* 132 */   } public void addActionListener(ActionListener paramActionListener) { this.actionListener = AWTEventMulticaster.add(this.actionListener, paramActionListener); } public Font getDisplayFont() { return this.font; } class DisplayArea extends Component {
/*     */     private final FontCanvas this$0; DisplayArea(FontCanvas this$0) { this.this$0 = this$0; } public Dimension getPreferredSize() { return new Dimension(120, 18); } public void paint(Graphics param1Graphics) { Dimension dimension = getSize(); param1Graphics.setColor(getBackground()); param1Graphics.fillRect(0, 0, dimension.width, dimension.height); param1Graphics.draw3DRect(0, 0, dimension.width - 1, dimension.height - 1, false); if (this.this$0.font == null)
/*     */         return; 
/*     */       FontMetrics fontMetrics = getFontMetrics(this.this$0.font);
/*     */       String str = StyleFont.toString(this.this$0.font);
/*     */       param1Graphics.setColor(getForeground());
/*     */       param1Graphics.setFont(this.this$0.font);
/*     */       Common.drawString(param1Graphics, str, (dimension.width - Common.stringWidth(str, this.this$0.font)) / 2.0F, (dimension.height - Common.getHeight(this.this$0.font, fontMetrics)) / 2.0F + fontMetrics.getAscent()); } }
/* 140 */   public void removeActionListener(ActionListener paramActionListener) { this.actionListener = AWTEventMulticaster.remove(this.actionListener, paramActionListener); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void processActionEvent(ActionEvent paramActionEvent) {
/* 148 */     if (this.actionListener != null)
/* 149 */       this.actionListener.actionPerformed(paramActionEvent); 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\FontCanvas.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */