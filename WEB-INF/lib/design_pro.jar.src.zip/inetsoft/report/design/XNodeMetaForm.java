package inetsoft.report.design;

import inetsoft.report.lens.AbstractFormLens;
import inetsoft.uql.XNode;
import inetsoft.uql.schema.XTypeNode;
import java.util.Date;

class XNodeMetaForm extends AbstractFormLens {
  Object[] header;
  
  Object[] row;
  
  public XNodeMetaForm(XTypeNode paramXTypeNode) {
    this.header = new Object[paramXTypeNode.getChildCount()];
    this.row = new Object[paramXTypeNode.getChildCount()];
    for (byte b = 0; b < this.row.length; b++) {
      XNode xNode = paramXTypeNode.getChild(b);
      this.header[b] = xNode.getAttribute("alias");
      if (this.header[b] == null)
        this.header[b] = xNode.getName(); 
      this.row[b] = getExampler((String)this.header[b], ((XTypeNode)paramXTypeNode.getChild(b)).getType());
    } 
    if (this.row.length == 0) {
      this.header = new Object[] { "Unknown" };
      this.row = new Object[] { "XXXXX" };
    } 
  }
  
  public int getFieldCount() { return this.row.length; }
  
  public Object getField(int paramInt) { return this.row[paramInt]; }
  
  public Object getLabel(int paramInt) { return this.header[paramInt]; }
  
  protected Object getExampler(String paramString1, String paramString2) {
    if (paramString2.equals("string"))
      return getString('X', Math.min(5, paramString1.length())); 
    if (paramString2.equals("boolean"))
      return Boolean.TRUE; 
    if (paramString2.equals("float"))
      return new Float(99999.99D); 
    if (paramString2.equals("double"))
      return new Double(99999.99D); 
    if (paramString2.equals("char"))
      return "X"; 
    if (paramString2.equals("byte"))
      return new Byte((byte)-25); 
    if (paramString2.equals("short"))
      return new Short((short)-31073); 
    if (paramString2.equals("integer"))
      return new Integer(99999); 
    if (paramString2.equals("long"))
      return new Long(99999L); 
    if (paramString2.equals("timeInstant"))
      return new Date(); 
    if (paramString2.equals("date"))
      return new Date(); 
    if (paramString2.equals("time"))
      return new Date(); 
    return getString('X', Math.min(5, paramString1.length()));
  }
  
  String getString(char paramChar, int paramInt) {
    StringBuffer stringBuffer = new StringBuffer();
    for (byte b = 0; b < paramInt; b++)
      stringBuffer.append(paramChar); 
    return stringBuffer.toString();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\XNodeMetaForm.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */