/*     */ package inetsoft.report.design;
/*     */ 
/*     */ import inetsoft.report.lens.AbstractFormLens;
/*     */ import inetsoft.uql.XNode;
/*     */ import inetsoft.uql.schema.XTypeNode;
/*     */ import java.util.Date;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class XNodeMetaForm
/*     */   extends AbstractFormLens
/*     */ {
/*     */   Object[] header;
/*     */   Object[] row;
/*     */   
/*     */   public XNodeMetaForm(XTypeNode paramXTypeNode) {
/*  32 */     this.header = new Object[paramXTypeNode.getChildCount()];
/*  33 */     this.row = new Object[paramXTypeNode.getChildCount()];
/*     */     
/*  35 */     for (byte b = 0; b < this.row.length; b++) {
/*  36 */       XNode xNode = paramXTypeNode.getChild(b);
/*  37 */       this.header[b] = xNode.getAttribute("alias");
/*  38 */       if (this.header[b] == null) {
/*  39 */         this.header[b] = xNode.getName();
/*     */       }
/*     */       
/*  42 */       this.row[b] = getExampler((String)this.header[b], ((XTypeNode)paramXTypeNode.getChild(b)).getType());
/*     */     } 
/*     */ 
/*     */     
/*  46 */     if (this.row.length == 0) {
/*  47 */       this.header = new Object[] { "Unknown" };
/*  48 */       this.row = new Object[] { "XXXXX" };
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  57 */   public int getFieldCount() { return this.row.length; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  66 */   public Object getField(int paramInt) { return this.row[paramInt]; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  74 */   public Object getLabel(int paramInt) { return this.header[paramInt]; }
/*     */ 
/*     */   
/*     */   protected Object getExampler(String paramString1, String paramString2) {
/*  78 */     if (paramString2.equals("string")) {
/*  79 */       return getString('X', Math.min(5, paramString1.length()));
/*     */     }
/*  81 */     if (paramString2.equals("boolean")) {
/*  82 */       return Boolean.TRUE;
/*     */     }
/*  84 */     if (paramString2.equals("float")) {
/*  85 */       return new Float(99999.99D);
/*     */     }
/*  87 */     if (paramString2.equals("double")) {
/*  88 */       return new Double(99999.99D);
/*     */     }
/*  90 */     if (paramString2.equals("char")) {
/*  91 */       return "X";
/*     */     }
/*  93 */     if (paramString2.equals("byte")) {
/*  94 */       return new Byte((byte)-25);
/*     */     }
/*  96 */     if (paramString2.equals("short")) {
/*  97 */       return new Short((short)-31073);
/*     */     }
/*  99 */     if (paramString2.equals("integer")) {
/* 100 */       return new Integer(99999);
/*     */     }
/* 102 */     if (paramString2.equals("long")) {
/* 103 */       return new Long(99999L);
/*     */     }
/* 105 */     if (paramString2.equals("timeInstant")) {
/* 106 */       return new Date();
/*     */     }
/* 108 */     if (paramString2.equals("date")) {
/* 109 */       return new Date();
/*     */     }
/* 111 */     if (paramString2.equals("time")) {
/* 112 */       return new Date();
/*     */     }
/*     */     
/* 115 */     return getString('X', Math.min(5, paramString1.length()));
/*     */   }
/*     */   
/*     */   String getString(char paramChar, int paramInt) {
/* 119 */     StringBuffer stringBuffer = new StringBuffer();
/* 120 */     for (byte b = 0; b < paramInt; b++) {
/* 121 */       stringBuffer.append(paramChar);
/*     */     }
/*     */     
/* 124 */     return stringBuffer.toString();
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\XNodeMetaForm.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */