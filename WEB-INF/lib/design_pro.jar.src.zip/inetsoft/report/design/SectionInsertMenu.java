package inetsoft.report.design;

import inetsoft.report.TableLens;
import inetsoft.report.internal.SectionXElement;
import inetsoft.report.internal.TextElementDef;
import inetsoft.report.lens.DefaultTextLens;
import inetsoft.report.locale.Catalog;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JMenu;
import javax.swing.JMenuItem;

public class SectionInsertMenu extends JMenu {
  ActionListener sectionTableListener;
  
  ActionListener sectionTextListener;
  
  ActionListener sectionTextboxListener;
  
  ActionListener sectionChartListener;
  
  ActionListener sectionImageListener;
  
  ActionListener sectionPainterListener;
  
  ActionListener sectionTabListener;
  
  ActionListener sectionSeparatorListener;
  
  ActionListener fieldListener;
  
  JMenuItem fieldM;
  
  DesignView view;
  
  public SectionInsertMenu() { this(null); }
  
  public SectionInsertMenu(DesignView paramDesignView) {
    super(Catalog.getString("Insert"));
    this.sectionTableListener = new ActionListener(this) {
        private final SectionInsertMenu this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.getDesignView().insertTable(5, 5, true); }
      };
    this.sectionTextListener = new ActionListener(this) {
        private final SectionInsertMenu this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.getDesignView().insertText(true); }
      };
    this.sectionTextboxListener = new ActionListener(this) {
        private final SectionInsertMenu this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.getDesignView().insertTextBox(true); }
      };
    this.sectionChartListener = new ActionListener(this) {
        private final SectionInsertMenu this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.getDesignView().insertChart(5, true); }
      };
    this.sectionImageListener = new ActionListener(this) {
        private final SectionInsertMenu this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.getDesignView().insertImage(true); }
      };
    this.sectionPainterListener = new ActionListener(this) {
        private final SectionInsertMenu this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.getDesignView().insertPainter(true); }
      };
    this.sectionTabListener = new ActionListener(this) {
        private final SectionInsertMenu this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.getDesignView().insertTab(true); }
      };
    this.sectionSeparatorListener = new ActionListener(this) {
        private final SectionInsertMenu this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.getDesignView().insertSeparator(true); }
      };
    this.fieldListener = new ActionListener(this) {
        private final SectionInsertMenu this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) {
          DesignView designView = this.this$0.getDesignView();
          SectionXElement sectionXElement = (SectionXElement)designView.getCurrent();
          TableLens tableLens = sectionXElement.getTable();
          String str = (String)FieldsDialog.show(tableLens);
          if (str != null) {
            TextElementDef textElementDef = new TextElementDef(designView.getStyleSheet(), new DefaultTextLens(str));
            textElementDef.setProperty("__BINDING__", str);
            designView.insert(textElementDef, true);
          } 
        }
      };
    this.view = paramDesignView;
    JMenuItem jMenuItem;
    add(jMenuItem = new JMenuItem(Catalog.getString("Text")));
    jMenuItem.addActionListener(this.sectionTextListener);
    add(jMenuItem = new JMenuItem(Catalog.getString("Text Box")));
    jMenuItem.addActionListener(this.sectionTextboxListener);
    add(jMenuItem = new JMenuItem(Catalog.getString("Image")));
    jMenuItem.addActionListener(this.sectionImageListener);
    add(jMenuItem = new JMenuItem(Catalog.getString("Chart")));
    jMenuItem.addActionListener(this.sectionChartListener);
    add(jMenuItem = new JMenuItem(Catalog.getString("Table")));
    jMenuItem.addActionListener(this.sectionTableListener);
    add(jMenuItem = new JMenuItem(Catalog.getString("Painter")));
    jMenuItem.addActionListener(this.sectionPainterListener);
    add(jMenuItem = new JMenuItem(Catalog.getString("Tab")));
    jMenuItem.addActionListener(this.sectionTabListener);
    add(jMenuItem = new JMenuItem(Catalog.getString("Separator")));
    jMenuItem.addActionListener(this.sectionSeparatorListener);
    addSeparator();
    add(this.fieldM = new JMenuItem(Catalog.getString("Data Field") + "..."));
    this.fieldM.setMnemonic('D');
    this.fieldM.addActionListener(this.fieldListener);
  }
  
  public DesignView getDesignView() { return this.view; }
  
  public ActionListener getFieldListener() { return this.fieldListener; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\SectionInsertMenu.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */