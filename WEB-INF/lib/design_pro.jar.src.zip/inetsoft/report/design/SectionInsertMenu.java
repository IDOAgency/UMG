/*     */ package inetsoft.report.design;
/*     */ 
/*     */ import inetsoft.report.TableLens;
/*     */ import inetsoft.report.internal.SectionXElement;
/*     */ import inetsoft.report.internal.TextElementDef;
/*     */ import inetsoft.report.lens.DefaultTextLens;
/*     */ import inetsoft.report.locale.Catalog;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import javax.swing.JMenu;
/*     */ import javax.swing.JMenuItem;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SectionInsertMenu
/*     */   extends JMenu
/*     */ {
/*     */   ActionListener sectionTableListener;
/*     */   ActionListener sectionTextListener;
/*     */   ActionListener sectionTextboxListener;
/*     */   ActionListener sectionChartListener;
/*     */   ActionListener sectionImageListener;
/*     */   ActionListener sectionPainterListener;
/*     */   ActionListener sectionTabListener;
/*     */   ActionListener sectionSeparatorListener;
/*     */   ActionListener fieldListener;
/*     */   JMenuItem fieldM;
/*     */   DesignView view;
/*     */   
/*  36 */   public SectionInsertMenu() { this(null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SectionInsertMenu(DesignView paramDesignView) {
/*  43 */     super(Catalog.getString("Insert"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  86 */     this.sectionTableListener = new ActionListener(this)
/*     */       {
/*  88 */         public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.getDesignView().insertTable(5, 5, true); }
/*     */         
/*     */         private final SectionInsertMenu this$0;
/*     */       };
/*  92 */     this.sectionTextListener = new ActionListener(this)
/*     */       {
/*  94 */         public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.getDesignView().insertText(true); }
/*     */         
/*     */         private final SectionInsertMenu this$0;
/*     */       };
/*  98 */     this.sectionTextboxListener = new ActionListener(this)
/*     */       {
/* 100 */         public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.getDesignView().insertTextBox(true); }
/*     */         
/*     */         private final SectionInsertMenu this$0;
/*     */       };
/* 104 */     this.sectionChartListener = new ActionListener(this)
/*     */       {
/* 106 */         public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.getDesignView().insertChart(5, true); }
/*     */         
/*     */         private final SectionInsertMenu this$0;
/*     */       };
/* 110 */     this.sectionImageListener = new ActionListener(this)
/*     */       {
/* 112 */         public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.getDesignView().insertImage(true); }
/*     */         
/*     */         private final SectionInsertMenu this$0;
/*     */       };
/* 116 */     this.sectionPainterListener = new ActionListener(this)
/*     */       {
/* 118 */         public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.getDesignView().insertPainter(true); }
/*     */         
/*     */         private final SectionInsertMenu this$0;
/*     */       };
/* 122 */     this.sectionTabListener = new ActionListener(this)
/*     */       {
/* 124 */         public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.getDesignView().insertTab(true); }
/*     */         
/*     */         private final SectionInsertMenu this$0;
/*     */       };
/* 128 */     this.sectionSeparatorListener = new ActionListener(this)
/*     */       {
/* 130 */         public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.getDesignView().insertSeparator(true); }
/*     */         
/*     */         private final SectionInsertMenu this$0;
/*     */       };
/* 134 */     this.fieldListener = new ActionListener(this) {
/*     */         public void actionPerformed(ActionEvent param1ActionEvent) {
/* 136 */           DesignView designView = this.this$0.getDesignView();
/* 137 */           SectionXElement sectionXElement = (SectionXElement)designView.getCurrent();
/* 138 */           TableLens tableLens = sectionXElement.getTable();
/*     */           
/* 140 */           String str = (String)FieldsDialog.show(tableLens);
/* 141 */           if (str != null) {
/* 142 */             TextElementDef textElementDef = new TextElementDef(designView.getStyleSheet(), new DefaultTextLens(str));
/*     */ 
/*     */ 
/*     */             
/* 146 */             textElementDef.setProperty("__BINDING__", str);
/* 147 */             designView.insert(textElementDef, true);
/*     */           } 
/*     */         }
/*     */         
/*     */         private final SectionInsertMenu this$0;
/*     */       };
/*     */     this.view = paramDesignView;
/*     */     JMenuItem jMenuItem;
/*     */     add(jMenuItem = new JMenuItem(Catalog.getString("Text")));
/*     */     jMenuItem.addActionListener(this.sectionTextListener);
/*     */     add(jMenuItem = new JMenuItem(Catalog.getString("Text Box")));
/*     */     jMenuItem.addActionListener(this.sectionTextboxListener);
/*     */     add(jMenuItem = new JMenuItem(Catalog.getString("Image")));
/*     */     jMenuItem.addActionListener(this.sectionImageListener);
/*     */     add(jMenuItem = new JMenuItem(Catalog.getString("Chart")));
/*     */     jMenuItem.addActionListener(this.sectionChartListener);
/*     */     add(jMenuItem = new JMenuItem(Catalog.getString("Table")));
/*     */     jMenuItem.addActionListener(this.sectionTableListener);
/*     */     add(jMenuItem = new JMenuItem(Catalog.getString("Painter")));
/*     */     jMenuItem.addActionListener(this.sectionPainterListener);
/*     */     add(jMenuItem = new JMenuItem(Catalog.getString("Tab")));
/*     */     jMenuItem.addActionListener(this.sectionTabListener);
/*     */     add(jMenuItem = new JMenuItem(Catalog.getString("Separator")));
/*     */     jMenuItem.addActionListener(this.sectionSeparatorListener);
/*     */     addSeparator();
/*     */     add(this.fieldM = new JMenuItem(Catalog.getString("Data Field") + "..."));
/*     */     this.fieldM.setMnemonic('D');
/*     */     this.fieldM.addActionListener(this.fieldListener);
/*     */   }
/*     */   
/*     */   public DesignView getDesignView() { return this.view; }
/*     */   
/*     */   public ActionListener getFieldListener() { return this.fieldListener; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\SectionInsertMenu.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */