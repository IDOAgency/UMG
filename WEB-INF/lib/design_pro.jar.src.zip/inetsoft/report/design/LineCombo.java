/*     */ package inetsoft.report.design;
/*     */ 
/*     */ import inetsoft.report.Common;
/*     */ import inetsoft.report.locale.Catalog;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JList;
/*     */ import javax.swing.ListCellRenderer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LineCombo
/*     */   extends JComboBox
/*     */ {
/*  34 */   public LineCombo() { this(false); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LineCombo(boolean paramBoolean) {
/*  43 */     super(paramBoolean ? fn_line_styles : line_styles);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 122 */     this.fontOnly = true; this.fontOnly = paramBoolean; setRenderer(new LineRenderer(this));
/*     */     setLightWeightPopupEnabled(false); } static Integer[] line_styles = { 
/* 124 */       new Integer(-1), new Integer(0), new Integer(4097), new Integer(4098), new Integer(4099), new Integer(8195), new Integer(4113), new Integer(4145), new Integer(528384), new Integer(266240), new Integer(4193), new Integer(4241), new Integer(24578), new Integer(40962), new Integer(24579), new Integer(40963) };
/*     */ 
/*     */ 
/*     */   
/*     */   public int getSelectedLineStyle() {
/*     */     Object object = getSelectedItem();
/*     */     if (object == null) {
/*     */       return 0;
/*     */     }
/*     */     return ((Integer)object).intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSelectedLineStyle(int paramInt) { setSelectedItem(new Integer(paramInt)); }
/*     */ 
/*     */ 
/*     */   
/*     */   static Integer[] fn_line_styles = { 
/* 143 */       new Integer(0), new Integer(4097), new Integer(528384), new Integer(266240), new Integer(4098), new Integer(4099), new Integer(8195), new Integer(4113), new Integer(4145), new Integer(4193), new Integer(4241) };
/*     */   
/*     */   class LineRenderer extends Component implements ListCellRenderer {
/*     */     int style;
/*     */     boolean sel;
/*     */     private final LineCombo this$0;
/*     */     
/*     */     LineRenderer(LineCombo this$0) { this.this$0 = this$0; }
/*     */     
/*     */     public Component getListCellRendererComponent(JList param1JList, Object param1Object, int param1Int, boolean param1Boolean1, boolean param1Boolean2) {
/*     */       this.style = (param1Object == null) ? 0 : ((Integer)param1Object).intValue();
/*     */       this.sel = param1Boolean1;
/*     */       return this;
/*     */     }
/*     */     
/*     */     public void paint(Graphics param1Graphics) {
/*     */       Dimension dimension = getSize();
/*     */       param1Graphics.setColor(Color.black);
/*     */       param1Graphics.setFont(LineCombo.itemfont);
/*     */       FontMetrics fontMetrics = param1Graphics.getFontMetrics();
/*     */       if (this.style == 528384) {
/*     */         param1Graphics.drawString("(" + Catalog.getString("thin thin line") + ")", 4, (dimension.height - fontMetrics.getHeight()) / 2 + fontMetrics.getAscent());
/*     */       } else if (this.style == 266240) {
/*     */         param1Graphics.drawString("(" + Catalog.getString("ulra thin line") + ")", 4, (dimension.height - fontMetrics.getHeight()) / 2 + fontMetrics.getAscent());
/*     */       } else if (this.style == 0) {
/*     */         param1Graphics.drawString("(" + Catalog.getString("none") + ")", 4, (dimension.height - fontMetrics.getHeight()) / 2 + fontMetrics.getAscent());
/*     */       } else if (this.style > 0) {
/*     */         Common.drawHLine(param1Graphics, (dimension.height - Common.getLineWidth(this.style)) / 2.0F, 4.0F, (dimension.width - 8), this.style, 0, 0);
/*     */       } 
/*     */       if (this.sel)
/*     */         param1Graphics.drawRect(0, 0, dimension.width - 1, dimension.height - 1); 
/*     */     }
/*     */     
/*     */     public Dimension getPreferredSize() { return new Dimension(40, 16); }
/*     */     
/*     */     public Dimension getMinimumSize() { return getPreferredSize(); }
/*     */   }
/*     */   static Font itemfont = new Font("Serif", 0, 10);
/*     */   boolean fontOnly;
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\LineCombo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */