/*     */ package inetsoft.report.design;
/*     */ 
/*     */ import inetsoft.report.locale.Catalog;
/*     */ import java.awt.Font;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.util.Hashtable;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.JTree;
/*     */ import javax.swing.tree.DefaultMutableTreeNode;
/*     */ import javax.swing.tree.DefaultTreeCellRenderer;
/*     */ import javax.swing.tree.DefaultTreeModel;
/*     */ import javax.swing.tree.TreePath;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class JSTree
/*     */   extends JTree
/*     */ {
/*     */   TreeNode2 top;
/*     */   Hashtable branchmap;
/*     */   
/*     */   public JSTree(String paramString, String[] paramArrayOfString) {
/* 139 */     this.top = null;
/* 140 */     this.branchmap = new Hashtable();
/*     */     this.top = new TreeNode2(paramString);
/*     */     for (byte b = 0; b < paramArrayOfString.length; b++) {
/*     */       try {
/*     */         populateTree(paramArrayOfString[b]);
/*     */       } catch (IOException iOException) {}
/*     */     } 
/*     */     setCellRenderer(new CellRenderer(this));
/*     */     setModel(new DefaultTreeModel(this.top));
/*     */     setFont(new Font("Dialog", 0, 10));
/*     */     setRowHeight(14);
/*     */   }
/*     */   
/*     */   private void populateTree(String paramString) throws IOException {
/*     */     InputStream inputStream = getClass().getResourceAsStream(paramString);
/*     */     BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
/*     */     TreeNode2 treeNode2 = new TreeNode2(Catalog.getString("Default"));
/*     */     String str;
/*     */     while ((str = bufferedReader.readLine()) != null) {
/*     */       if (str.charAt(0) != '\t') {
/*     */         treeNode2 = (TreeNode2)this.branchmap.get(str);
/*     */         if (treeNode2 == null)
/*     */           this.branchmap.put(str, treeNode2 = new TreeNode2(str)); 
/*     */         this.top.add(treeNode2);
/*     */         continue;
/*     */       } 
/*     */       str = str.trim();
/*     */       int i = str.indexOf('\t');
/*     */       String str1 = null;
/*     */       if (i > 0) {
/*     */         str1 = str.substring(i + 1);
/*     */         str = str.substring(0, i);
/*     */       } 
/*     */       TreeNode2 treeNode21 = new TreeNode2(str);
/*     */       treeNode21.setObject(str1);
/*     */       treeNode2.add(treeNode21);
/*     */     } 
/*     */   }
/*     */   
/*     */   public String getSelectedValue() {
/*     */     TreePath[] arrayOfTreePath = getSelectionPaths();
/*     */     if (arrayOfTreePath != null)
/*     */       for (byte b = 0; b < arrayOfTreePath.length; b++) {
/*     */         TreeNode2 treeNode2 = (TreeNode2)arrayOfTreePath[b].getLastPathComponent();
/*     */         if (treeNode2.isLeaf()) {
/*     */           String str = treeNode2.getObject();
/*     */           return (str == null) ? treeNode2.toString() : str;
/*     */         } 
/*     */       }  
/*     */     return null;
/*     */   }
/*     */   
/*     */   static class TreeNode2 extends DefaultMutableTreeNode {
/*     */     String obj;
/*     */     
/*     */     public TreeNode2(String param1String) throws IOException { super(param1String); }
/*     */     
/*     */     public void setObject(String param1String) throws IOException { this.obj = param1String; }
/*     */     
/*     */     public String getObject() { return this.obj; }
/*     */   }
/*     */   
/*     */   class CellRenderer extends DefaultTreeCellRenderer {
/*     */     private final JSTree this$0;
/*     */     
/*     */     CellRenderer(JSTree this$0) { this.this$0 = this$0; }
/*     */     
/*     */     public Icon getLeafIcon() { return null; }
/*     */     
/*     */     public Icon getClosedIcon() { return null; }
/*     */     
/*     */     public Icon getOpenIcon() { return null; }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\JSTree.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */