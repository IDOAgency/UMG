/*     */ package inetsoft.report.design;
/*     */ 
/*     */ import inetsoft.report.StyleSheet;
/*     */ import inetsoft.report.internal.j2d.NumField;
/*     */ import inetsoft.report.internal.j2d.Property2Panel;
/*     */ import inetsoft.report.locale.Catalog;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import javax.swing.DefaultListModel;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JList;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.ListModel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TabDefProperty
/*     */   extends PropertyDialog
/*     */ {
/*     */   ActionListener setListener;
/*     */   StyleSheet page;
/*     */   NumField pos;
/*     */   JList stops;
/*     */   JButton setB;
/*     */   JButton clearB;
/*     */   JButton clearAllB;
/*     */   DefaultListModel model;
/*     */   
/*     */   public TabDefProperty(DesignView paramDesignView) {
/*  35 */     super(paramDesignView);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 102 */     this.setListener = new ActionListener(this)
/*     */       {
/*     */         public void actionPerformed(ActionEvent param1ActionEvent) {
/* 105 */           if (this.this$0.pos.getText().length() == 0) {
/*     */             return;
/*     */           }
/*     */           
/* 109 */           double d = Double.valueOf(this.this$0.pos.getText()).doubleValue();
/*     */           
/* 111 */           for (byte b = 0; b < this.this$0.model.getSize(); b++) {
/* 112 */             if (d < Double.valueOf(this.this$0.model.getElementAt(b).toString()).doubleValue()) {
/*     */               
/* 114 */               this.this$0.model.insertElementAt(this.this$0.pos.getText(), b);
/*     */               
/*     */               return;
/*     */             } 
/*     */           } 
/* 119 */           this.this$0.model.addElement(this.this$0.pos.getText());
/* 120 */           this.this$0.pos.setText("");
/*     */         }
/*     */         
/*     */         private final TabDefProperty this$0;
/*     */       };
/* 125 */     this.pos = new NumField(10, false);
/* 126 */     this.stops = new JList();
/* 127 */     this.setB = new JButton(Catalog.getString("Set"));
/* 128 */     this.clearB = new JButton(Catalog.getString("Clear"));
/* 129 */     this.clearAllB = new JButton(Catalog.getString("Clear All"));
/* 130 */     this.model = new DefaultListModel();
/*     */     setTitle(Catalog.getString("Tab Properties"));
/*     */     Property2Panel property2Panel = new Property2Panel();
/*     */     JScrollPane jScrollPane = new JScrollPane(this.stops);
/*     */     JPanel jPanel = new JPanel();
/*     */     jPanel.setLayout(new BorderLayout(5, 10));
/*     */     jPanel.add(this.clearB, "North");
/*     */     jPanel.add(this.clearAllB, "South");
/*     */     jScrollPane.setPreferredSize(new Dimension(100, 100));
/*     */     property2Panel.add(Catalog.getString("Tab Stops"), new Object[][] { { this.pos, this.setB }, { jScrollPane, jPanel } });
/*     */     this.folder.addTab(Catalog.getString("Tab"), null, property2Panel, Catalog.getString("Tab"));
/*     */     this.clearAllB.addActionListener(new ActionListener(this) {
/*     */           private final TabDefProperty this$0;
/*     */           
/*     */           public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.model.removeAllElements(); }
/*     */         });
/*     */     this.clearB.addActionListener(new ActionListener(this) {
/*     */           private final TabDefProperty this$0;
/*     */           
/*     */           public void actionPerformed(ActionEvent param1ActionEvent) {
/*     */             int[] arrayOfInt = this.this$0.stops.getSelectedIndices();
/*     */             for (int i = arrayOfInt.length - 1; i >= 0; i--)
/*     */               this.this$0.model.removeElementAt(arrayOfInt[i]); 
/*     */           }
/*     */         });
/*     */     this.pos.addActionListener(this.setListener);
/*     */     this.setB.addActionListener(this.setListener);
/*     */   }
/*     */   
/*     */   public void setElement(StyleSheet paramStyleSheet) {
/*     */     this.page = paramStyleSheet;
/*     */     setElement(null);
/*     */     this.model.removeAllElements();
/*     */     double[] arrayOfDouble = paramStyleSheet.getCurrentTabStops();
/*     */     for (byte b = 0; b < arrayOfDouble.length; b++)
/*     */       this.model.addElement(Double.toString(arrayOfDouble[b])); 
/*     */     this.stops.setModel(this.model);
/*     */   }
/*     */   
/*     */   public boolean populateElement() {
/*     */     ListModel listModel = this.stops.getModel();
/*     */     double[] arrayOfDouble = new double[listModel.getSize()];
/*     */     for (byte b = 0; b < arrayOfDouble.length; b++)
/*     */       arrayOfDouble[b] = Double.valueOf((String)listModel.getElementAt(b)).doubleValue(); 
/*     */     this.page.setCurrentTabStops(arrayOfDouble);
/*     */     return true;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\TabDefProperty.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */