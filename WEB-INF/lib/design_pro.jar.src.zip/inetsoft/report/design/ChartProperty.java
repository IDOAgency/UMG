package inetsoft.report.design;

import inetsoft.report.ChartDescriptor;
import inetsoft.report.ChartLens;
import inetsoft.report.ReportElement;
import inetsoft.report.internal.ChartXElement;
import inetsoft.report.internal.j2d.NumField;
import inetsoft.report.internal.j2d.Property2Panel;
import inetsoft.report.lens.AttributeChartLens;
import inetsoft.report.locale.Catalog;
import inetsoft.widget.ColorComboBox;
import inetsoft.widget.Spinner;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import javax.swing.ButtonGroup;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class ChartProperty extends PainterProperty {
  ItemListener enableListener;
  
  ItemListener dsListener;
  
  ItemListener ds2Listener;
  
  ItemListener styleListener;
  
  public ChartProperty(DesignView paramDesignView) {
    super(paramDesignView);
    this.enableListener = new ItemListener(this) {
        private final ChartProperty this$0;
        
        public void itemStateChanged(ItemEvent param1ItemEvent) { this.this$0.setEnabled(); }
      };
    this.dsListener = new ItemListener(this) {
        private final ChartProperty this$0;
        
        public void itemStateChanged(ItemEvent param1ItemEvent) {
          int i = this.this$0.getDSIndex();
          if (i >= 0) {
            this.this$0.style2.removeItemListener(this.this$0.ds2Listener);
            this.this$0.ptstyle.removeItemListener(this.this$0.ds2Listener);
            this.this$0.style2.setSelectedIndex(ChartProperty.getStyleIndex(this.this$0.style2s[i]));
            this.this$0.ptstyle.setSelectedIndex(ChartProperty.getPointStyleIndex(this.this$0.ptstyles[i]));
            this.this$0.style2.addItemListener(this.this$0.ds2Listener);
            this.this$0.ptstyle.addItemListener(this.this$0.ds2Listener);
          } 
          this.this$0.setEnabled();
        }
      };
    this.ds2Listener = new ItemListener(this) {
        private final ChartProperty this$0;
        
        public void itemStateChanged(ItemEvent param1ItemEvent) {
          int i = this.this$0.getDSIndex();
          if (i >= 0) {
            if (this.this$0.style2.getSelectedIndex() >= 0)
              this.this$0.style2s[i] = ChartProperty.styleopts[this.this$0.style2.getSelectedIndex()]; 
            if (this.this$0.ptstyle.getSelectedIndex() >= 0)
              this.this$0.ptstyles[i] = ChartProperty.ptstyleopts[this.this$0.ptstyle.getSelectedIndex()]; 
          } 
          this.this$0.setEnabled();
        }
      };
    this.styleListener = new ItemListener(this) {
        private final ChartProperty this$0;
        
        public void itemStateChanged(ItemEvent param1ItemEvent) {
          switch (ChartProperty.styleopts[this.this$0.style.getSelectedIndex()]) {
            case 5122:
              this.this$0.styleLO.show(this.this$0.styleOp, "lineW");
              return;
            case 5124:
              this.this$0.styleLO.show(this.this$0.styleOp, "pointW");
              return;
            case 1:
            case 3:
              this.this$0.styleLO.show(this.this$0.styleOp, "barborder");
              return;
          } 
          this.this$0.styleLO.show(this.this$0.styleOp, "null");
        }
      };
    this.style = new JComboBox(stylenames);
    this.xtitle = new JTextField(14);
    this.ytitle = new JTextField(14);
    this.max = new NumField(4, false, true);
    this.min = new NumField(4, false, true);
    this.inc = new NumField(4, false, true);
    this.minc = new NumField(4, false, true);
    this.gap = new NumField(2, true);
    this.font = new FontCanvas();
    this.grid = new LineCombo(true);
    this.border = new LineCombo();
    this.showv = new JCheckBox(Catalog.getString("Show Values"));
    this.lpos = new JComboBox(posnames);
    this.datapane = new TablePane(2);
    this.styleOp = new JPanel();
    this.styleLO = new CardLayout();
    this.barborder = new JCheckBox(Catalog.getString("Border around bars"));
    this.lineW = new Spinner(1, 5);
    this.pointW = new Spinner(2, 20);
    this.xrotate = new NumField(4, false);
    this.yFormat = new JTextField(14);
    this.vFormat = new JTextField(14);
    this.yCB = new JComboBox(formatnames);
    this.vCB = new JComboBox(formatnames);
    this.yLog = new JCheckBox(Catalog.getString("Logarithmic Scale"));
    this.vgrid = new LineCombo(true);
    this.ds1 = new JCheckBox(Catalog.getString("1st"));
    this.ds2 = new JCheckBox(Catalog.getString("2nd"));
    this.ds3 = new JCheckBox(Catalog.getString("3rd"));
    this.ds4 = new JCheckBox(Catalog.getString("4th"));
    this.ds5 = new JCheckBox(Catalog.getString("5th"));
    this.ds6 = new JCheckBox(Catalog.getString("6th"));
    this.ds7 = new JCheckBox(Catalog.getString("7th"));
    this.ds8 = new JCheckBox(Catalog.getString("8th"));
    this.style2 = new JComboBox(stylenames);
    this.ptstyle = new JComboBox(ptstylenames);
    this.y2Format = new JTextField(14);
    this.y2CB = new JComboBox(formatnames);
    this.first2ds = new JComboBox(dsindexes);
    this.y2Log = new JCheckBox(Catalog.getString("Logarithmic Scale"));
    this.y2title = new JTextField(14);
    this.max2 = new NumField(4, false);
    this.min2 = new NumField(4, false);
    this.inc2 = new NumField(4, false);
    this.minc2 = new NumField(4, false);
    this.colors = new ColorComboBox[] { 
        new ColorComboBox(), new ColorComboBox(), new ColorComboBox(), new ColorComboBox(), new ColorComboBox(), new ColorComboBox(), new ColorComboBox(), new ColorComboBox(), new ColorComboBox(), new ColorComboBox(), 
        new ColorComboBox(), new ColorComboBox() };
    this.style2s = new int[10];
    this.ptstyles = new int[] { 908, 904, 907, 902, 906, 910, 900, 901, 905, 909 };
    setTitle(Catalog.getString("Chart Properties"));
    this.styleOp.setLayout(this.styleLO);
    JPanel jPanel = new JPanel();
    jPanel.add(new JLabel(Catalog.getString("Line Width") + ":"));
    jPanel.add(this.lineW);
    this.styleOp.add(jPanel, "lineW");
    jPanel = new JPanel();
    jPanel.add(new JLabel(Catalog.getString("Point Size") + ":"));
    jPanel.add(this.pointW);
    this.pointW.setCurrent(6);
    this.styleOp.add(jPanel, "pointW");
    this.styleOp.add(this.barborder, "barborder");
    this.styleOp.add(new JLabel(""), "null");
    this.styleLO.show(this.styleOp, "null");
    Property2Panel property2Panel1 = new Property2Panel();
    property2Panel1.add(Catalog.getString("Style"), new Object[][] { { Catalog.getString("Style") + ":", this.style, this.styleOp } });
    property2Panel1.add(Catalog.getString("Y Axis"), new Object[][] { { Catalog.getString("Title") + ":", new Integer(3), this.ytitle, null, this.yLog }, { Catalog.getString("Max") + ":", this.max, Catalog.getString("Min") + ":", this.min, Catalog.getString("Increment") + ":", this.inc, Catalog.getString("Minor Increment") + ":", this.minc } });
    property2Panel1.add(Catalog.getString("Misc"), new Object[][] { { Catalog.getString("Title Font") + ":", this.font, Catalog.getString("Legend Position") + ":", this.lpos }, { Catalog.getString("Grid Style") + ":", this.grid, Catalog.getString("Chart Border") + ":", this.border }, { Catalog.getString("Vertical Grid") + ":", this.vgrid, Catalog.getString("Bar Gap Space"), this.gap }, { Catalog.getString("X Title") + ":", this.xtitle, Catalog.getString("X Label Rotation") + ":", this.xrotate }, { Catalog.getString("Y Label Format") + ":", this.yFormat, this.yCB }, { Catalog.getString("Value Format") + ":", this.vFormat, this.vCB, this.showv } });
    Property2Panel property2Panel2 = new Property2Panel();
    property2Panel2.add(Catalog.getString("Multi Chart Style"), new Object[][] { { this.ds1, this.ds2, this.ds3, this.ds4, this.ds5, this.ds6, this.ds7, this.ds8 }, { new Integer(2), Catalog.getString("Chart Style") + ":", new Integer(4), this.style2 }, { new Integer(2), Catalog.getString("Point Style") + ":", new Integer(4), this.ptstyle } });
    property2Panel2.add(Catalog.getString("Secondary Y Axis"), new Object[][] { { new Integer(3), Catalog.getString("First Dataset on Secondary Y Axis") + ":", this.first2ds }, { Catalog.getString("Title") + ":", new Integer(3), this.y2title, null, this.y2Log }, { Catalog.getString("Max") + ":", this.max2, Catalog.getString("Min") + ":", this.min2, Catalog.getString("Increment") + ":", this.inc2, Catalog.getString("Minor Increment") + ":", this.minc2 }, { new Integer(2), Catalog.getString("Y Label Format") + ":", new Integer(3), this.y2Format, this.y2CB } });
    property2Panel2.add(Catalog.getString("Colors"), new Object[][] { this.colors });
    this.folder.insertTab(Catalog.getString("Chart"), null, property2Panel1, Catalog.getString("Chart Property"), 0);
    this.folder.insertTab(Catalog.getString("Advanced"), null, property2Panel2, Catalog.getString("Advanced Chart Property"), 1);
    this.folder.addTab(Catalog.getString("Labels and Data"), null, this.datapane, Catalog.getString("Chart Labels and Data"));
    this.style.addItemListener(this.styleListener);
    this.yCB.addItemListener(new FormatListener(this, this.yFormat));
    this.y2CB.addItemListener(new FormatListener(this, this.y2Format));
    this.vCB.addItemListener(new FormatListener(this, this.vFormat));
    this.showv.addItemListener(this.enableListener);
    this.first2ds.addItemListener(this.enableListener);
    this.ds1.addItemListener(this.dsListener);
    this.ds2.addItemListener(this.dsListener);
    this.ds3.addItemListener(this.dsListener);
    this.ds4.addItemListener(this.dsListener);
    this.ds5.addItemListener(this.dsListener);
    this.ds6.addItemListener(this.dsListener);
    this.ds7.addItemListener(this.dsListener);
    this.ds8.addItemListener(this.dsListener);
    this.style2.addItemListener(this.ds2Listener);
    this.ptstyle.addItemListener(this.ds2Listener);
    ButtonGroup buttonGroup = new ButtonGroup();
    buttonGroup.add(this.ds1);
    buttonGroup.add(this.ds2);
    buttonGroup.add(this.ds3);
    buttonGroup.add(this.ds4);
    buttonGroup.add(this.ds5);
    buttonGroup.add(this.ds6);
    buttonGroup.add(this.ds7);
    buttonGroup.add(this.ds8);
    setEnabled();
  }
  
  public void setElement(ReportElement paramReportElement) {
    this.elem = (ChartXElement)paramReportElement;
    ChartDescriptor chartDescriptor = this.elem.getChartDescriptor();
    super.setElement(paramReportElement);
    if (paramReportElement.getProperty("query") != null) {
      this.folder.setEnabledAt(1, false);
    } else {
      this.folder.setEnabledAt(1, true);
      this.datapane.setElement(this.elem);
    } 
    ChartLens chartLens = this.elem.getChart();
    this.style.setSelectedIndex(getStyleIndex(chartLens.getStyle()));
    this.xtitle.setText(chartLens.getXTitle());
    this.ytitle.setText(chartLens.getYTitle());
    this.max.setText((chartLens.getMaximum() == null) ? "" : chartLens.getMaximum().toString());
    this.min.setText((chartLens.getMinimum() == null) ? "" : chartLens.getMinimum().toString());
    this.inc.setText((chartLens.getIncrement() == null) ? "" : chartLens.getIncrement().toString());
    this.minc.setText((chartLens.getMinorIncrement() == null) ? "" : chartLens.getMinorIncrement().toString());
    this.gap.setValue(chartLens.getGap());
    this.font.setDisplayFont(chartLens.getTitleFont());
    this.grid.setSelectedLineStyle(chartLens.getGridStyle());
    this.border.setSelectedLineStyle(chartLens.getBorderStyle());
    this.showv.setSelected(chartLens.isShowValue());
    for (byte b1 = 0; b1 < this.style2s.length; b1++)
      this.style2s[b1] = chartLens.getStyle(b1); 
    for (byte b2 = 0; b2 < posopts.length; b2++) {
      if (chartLens.getLegendPosition() == posopts[b2]) {
        this.lpos.setSelectedIndex(b2);
        break;
      } 
    } 
    for (byte b3 = 0; b3 < this.colors.length; b3++) {
      Object object = chartLens.getColor(b3);
      if (object instanceof Color)
        this.colors[b3].setSelectedColor((Color)object); 
    } 
    if (chartDescriptor != null) {
      this.barborder.setSelected(chartDescriptor.isBarBorder());
      this.lineW.setCurrent((int)chartDescriptor.getLineChartLineWidth());
      this.pointW.setCurrent((int)chartDescriptor.getPointSize());
      this.xrotate.setValue(chartDescriptor.getXLabelRotation() * 180.0D / Math.PI);
      DecimalFormat decimalFormat = (DecimalFormat)chartDescriptor.getYAxisFormat();
      this.yFormat.setText((decimalFormat == null) ? "" : decimalFormat.toPattern());
      decimalFormat = (DecimalFormat)chartDescriptor.getSecondaryYAxisFormat();
      this.y2Format.setText((decimalFormat == null) ? "" : decimalFormat.toPattern());
      decimalFormat = (DecimalFormat)chartDescriptor.getValueFormat();
      this.vFormat.setText((decimalFormat == null) ? "" : decimalFormat.toPattern());
      this.vgrid.setSelectedLineStyle(chartDescriptor.getVerticalGridStyle());
      this.yLog.setSelected(chartDescriptor.isLogarithmicYScale());
      this.y2Log.setSelected(chartDescriptor.isSecondaryLogarithmicYScale());
      this.y2title.setText(chartDescriptor.getSecondaryYTitle());
      this.first2ds.setSelectedIndex(chartDescriptor.getFirstDatasetOfSecondaryAxis() + 1);
      this.max2.setText((chartDescriptor.getSecondaryMaximum() == null) ? "" : chartDescriptor.getSecondaryMaximum().toString());
      this.min2.setText((chartDescriptor.getSecondaryMinimum() == null) ? "" : chartDescriptor.getSecondaryMinimum().toString());
      this.inc2.setText((chartDescriptor.getSecondaryIncrement() == null) ? "" : chartDescriptor.getSecondaryIncrement().toString());
      this.minc2.setText((chartDescriptor.getSecondaryMinorIncrement() == null) ? "" : chartDescriptor.getSecondaryMinorIncrement().toString());
      for (byte b = 0; b < this.ptstyles.length; b++)
        this.ptstyles[b] = chartDescriptor.getPointStyle(b); 
    } 
  }
  
  public boolean populateElement() {
    if (!super.populateElement())
      return false; 
    if (this.folder.isEnabledAt(1))
      this.datapane.populateElement(); 
    AttributeChartLens attributeChartLens = (AttributeChartLens)this.elem.getChart();
    ChartDescriptor chartDescriptor = new ChartDescriptor();
    attributeChartLens.setStyle(styleopts[this.style.getSelectedIndex()]);
    attributeChartLens.setXTitle(this.xtitle.getText());
    attributeChartLens.setYTitle(this.ytitle.getText());
    attributeChartLens.setMaximum(this.max.doubleObject());
    attributeChartLens.setMinimum(this.min.doubleObject());
    attributeChartLens.setIncrement(this.inc.doubleObject());
    attributeChartLens.setMinorIncrement(this.minc.doubleObject());
    attributeChartLens.setGap(this.gap.intValue());
    attributeChartLens.setTitleFont(this.font.getDisplayFont());
    attributeChartLens.setGridStyle(this.grid.getSelectedLineStyle());
    attributeChartLens.setBorderStyle(this.border.getSelectedLineStyle());
    attributeChartLens.setShowValue(this.showv.isSelected());
    attributeChartLens.setLegendPosition(posopts[this.lpos.getSelectedIndex()]);
    this.elem.setChartDescriptor(chartDescriptor);
    chartDescriptor.setBarBorder(this.barborder.isSelected());
    chartDescriptor.setLineChartLineWidth(this.lineW.getCurrent());
    chartDescriptor.setPointSize(this.pointW.getCurrent());
    chartDescriptor.setXLabelRotation(this.xrotate.doubleValue() * Math.PI / 180.0D);
    chartDescriptor.setVerticalGridStyle(this.vgrid.getSelectedLineStyle());
    chartDescriptor.setLogarithmicYScale(this.yLog.isSelected());
    chartDescriptor.setSecondaryLogarithmicYScale(this.y2Log.isSelected());
    chartDescriptor.setSecondaryYTitle(this.y2title.getText());
    chartDescriptor.setFirstDatasetOfSecondaryAxis(this.first2ds.getSelectedIndex() - 1);
    String str = this.yFormat.getText();
    if (str.length() > 0)
      chartDescriptor.setYAxisFormat(new DecimalFormat(str)); 
    str = this.y2Format.getText();
    if (str.length() > 0)
      chartDescriptor.setSecondaryYAxisFormat(new DecimalFormat(str)); 
    str = this.vFormat.getText();
    if (str.length() > 0)
      chartDescriptor.setValueFormat(new DecimalFormat(str)); 
    chartDescriptor.setSecondaryMaximum(this.max2.doubleObject());
    chartDescriptor.setSecondaryMinimum(this.min2.doubleObject());
    chartDescriptor.setSecondaryIncrement(this.inc2.doubleObject());
    chartDescriptor.setSecondaryMinorIncrement(this.minc2.doubleObject());
    for (byte b1 = 0; b1 < this.style2s.length; b1++)
      attributeChartLens.setStyle(b1, this.style2s[b1]); 
    for (byte b2 = 0; b2 < this.ptstyles.length; b2++)
      chartDescriptor.setPointStyle(b2, this.ptstyles[b2]); 
    for (byte b3 = 0; b3 < this.colors.length; b3++)
      attributeChartLens.setColor(b3, this.colors[b3].getSelectedColor()); 
    return true;
  }
  
  public void setEnabled() {
    this.vFormat.setEnabled(this.showv.isSelected());
    this.vCB.setEnabled(this.showv.isSelected());
    int i = getDSIndex();
    this.style2.setEnabled((i >= 0));
    this.ptstyle.setEnabled((i >= 0));
    int j = this.first2ds.getSelectedIndex();
    this.y2Format.setEnabled((j > 0));
    this.y2CB.setEnabled((j > 0));
    this.y2Log.setEnabled((j > 0));
    this.y2title.setEnabled((j > 0));
    this.max2.setEnabled((j > 0));
    this.min2.setEnabled((j > 0));
    this.inc2.setEnabled((j > 0));
    this.minc2.setEnabled((j > 0));
  }
  
  private int getDSIndex() {
    if (this.ds1.isSelected())
      return 0; 
    if (this.ds2.isSelected())
      return 1; 
    if (this.ds3.isSelected())
      return 2; 
    if (this.ds4.isSelected())
      return 3; 
    if (this.ds5.isSelected())
      return 4; 
    if (this.ds6.isSelected())
      return 5; 
    if (this.ds7.isSelected())
      return 6; 
    if (this.ds8.isSelected())
      return 7; 
    return -1;
  }
  
  public static String[] getStyleNames() { return stylenames; }
  
  public static int getStyle(String paramString) {
    for (byte b = 0; b < stylenames.length; b++) {
      if (Catalog.getString(paramString).equals(stylenames[b]))
        return styleopts[b]; 
    } 
    return styleopts[0];
  }
  
  private static int getStyleIndex(int paramInt) {
    for (byte b = 0; b < styleopts.length; b++) {
      if (paramInt == styleopts[b])
        return b; 
    } 
    return -1;
  }
  
  public static int getPointStyle(String paramString) {
    for (byte b = 0; b < ptstylenames.length; b++) {
      if (Catalog.getString(paramString).equals(ptstylenames[b]))
        return ptstyleopts[b]; 
    } 
    return ptstyleopts[0];
  }
  
  private static int getPointStyleIndex(int paramInt) {
    for (byte b = 0; b < ptstyleopts.length; b++) {
      if (paramInt == ptstyleopts[b])
        return b; 
    } 
    return -1;
  }
  
  class FormatListener implements ItemListener {
    JTextField text;
    
    private final ChartProperty this$0;
    
    public FormatListener(ChartProperty this$0, JTextField param1JTextField) {
      this.this$0 = this$0;
      this.text = param1JTextField;
    }
    
    public void itemStateChanged(ItemEvent param1ItemEvent) {
      String str = (String)param1ItemEvent.getItem();
      DecimalFormat decimalFormat = null;
      if (str.equals(ChartProperty.formatnames[1])) {
        decimalFormat = (DecimalFormat)NumberFormat.getNumberInstance();
      } else if (str.equals(ChartProperty.formatnames[2])) {
        decimalFormat = (DecimalFormat)NumberFormat.getCurrencyInstance();
      } else if (str.equals(ChartProperty.formatnames[3])) {
        decimalFormat = (DecimalFormat)NumberFormat.getPercentInstance();
      } 
      if (decimalFormat != null)
        this.text.setText(decimalFormat.toPattern()); 
    }
  }
  
  static final String[] stylenames = { 
      Catalog.getString("3D Bar"), Catalog.getString("3D Stack Bar"), Catalog.getString("Pie"), Catalog.getString("Line"), Catalog.getString("Point"), Catalog.getString("Bar"), Catalog.getString("Stack Bar"), Catalog.getString("3D Pie"), Catalog.getString("3D Bar 3D Coord"), Catalog.getString("Area"), 
      Catalog.getString("Stack Area"), Catalog.getString("Inverted Bar"), Catalog.getString("Inverted Stack Bar"), Catalog.getString("Inverted Line"), Catalog.getString("Inverted Point"), Catalog.getString("Pie - No Label"), Catalog.getString("3D Pie - No Label"), Catalog.getString("Stick"), Catalog.getString("Stock"), Catalog.getString("Scattered"), 
      Catalog.getString("XY Line"), Catalog.getString("Bubble"), Catalog.getString("Radar"), Catalog.getString("Filled Radar"), Catalog.getString("Candle") };
  
  static final int[] styleopts = { 
      5, 7, 6, 5122, 5124, 1, 3, 8, 9, 12, 
      14, 257, 259, 5378, 5380, 8198, 8200, 4107, 4106, 5636, 
      5634, 528, 1041, 18, 20 };
  
  static final String[] ptstylenames = { 
      Catalog.getString("(none)"), Catalog.getString("CIRCLE"), Catalog.getString("TRIANGLE"), Catalog.getString("SQUARE"), Catalog.getString("CROSS"), Catalog.getString("STAR"), Catalog.getString("DIAMOND"), Catalog.getString("X"), Catalog.getString("FILLED_CIRCLE"), Catalog.getString("FILLED_TRIANGLE"), 
      Catalog.getString("FILLED_SQUARE"), Catalog.getString("FILLED_DIAMOND") };
  
  static final int[] ptstyleopts = { 
      0, 900, 901, 902, 903, 904, 905, 906, 907, 908, 
      909, 910 };
  
  static final String[] posnames = { Catalog.getString("None"), Catalog.getString("Top"), Catalog.getString("Left"), Catalog.getString("Bottom"), Catalog.getString("Right") };
  
  static final int[] posopts = { 0, 8, 1, 32, 4 };
  
  static final String[] formatnames = { "", Catalog.getString("Number"), Catalog.getString("Currency"), Catalog.getString("Percent") };
  
  static final String[] dsindexes = { 
      "(none)", "1st", "2nd", "3rd", "4th", "5th", "6th", "7th", "8th", "9th", 
      "10th" };
  
  ChartXElement elem;
  
  JComboBox style;
  
  JTextField xtitle;
  
  JTextField ytitle;
  
  NumField max;
  
  NumField min;
  
  NumField inc;
  
  NumField minc;
  
  NumField gap;
  
  FontCanvas font;
  
  LineCombo grid;
  
  LineCombo border;
  
  JCheckBox showv;
  
  JComboBox lpos;
  
  TablePane datapane;
  
  JPanel styleOp;
  
  CardLayout styleLO;
  
  JCheckBox barborder;
  
  Spinner lineW;
  
  Spinner pointW;
  
  NumField xrotate;
  
  JTextField yFormat;
  
  JTextField vFormat;
  
  JComboBox yCB;
  
  JComboBox vCB;
  
  JCheckBox yLog;
  
  LineCombo vgrid;
  
  JCheckBox ds1;
  
  JCheckBox ds2;
  
  JCheckBox ds3;
  
  JCheckBox ds4;
  
  JCheckBox ds5;
  
  JCheckBox ds6;
  
  JCheckBox ds7;
  
  JCheckBox ds8;
  
  JComboBox style2;
  
  JComboBox ptstyle;
  
  JTextField y2Format;
  
  JComboBox y2CB;
  
  JComboBox first2ds;
  
  JCheckBox y2Log;
  
  JTextField y2title;
  
  NumField max2;
  
  NumField min2;
  
  NumField inc2;
  
  NumField minc2;
  
  ColorComboBox[] colors;
  
  int[] style2s;
  
  int[] ptstyles;
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\ChartProperty.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */