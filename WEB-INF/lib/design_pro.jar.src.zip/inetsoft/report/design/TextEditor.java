/*     */ package inetsoft.report.design;
/*     */ 
/*     */ import inetsoft.report.ReportElement;
/*     */ import inetsoft.report.internal.BaseElement;
/*     */ import inetsoft.report.internal.TextBased;
/*     */ import java.awt.Color;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Point;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.event.FocusAdapter;
/*     */ import java.awt.event.FocusEvent;
/*     */ import java.awt.event.FocusListener;
/*     */ import java.awt.event.KeyAdapter;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.awt.event.KeyListener;
/*     */ import javax.swing.JTextArea;
/*     */ import javax.swing.event.DocumentEvent;
/*     */ import javax.swing.event.DocumentListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class TextEditor
/*     */   extends JTextArea
/*     */ {
/*     */   FocusListener editorListener;
/*     */   DocumentListener resizeListener;
/*     */   KeyListener keyListener;
/*     */   TextBased elem;
/*     */   String otext;
/*     */   boolean isnew;
/*     */   boolean fixed;
/*     */   boolean vonly;
/*     */   Rectangle box;
/*     */   Rectangle bounds;
/*     */   boolean otextmode;
/*     */   Point initpt;
/*     */   DesignPane pane;
/*     */   
/*     */   public TextEditor(DesignPane paramDesignPane) {
/* 209 */     this.editorListener = new FocusAdapter(this) {
/*     */         public void focusLost(FocusEvent param1FocusEvent) {
/* 211 */           if (!param1FocusEvent.isTemporary()) {
/* 212 */             this.this$0.stop();
/*     */           }
/*     */         }
/*     */         
/*     */         private final TextEditor this$0;
/*     */       };
/* 218 */     this.resizeListener = new DocumentListener(this)
/*     */       {
/* 220 */         public void insertUpdate(DocumentEvent param1DocumentEvent) { this.this$0.setBounds(); }
/*     */ 
/*     */         
/*     */         private final TextEditor this$0;
/*     */         
/*     */         public void removeUpdate(DocumentEvent param1DocumentEvent) {}
/*     */         
/*     */         public void changedUpdate(DocumentEvent param1DocumentEvent) {}
/*     */       };
/* 229 */     this.keyListener = new KeyAdapter(this) {
/*     */         public void keyPressed(KeyEvent param1KeyEvent) {
/* 231 */           if (param1KeyEvent.getKeyCode() == 9) {
/* 232 */             param1KeyEvent.consume();
/* 233 */             this.this$0.stop();
/* 234 */             this.this$0.pane.insertTab(false);
/* 235 */             this.this$0.pane.getCurrentPage().requestFocus();
/*     */           } 
/*     */         }
/*     */         
/*     */         private final TextEditor this$0;
/*     */       };
/* 241 */     this.otext = "";
/* 242 */     this.isnew = false;
/* 243 */     this.fixed = false;
/* 244 */     this.vonly = false;
/* 245 */     this.box = new Rectangle(0, 0, 72, 72);
/* 246 */     this.bounds = new Rectangle(0, 0, 72, 72);
/* 247 */     this.otextmode = false;
/* 248 */     this.initpt = null;
/*     */     this.pane = paramDesignPane;
/*     */     setBorder(new ThinBevel(1, new Color(150, 150, 150), new Color(80, 80, 80)));
/*     */     setLineWrap(true);
/*     */     setWrapStyleWord(true);
/*     */     setBackground(new Color(240, 240, 240));
/*     */     setCaret(new ThickCaret());
/*     */     addFocusListener(this.editorListener);
/*     */     getDocument().addDocumentListener(this.resizeListener);
/*     */     addKeyListener(this.keyListener);
/*     */   }
/*     */   
/*     */   public void setParam(TextBased paramTextBased, boolean paramBoolean, Rectangle paramRectangle1, Rectangle paramRectangle2, Point paramPoint, String paramString) {
/*     */     this.elem = paramTextBased;
/*     */     this.isnew = paramBoolean;
/*     */     this.bounds = paramRectangle1;
/*     */     this.vonly = false;
/*     */     BaseElement baseElement = (BaseElement)paramTextBased;
/*     */     this.box = paramRectangle2;
/*     */     this.fixed = baseElement.getParent() instanceof inetsoft.report.FixedContainer;
/*     */     this.otextmode = this.pane.isTextMode();
/*     */     if (!this.pane.textmode) {
/*     */       this.pane.textmode = true;
/*     */       this.pane.fireEvent();
/*     */     } 
/*     */     String str = paramTextBased.getText();
/*     */     this.otext = (paramString == null) ? str : paramString;
/*     */     if (str.length() == 0) {
/*     */       setText(" ");
/*     */       setCaretPosition(1);
/*     */     } 
/*     */     setText(str);
/*     */     setFont(baseElement.getFont());
/*     */     setBounds();
/*     */     this.initpt = null;
/*     */     if (paramPoint != null && paramPoint.y == -1) {
/*     */       setCaretPosition(paramPoint.x);
/*     */     } else {
/*     */       setCaretPosition(getText().length());
/*     */       this.initpt = (paramPoint == null) ? null : new Point(paramPoint.x - paramRectangle1.x - this.pane.insets.left, paramPoint.y - paramRectangle1.y - this.pane.insets.top);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setBounds() {
/*     */     Dimension dimension = null;
/*     */     if (this.fixed) {
/*     */       setBounds(this.bounds.x + this.pane.insets.left, this.bounds.y + this.pane.insets.top, this.bounds.width, this.bounds.height);
/*     */       return;
/*     */     } 
/*     */     if (!this.vonly) {
/*     */       setLineWrap(false);
/*     */       dimension = getPreferredSize();
/*     */       setLineWrap(true);
/*     */       dimension.width = Math.max(dimension.width + 5, this.bounds.width);
/*     */       int i = this.box.x + this.box.width - this.bounds.x;
/*     */       dimension.width = Math.min(dimension.width, i);
/*     */       if (this.vonly = (dimension.width == i))
/*     */         if (dimension.width < this.box.width / 5) {
/*     */           this.bounds.x -= this.box.width / 5 - dimension.width;
/*     */           dimension.width = this.box.width / 5;
/*     */         }  
/*     */       setLocation(this.bounds.x + this.pane.insets.left, this.bounds.y + this.pane.insets.top);
/*     */     } else {
/*     */       dimension = getPreferredSize();
/*     */     } 
/*     */     dimension.height = Math.min(dimension.height, this.box.y + this.box.height - this.bounds.y);
/*     */     dimension.height = Math.max(dimension.height, this.bounds.height);
/*     */     setSize(dimension);
/*     */   }
/*     */   
/*     */   public void paint(Graphics paramGraphics) {
/*     */     if (this.initpt != null) {
/*     */       int i = viewToModel(this.initpt);
/*     */       if (i >= 0) {
/*     */         this.initpt = null;
/*     */         setCaretPosition(i);
/*     */       } 
/*     */     } 
/*     */     super.paint(paramGraphics);
/*     */   }
/*     */   
/*     */   public void resetTextMode(boolean paramBoolean) { this.otextmode = paramBoolean; }
/*     */   
/*     */   public void stop() {
/*     */     if (!this.pane.editing || !isVisible() || this.elem == null)
/*     */       return; 
/*     */     String str = getText();
/*     */     this.elem.setText(str);
/*     */     if (this.pane.textmode != this.otextmode) {
/*     */       this.pane.textmode = this.otextmode;
/*     */       this.pane.fireEvent();
/*     */     } 
/*     */     setVisible(false);
/*     */     Container container = getParent();
/*     */     if (container != null)
/*     */       container.remove(this); 
/*     */     if (this.isnew && (str.length() > 0 || this.elem instanceof inetsoft.report.TextBoxElement)) {
/*     */       this.pane.setChanged(true);
/*     */       this.pane.insert((ReportElement)this.elem, false);
/*     */     } else if (!this.otext.equals(str)) {
/*     */       this.pane.setChanged(true);
/*     */       if (str.length() == 0) {
/*     */         this.pane.remove((ReportElement)this.elem, true);
/*     */       } else {
/*     */         this.pane.reprint(this.pane.getCurrent());
/*     */       } 
/*     */     } else if (this.pane.getCurrentPage() != null) {
/*     */       this.pane.getCurrentPage().repaint(100L);
/*     */     } 
/*     */     this.pane.editing = false;
/*     */     this.elem = null;
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\TextEditor.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */