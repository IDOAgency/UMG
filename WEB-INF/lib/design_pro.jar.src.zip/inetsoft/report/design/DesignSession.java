package inetsoft.report.design;

import inetsoft.report.ChartElement;
import inetsoft.report.FormElement;
import inetsoft.report.ReportElement;
import inetsoft.report.SectionElement;
import inetsoft.report.StyleSheet;
import inetsoft.report.TableElement;
import inetsoft.report.TableFilter;
import inetsoft.report.XSessionManager;
import inetsoft.report.internal.ChartXElement;
import inetsoft.report.internal.DatasetAttr;
import inetsoft.report.lens.ChartTable;
import inetsoft.report.lens.TableChartLens;
import inetsoft.uql.VariableTable;
import inetsoft.uql.XDataService;
import inetsoft.uql.XNode;
import inetsoft.uql.XQuery;
import inetsoft.uql.XRepository;
import inetsoft.uql.builder.VariableEntry;
import inetsoft.uql.schema.UserVariable;
import inetsoft.uql.schema.XTypeNode;
import java.rmi.RemoteException;
import java.util.Hashtable;
import java.util.Vector;
import javax.swing.JOptionPane;

class DesignSession extends XSessionManager {
  public DesignSession() throws RemoteException {}
  
  public DesignSession(XDataService paramXDataService, Object paramObject) { super(paramXDataService, paramObject); }
  
  public void populateMetaData(StyleSheet paramStyleSheet) throws Exception {
    Vector vector1 = getAllElements(paramStyleSheet);
    XRepository xRepository = (XRepository)getDataService();
    Vector vector2 = new Vector();
    this.qmap.clear();
    for (byte b1 = 0; b1 < vector1.size(); b1++) {
      ReportElement reportElement = (ReportElement)vector1.elementAt(b1);
      String str = reportElement.getProperty("query");
      if (str != null)
        if (str.indexOf("::") >= 0) {
          if (str.startsWith("chart::"))
            vector2.addElement(reportElement); 
        } else {
          populateMetaData(reportElement);
        }  
    } 
    for (byte b2 = 0; b2 < vector2.size(); b2++) {
      TableElement tableElement = (TableElement)vector2.elementAt(b2);
      ChartElement chartElement = (ChartElement)paramStyleSheet.getElement(tableElement.getProperty("query").substring(7));
      if (chartElement != null)
        tableElement.setTable(new ChartTable(chartElement.getChart())); 
    } 
  }
  
  public void populateMetaData(ReportElement paramReportElement) throws Exception {
    String str = paramReportElement.getProperty("query");
    if (str == null)
      return; 
    XRepository xRepository = (XRepository)getDataService();
    XTypeNode xTypeNode = (XTypeNode)this.qmap.get(str);
    XQuery xQuery = xRepository.getQuery(str);
    if (xTypeNode == null) {
      if (xQuery == null) {
        JOptionPane.showMessageDialog(null, "Query not defined: " + str);
        return;
      } 
      xTypeNode = xQuery.getOutputType();
      if (xTypeNode != null)
        this.qmap.put(str, xTypeNode); 
    } 
    for (byte b = 0; b < xTypeNode.getChildCount(); b++) {
      String str1 = xTypeNode.getChild(b).getName();
      if (str1.endsWith(".*")) {
        VariableTable variableTable = new VariableTable();
        UserVariable[] arrayOfUserVariable = xRepository.getConnectionParameters(getSession(), str);
        if (arrayOfUserVariable != null && arrayOfUserVariable.length > 0) {
          variableTable = VariableEntry.show(arrayOfUserVariable);
          if (variableTable == null)
            continue; 
        } 
        xRepository.connect(getSession(), str, variableTable);
        XNode xNode1 = new XNode(str1.substring(0, str1.length() - 2));
        XNode xNode2 = xRepository.getMetaData(getSession(), xQuery.getDataSource(), xNode1);
        xTypeNode.removeChild(b);
        for (byte b1 = 0; b1 < xNode2.getChildCount(); b1++)
          xTypeNode.insertChild(b++, xNode2.getChild(b1)); 
        b--;
      } 
      continue;
    } 
    if (xTypeNode != null)
      if (paramReportElement instanceof ChartElement) {
        DatasetAttr datasetAttr = (paramReportElement instanceof ChartXElement) ? ((ChartXElement)paramReportElement).getDataset() : null;
        TableFilter tableFilter = new XNodeMetaTable(xTypeNode);
        if (datasetAttr != null)
          tableFilter = datasetAttr.createFilter(tableFilter); 
        TableChartLens tableChartLens = new TableChartLens(tableFilter);
        if (datasetAttr != null)
          tableChartLens.setLabelFormat(datasetAttr.getLabelFormat()); 
        ((ChartElement)paramReportElement).setChart(tableChartLens);
      } else if (paramReportElement instanceof FormElement) {
        ((FormElement)paramReportElement).setForm(new XNodeMetaForm(xTypeNode));
      } else if (paramReportElement instanceof TableElement) {
        ((TableElement)paramReportElement).setTable(new XNodeMetaTable(xTypeNode));
      } else if (paramReportElement instanceof SectionElement) {
        ((SectionElement)paramReportElement).setTable(new XNodeMetaTable(xTypeNode));
      }  
  }
  
  private Hashtable qmap = new Hashtable();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\DesignSession.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */