/*     */ package inetsoft.report.design;
/*     */ 
/*     */ import inetsoft.report.ChartElement;
/*     */ import inetsoft.report.FormElement;
/*     */ import inetsoft.report.ReportElement;
/*     */ import inetsoft.report.SectionElement;
/*     */ import inetsoft.report.StyleSheet;
/*     */ import inetsoft.report.TableElement;
/*     */ import inetsoft.report.TableFilter;
/*     */ import inetsoft.report.XSessionManager;
/*     */ import inetsoft.report.internal.ChartXElement;
/*     */ import inetsoft.report.internal.DatasetAttr;
/*     */ import inetsoft.report.lens.ChartTable;
/*     */ import inetsoft.report.lens.TableChartLens;
/*     */ import inetsoft.uql.VariableTable;
/*     */ import inetsoft.uql.XDataService;
/*     */ import inetsoft.uql.XNode;
/*     */ import inetsoft.uql.XQuery;
/*     */ import inetsoft.uql.XRepository;
/*     */ import inetsoft.uql.builder.VariableEntry;
/*     */ import inetsoft.uql.schema.UserVariable;
/*     */ import inetsoft.uql.schema.XTypeNode;
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ import javax.swing.JOptionPane;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DesignSession
/*     */   extends XSessionManager
/*     */ {
/*     */   public DesignSession() throws RemoteException {}
/*     */   
/*  49 */   public DesignSession(XDataService paramXDataService, Object paramObject) { super(paramXDataService, paramObject); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void populateMetaData(StyleSheet paramStyleSheet) throws Exception {
/*  56 */     Vector vector1 = getAllElements(paramStyleSheet);
/*  57 */     XRepository xRepository = (XRepository)getDataService();
/*     */     
/*  59 */     Vector vector2 = new Vector();
/*     */ 
/*     */     
/*  62 */     this.qmap.clear();
/*     */     
/*  64 */     for (byte b1 = 0; b1 < vector1.size(); b1++) {
/*  65 */       ReportElement reportElement = (ReportElement)vector1.elementAt(b1);
/*  66 */       String str = reportElement.getProperty("query");
/*     */       
/*  68 */       if (str != null) {
/*  69 */         if (str.indexOf("::") >= 0) {
/*     */           
/*  71 */           if (str.startsWith("chart::")) {
/*  72 */             vector2.addElement(reportElement);
/*     */           
/*     */           }
/*     */         }
/*     */         else {
/*     */           
/*  78 */           populateMetaData(reportElement);
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/*  83 */     for (byte b2 = 0; b2 < vector2.size(); b2++) {
/*  84 */       TableElement tableElement = (TableElement)vector2.elementAt(b2);
/*  85 */       ChartElement chartElement = (ChartElement)paramStyleSheet.getElement(tableElement.getProperty("query").substring(7));
/*     */ 
/*     */       
/*  88 */       if (chartElement != null) {
/*  89 */         tableElement.setTable(new ChartTable(chartElement.getChart()));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void populateMetaData(ReportElement paramReportElement) throws Exception {
/*  98 */     String str = paramReportElement.getProperty("query");
/*  99 */     if (str == null) {
/*     */       return;
/*     */     }
/*     */     
/* 103 */     XRepository xRepository = (XRepository)getDataService();
/* 104 */     XTypeNode xTypeNode = (XTypeNode)this.qmap.get(str);
/* 105 */     XQuery xQuery = xRepository.getQuery(str);
/*     */     
/* 107 */     if (xTypeNode == null) {
/* 108 */       if (xQuery == null) {
/* 109 */         JOptionPane.showMessageDialog(null, "Query not defined: " + str);
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 114 */       xTypeNode = xQuery.getOutputType();
/* 115 */       if (xTypeNode != null) {
/* 116 */         this.qmap.put(str, xTypeNode);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 121 */     for (byte b = 0; b < xTypeNode.getChildCount(); b++) {
/* 122 */       String str1 = xTypeNode.getChild(b).getName();
/*     */       
/* 124 */       if (str1.endsWith(".*")) {
/* 125 */         VariableTable variableTable = new VariableTable();
/* 126 */         UserVariable[] arrayOfUserVariable = xRepository.getConnectionParameters(getSession(), str);
/*     */ 
/*     */         
/* 129 */         if (arrayOfUserVariable != null && arrayOfUserVariable.length > 0) {
/* 130 */           variableTable = VariableEntry.show(arrayOfUserVariable);
/* 131 */           if (variableTable == null) {
/*     */             continue;
/*     */           }
/*     */         } 
/*     */         
/* 136 */         xRepository.connect(getSession(), str, variableTable);
/*     */         
/* 138 */         XNode xNode1 = new XNode(str1.substring(0, str1.length() - 2));
/* 139 */         XNode xNode2 = xRepository.getMetaData(getSession(), xQuery.getDataSource(), xNode1);
/*     */         
/* 141 */         xTypeNode.removeChild(b);
/*     */         
/* 143 */         for (byte b1 = 0; b1 < xNode2.getChildCount(); b1++) {
/* 144 */           xTypeNode.insertChild(b++, xNode2.getChild(b1));
/*     */         }
/* 146 */         b--;
/*     */       } 
/*     */       continue;
/*     */     } 
/* 150 */     if (xTypeNode != null) {
/* 151 */       if (paramReportElement instanceof ChartElement) {
/* 152 */         DatasetAttr datasetAttr = (paramReportElement instanceof ChartXElement) ? ((ChartXElement)paramReportElement).getDataset() : null;
/*     */ 
/*     */         
/* 155 */         TableFilter tableFilter = new XNodeMetaTable(xTypeNode);
/* 156 */         if (datasetAttr != null) {
/* 157 */           tableFilter = datasetAttr.createFilter(tableFilter);
/*     */         }
/*     */         
/* 160 */         TableChartLens tableChartLens = new TableChartLens(tableFilter);
/*     */         
/* 162 */         if (datasetAttr != null) {
/* 163 */           tableChartLens.setLabelFormat(datasetAttr.getLabelFormat());
/*     */         }
/*     */         
/* 166 */         ((ChartElement)paramReportElement).setChart(tableChartLens);
/*     */       }
/* 168 */       else if (paramReportElement instanceof FormElement) {
/* 169 */         ((FormElement)paramReportElement).setForm(new XNodeMetaForm(xTypeNode));
/*     */       }
/* 171 */       else if (paramReportElement instanceof TableElement) {
/* 172 */         ((TableElement)paramReportElement).setTable(new XNodeMetaTable(xTypeNode));
/*     */       }
/* 174 */       else if (paramReportElement instanceof SectionElement) {
/* 175 */         ((SectionElement)paramReportElement).setTable(new XNodeMetaTable(xTypeNode));
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/* 180 */   private Hashtable qmap = new Hashtable();
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\DesignSession.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */