package inetsoft.report.design;

import inetsoft.report.StyleSheet;
import inetsoft.report.locale.Catalog;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Enumeration;
import java.util.Hashtable;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JList;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.MenuElement;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

abstract class HeaderDialog extends JDialog {
  JComboBox elemCB;
  
  DefaultListModel list;
  
  JList headerLT;
  
  JScrollPane scroller;
  
  JButton closeB;
  
  JButton removeB;
  
  JButton addB;
  
  String message;
  
  String title;
  
  JPopupMenu menu;
  
  StyleSheet sheet;
  
  public HeaderDialog(Frame paramFrame, StyleSheet paramStyleSheet, Hashtable paramHashtable) {
    super(paramFrame, false);
    this.elemCB = new JComboBox(this) {
        private final HeaderDialog this$0;
        
        public Dimension getPreferredSize() {
          Dimension dimension = super.getPreferredSize();
          dimension.width = Math.max(dimension.width, 120);
          return dimension;
        }
      };
    this.list = new DefaultListModel();
    this.headerLT = new JList(this.list);
    this.scroller = new JScrollPane(this, this.headerLT) {
        private final HeaderDialog this$0;
        
        public Dimension getPreferredSize() {
          Dimension dimension = this.this$0.elemCB.getPreferredSize();
          return new Dimension(dimension.width, 100);
        }
      };
    this.closeB = new JButton(Catalog.getString("OK"));
    this.removeB = new JButton(Catalog.getString("Remove"));
    this.addB = new JButton(this, Catalog.getString("New")) {
        private final HeaderDialog this$0;
        
        public Dimension getPreferredSize() { return this.this$0.removeB.getPreferredSize(); }
      };
    this.message = Catalog.getString("Remove selected headers PERMANENTLY!?");
    this.title = Catalog.getString("Confirm Deletion");
    this.sheet = paramStyleSheet;
    getContentPane().setLayout(new BorderLayout(5, 5));
    JPanel jPanel = new JPanel();
    jPanel.setLayout(new FlowLayout(0, 10, 5));
    jPanel.add(this.elemCB);
    jPanel.add(this.addB);
    getContentPane().add(jPanel, "North");
    jPanel = new JPanel();
    jPanel.setLayout(new FlowLayout(0, 10, 5));
    jPanel.add(this.scroller);
    jPanel.add(this.removeB);
    getContentPane().add(jPanel, "Center");
    jPanel = new JPanel();
    jPanel.add(this.closeB);
    getContentPane().add(jPanel, "South");
    this.headerLT.setSelectionMode(0);
    this.addB.addActionListener(new ActionListener(this) {
          private final HeaderDialog this$0;
          
          public void actionPerformed(ActionEvent param1ActionEvent) {
            String str = (String)this.this$0.elemCB.getSelectedItem();
            if (str != null) {
              this.this$0.list.addElement(str);
              this.this$0.headerLT.setSelectedIndex(this.this$0.list.getSize() - 1);
              this.this$0.add(str);
            } 
          }
        });
    this.removeB.addActionListener(new ActionListener(this) {
          private final HeaderDialog this$0;
          
          public void actionPerformed(ActionEvent param1ActionEvent) {
            int i = JOptionPane.showConfirmDialog(this.this$0, this.this$0.message, this.this$0.title, 0);
            if (i != 0)
              return; 
            int j = this.this$0.headerLT.getSelectedIndex();
            if (j >= 0) {
              this.this$0.remove((String)this.this$0.headerLT.getSelectedValue());
              this.this$0.list.removeElementAt(j);
              this.this$0.removeB.setEnabled((this.this$0.headerLT.getSelectedIndex() >= 0));
            } 
          }
        });
    this.closeB.addActionListener(new ActionListener(this) {
          private final HeaderDialog this$0;
          
          public void actionPerformed(ActionEvent param1ActionEvent) {
            String str = (String)this.this$0.headerLT.getSelectedValue();
            if (this.this$0.menu != null && str != null) {
              MenuElement[] arrayOfMenuElement = this.this$0.menu.getSubElements();
              for (byte b = 0; b < arrayOfMenuElement.length; b++) {
                JMenuItem jMenuItem = (JMenuItem)arrayOfMenuElement[b];
                if (jMenuItem.getText().equals(str))
                  jMenuItem.setSelected(true); 
              } 
            } 
            this.this$0.dispose();
          }
        });
    for (byte b = 0; b < paramStyleSheet.getElementCount(); b++)
      this.elemCB.addItem(paramStyleSheet.getElement(b).getID()); 
    Enumeration enumeration = paramHashtable.keys();
    while (enumeration.hasMoreElements())
      this.list.addElement(enumeration.nextElement()); 
    this.removeB.setEnabled(false);
    this.headerLT.addListSelectionListener(new ListSelectionListener(this) {
          private final HeaderDialog this$0;
          
          public void valueChanged(ListSelectionEvent param1ListSelectionEvent) { this.this$0.removeB.setEnabled((this.this$0.headerLT.getSelectedIndex() >= 0)); }
        });
  }
  
  protected void setMenu(JPopupMenu paramJPopupMenu) { this.menu = paramJPopupMenu; }
  
  public abstract void add(String paramString);
  
  public abstract void remove(String paramString);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\HeaderDialog.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */