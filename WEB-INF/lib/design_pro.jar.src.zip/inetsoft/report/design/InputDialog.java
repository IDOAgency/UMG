package inetsoft.report.design;

import inetsoft.report.locale.Catalog;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

class InputDialog extends JDialog {
  ActionListener okListener;
  
  JTextField textTF;
  
  public static String show(String paramString1, String paramString2) {
    InputDialog inputDialog = new InputDialog(paramString1, paramString2);
    inputDialog.setModal(true);
    inputDialog.pack();
    inputDialog.setVisible(true);
    return inputDialog.textTF.getText();
  }
  
  public InputDialog(String paramString1, String paramString2) {
    this.okListener = new ActionListener(this) {
        private final InputDialog this$0;
        
        public void actionPerformed(ActionEvent param1ActionEvent) { this.this$0.dispose(); }
      };
    this.textTF = new JTextField(15);
    getContentPane().setLayout(new BorderLayout(5, 5));
    JPanel jPanel = new JPanel();
    jPanel.add(new JLabel(paramString1));
    jPanel.add(this.textTF);
    getContentPane().add(jPanel, "Center");
    if (paramString2 != null)
      this.textTF.setText(paramString2); 
    jPanel = new JPanel();
    getContentPane().add(jPanel, "South");
    JButton jButton = new JButton(Catalog.getString("OK"));
    jPanel.add(jButton);
    this.textTF.addActionListener(this.okListener);
    jButton.addActionListener(this.okListener);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\report\design\InputDialog.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */