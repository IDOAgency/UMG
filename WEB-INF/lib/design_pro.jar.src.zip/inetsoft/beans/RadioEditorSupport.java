/*     */ package inetsoft.beans;
/*     */ 
/*     */ import java.awt.Checkbox;
/*     */ import java.awt.CheckboxGroup;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.GridLayout;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class RadioEditorSupport
/*     */   extends OptionEditorSupport
/*     */ {
/*     */   public abstract int[] getRadioGroups();
/*     */   
/*  40 */   public Component getCustomEditor() { return new RadioEditor(this); }
/*     */   
/*     */   class RadioEditor
/*     */     extends Container {
/*     */     public RadioEditor(RadioEditorSupport this$0) {
/*  45 */       this.this$0 = this$0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 114 */       this.tags = this.this$0.getOptionTags();
/* 115 */       this.masks = this.this$0.getOptionMasks();
/* 116 */       this.groups = this.this$0.getRadioGroups();
/*     */       
/* 118 */       this.boxes = new Checkbox[this.tags.length];
/*     */       CheckboxGroup[] arrayOfCheckboxGroup = new CheckboxGroup[this.groups.length];
/*     */       for (byte b1 = 0; b1 < this.groups.length; b1++) {
/*     */         this.maxoptions = Math.max(this.maxoptions, this.groups[b1]);
/*     */         arrayOfCheckboxGroup[b1] = new CheckboxGroup();
/*     */       } 
/*     */       setLayout(new GridLayout(this.maxoptions, this.groups.length));
/*     */       int i = ((Integer)this$0.getValue()).intValue();
/*     */       RadioEditorSupport$1 radioEditorSupport$1 = new RadioEditorSupport$1(this);
/*     */       Component[][] arrayOfComponent = new Component[this.groups.length][this.maxoptions];
/*     */       byte b2 = 0;
/*     */       for (byte b3 = 0; b3 < arrayOfComponent.length; b3++) {
/*     */         for (byte b = 0; b < this.maxoptions && b < this.groups[b3]; b++) {
/*     */           this.boxes[b2] = new Checkbox(this.tags[b2], false, arrayOfCheckboxGroup[b3]);
/*     */           arrayOfComponent[b3][b] = this.boxes[b2];
/*     */           this.boxes[b2].addItemListener(radioEditorSupport$1);
/*     */           if ((i & this.masks[b2]) != 0)
/*     */             this.boxes[b2].setState(true); 
/*     */           b2++;
/*     */         } 
/*     */       } 
/*     */       for (byte b4 = 0; b4 < this.maxoptions; b4++) {
/*     */         for (byte b = 0; b < arrayOfComponent.length; b++) {
/*     */           if (arrayOfComponent[b][b4] != null)
/*     */             add(arrayOfComponent[b][b4]); 
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/*     */     String[] tags;
/*     */     int[] masks;
/*     */     int[] groups;
/*     */     int maxoptions;
/*     */     Checkbox[] boxes;
/*     */     private final RadioEditorSupport this$0;
/*     */     
/*     */     public Dimension getPreferredSize() {
/*     */       Dimension dimension = super.getPreferredSize();
/*     */       return (dimension.width > 0 && dimension.height > 0) ? dimension : new Dimension(120 * this.groups.length, this.maxoptions * 20);
/*     */     }
/*     */     
/*     */     void setRadio() {
/*     */       int i = 0;
/*     */       for (byte b = 0; b < this.boxes.length; b++) {
/*     */         if (this.boxes[b].getState())
/*     */           i |= this.masks[b]; 
/*     */       } 
/*     */       this.this$0.setValue(new Integer(i));
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\beans\RadioEditorSupport.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */