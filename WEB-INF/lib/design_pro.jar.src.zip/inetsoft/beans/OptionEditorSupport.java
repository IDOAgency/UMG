package inetsoft.beans;

import java.awt.Checkbox;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Rectangle;
import java.beans.PropertyEditorSupport;

public abstract class OptionEditorSupport extends PropertyEditorSupport {
  public abstract String[] getOptionTags();
  
  public abstract int[] getOptionMasks();
  
  public boolean isPaintable() { return true; }
  
  public void paintValue(Graphics paramGraphics, Rectangle paramRectangle) {
    Graphics graphics = paramGraphics.create(paramRectangle.x, paramRectangle.y, paramRectangle.width, paramRectangle.height);
    String[] arrayOfString = getOptionTags();
    int[] arrayOfInt = getOptionMasks();
    int i = ((Integer)getValue()).intValue();
    String str = null;
    for (byte b = 0; b < arrayOfInt.length; b++) {
      if ((arrayOfInt[b] & i) != 0)
        str = (str == null) ? arrayOfString[b] : (str + " | " + arrayOfString[b]); 
    } 
    FontMetrics fontMetrics = graphics.getFontMetrics();
    graphics.drawString(str, 0, paramRectangle.height / 2 + fontMetrics.getMaxDescent());
    graphics.dispose();
  }
  
  public boolean supportsCustomEditor() { return true; }
  
  public Component getCustomEditor() { return new OptionEditor(this); }
  
  class OptionEditor extends Container {
    String[] tags;
    
    int[] masks;
    
    Checkbox[] boxes;
    
    private final OptionEditorSupport this$0;
    
    public OptionEditor(OptionEditorSupport this$0) {
      this.this$0 = this$0;
      this.tags = this.this$0.getOptionTags();
      this.masks = this.this$0.getOptionMasks();
      this.boxes = new Checkbox[this.tags.length];
      setLayout(new GridLayout(this.tags.length, 1));
      int i = ((Integer)this$0.getValue()).intValue();
      OptionEditorSupport$1 optionEditorSupport$1 = new OptionEditorSupport$1(this);
      for (byte b = 0; b < this.tags.length; b++) {
        this.boxes[b] = new Checkbox(this.tags[b]);
        this.boxes[b].addItemListener(optionEditorSupport$1);
        if ((i & this.masks[b]) != 0)
          this.boxes[b].setState(true); 
        add(this.boxes[b]);
      } 
    }
    
    public Dimension getPreferredSize() {
      Dimension dimension = super.getPreferredSize();
      return (dimension.width > 0 && dimension.height > 0) ? dimension : new Dimension(150, this.tags.length * 20);
    }
    
    void setOption() {
      int i = 0;
      for (byte b = 0; b < this.boxes.length; b++) {
        if (this.boxes[b].getState())
          i |= this.masks[b]; 
      } 
      this.this$0.setValue(new Integer(i));
    }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\beans\OptionEditorSupport.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */