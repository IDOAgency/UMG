/*     */ package inetsoft.beans;
/*     */ 
/*     */ import java.awt.Checkbox;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.GridLayout;
/*     */ import java.awt.Rectangle;
/*     */ import java.beans.PropertyEditorSupport;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class OptionEditorSupport
/*     */   extends PropertyEditorSupport
/*     */ {
/*     */   public abstract String[] getOptionTags();
/*     */   
/*     */   public abstract int[] getOptionMasks();
/*     */   
/*  45 */   public boolean isPaintable() { return true; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void paintValue(Graphics paramGraphics, Rectangle paramRectangle) {
/*  52 */     Graphics graphics = paramGraphics.create(paramRectangle.x, paramRectangle.y, paramRectangle.width, paramRectangle.height);
/*  53 */     String[] arrayOfString = getOptionTags();
/*  54 */     int[] arrayOfInt = getOptionMasks();
/*  55 */     int i = ((Integer)getValue()).intValue();
/*  56 */     String str = null;
/*     */     
/*  58 */     for (byte b = 0; b < arrayOfInt.length; b++) {
/*  59 */       if ((arrayOfInt[b] & i) != 0) {
/*  60 */         str = (str == null) ? arrayOfString[b] : (str + " | " + arrayOfString[b]);
/*     */       }
/*     */     } 
/*     */     
/*  64 */     FontMetrics fontMetrics = graphics.getFontMetrics();
/*  65 */     graphics.drawString(str, 0, paramRectangle.height / 2 + fontMetrics.getMaxDescent());
/*  66 */     graphics.dispose();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  73 */   public boolean supportsCustomEditor() { return true; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  80 */   public Component getCustomEditor() { return new OptionEditor(this); }
/*     */   
/*     */   class OptionEditor
/*     */     extends Container {
/*     */     public OptionEditor(OptionEditorSupport this$0) {
/*  85 */       this.this$0 = this$0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 129 */       this.tags = this.this$0.getOptionTags();
/* 130 */       this.masks = this.this$0.getOptionMasks();
/* 131 */       this.boxes = new Checkbox[this.tags.length];
/*     */       setLayout(new GridLayout(this.tags.length, 1));
/*     */       int i = ((Integer)this$0.getValue()).intValue();
/*     */       OptionEditorSupport$1 optionEditorSupport$1 = new OptionEditorSupport$1(this);
/*     */       for (byte b = 0; b < this.tags.length; b++) {
/*     */         this.boxes[b] = new Checkbox(this.tags[b]);
/*     */         this.boxes[b].addItemListener(optionEditorSupport$1);
/*     */         if ((i & this.masks[b]) != 0)
/*     */           this.boxes[b].setState(true); 
/*     */         add(this.boxes[b]);
/*     */       } 
/*     */     }
/*     */     
/*     */     String[] tags;
/*     */     int[] masks;
/*     */     Checkbox[] boxes;
/*     */     private final OptionEditorSupport this$0;
/*     */     
/*     */     public Dimension getPreferredSize() {
/*     */       Dimension dimension = super.getPreferredSize();
/*     */       return (dimension.width > 0 && dimension.height > 0) ? dimension : new Dimension(150, this.tags.length * 20);
/*     */     }
/*     */     
/*     */     void setOption() {
/*     */       int i = 0;
/*     */       for (byte b = 0; b < this.boxes.length; b++) {
/*     */         if (this.boxes[b].getState())
/*     */           i |= this.masks[b]; 
/*     */       } 
/*     */       this.this$0.setValue(new Integer(i));
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\beans\OptionEditorSupport.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */