/*     */ package inetsoft.beans;
/*     */ 
/*     */ import java.awt.Image;
/*     */ import java.beans.Introspector;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.beans.SimpleBeanInfo;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AutoBeanInfo
/*     */   extends SimpleBeanInfo
/*     */ {
/*     */   private Hashtable pdmap;
/*     */   private Class bean;
/*     */   private String imagename;
/*     */   private String image32name;
/*     */   
/*     */   protected AutoBeanInfo(Class paramClass) {
/* 149 */     this.pdmap = new Hashtable();
/*     */     this.bean = paramClass;
/*     */     try {
/*     */       Method[] arrayOfMethod = paramClass.getMethods();
/*     */       for (byte b = 0; b < arrayOfMethod.length; b++) {
/*     */         if (Modifier.isPublic(arrayOfMethod[b].getModifiers())) {
/*     */           String str = arrayOfMethod[b].getName();
/*     */           if ((str.startsWith("get") && arrayOfMethod[b].getParameterTypes().length == 0) || (str.startsWith("set") && arrayOfMethod[b].getParameterTypes().length == 1)) {
/*     */             String str1 = Introspector.decapitalize(str.substring(3));
/*     */             Object object = this.pdmap.get(str1);
/*     */             object = (object != null) ? new Integer(((Integer)object).intValue() + 1) : new Integer(1);
/*     */             this.pdmap.put(str1, object);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       for (Enumeration enumeration = this.pdmap.keys(); enumeration.hasMoreElements(); ) {
/*     */         String str = (String)enumeration.nextElement();
/*     */         if (((Integer)this.pdmap.get(str)).intValue() < 2)
/*     */           this.pdmap.remove(str); 
/*     */       } 
/*     */     } catch (Exception exception) {
/*     */       exception.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void registerEditor(String paramString, Class paramClass) { this.pdmap.put(paramString, paramClass); }
/*     */   
/*     */   protected void setBean(Class paramClass) { this.bean = paramClass; }
/*     */   
/*     */   protected void setImage(String paramString) { this.imagename = paramString; }
/*     */   
/*     */   protected void setImage32(String paramString) { this.image32name = paramString; }
/*     */   
/*     */   public Image getIcon(int paramInt) {
/*     */     Image image;
/*     */     if (this.imagename == null && this.image32name == null)
/*     */       return null; 
/*     */     switch (paramInt) {
/*     */       case 1:
/*     */       case 3:
/*     */         image = loadImage((this.imagename != null) ? this.imagename : this.image32name);
/*     */         return image.getScaledInstance(16, 16, 4);
/*     */       case 2:
/*     */       case 4:
/*     */         image = loadImage((this.image32name != null) ? this.image32name : this.imagename);
/*     */         return image.getScaledInstance(32, 32, 4);
/*     */     } 
/*     */     return null;
/*     */   }
/*     */   
/*     */   public PropertyDescriptor[] getPropertyDescriptors() {
/*     */     try {
/*     */       PropertyDescriptor[] arrayOfPropertyDescriptor = new PropertyDescriptor[this.pdmap.size()];
/*     */       byte b = 0;
/*     */       for (Enumeration enumeration = this.pdmap.keys(); enumeration.hasMoreElements(); b++) {
/*     */         String str = (String)enumeration.nextElement();
/*     */         arrayOfPropertyDescriptor[b] = new PropertyDescriptor(str, this.bean);
/*     */         Object object = this.pdmap.get(str);
/*     */         if (object instanceof Class)
/*     */           arrayOfPropertyDescriptor[b].setPropertyEditorClass((Class)object); 
/*     */       } 
/*     */       return arrayOfPropertyDescriptor;
/*     */     } catch (Exception exception) {
/*     */       exception.printStackTrace();
/*     */       return null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\beans\AutoBeanInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */