/*    */ package inetsoft.beans;
/*    */ 
/*    */ import java.beans.PropertyEditorSupport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IntegerEditorSupport
/*    */   extends PropertyEditorSupport
/*    */ {
/*    */   public void setValues(String[] paramArrayOfString, int[] paramArrayOfInt) {
/* 13 */     this.tags = paramArrayOfString;
/* 14 */     this.opts = paramArrayOfInt;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void setAsText(String paramString) {
/* 21 */     for (byte b = 0; b < this.tags.length; b++) {
/* 22 */       if (this.tags[b].equals(paramString)) {
/* 23 */         setValue(new Integer(this.opts[b]));
/*    */         break;
/*    */       } 
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getAsText() {
/* 34 */     int i = ((Integer)getValue()).intValue();
/* 35 */     for (byte b = 0; b < this.opts.length; b++) {
/* 36 */       if (this.opts[b] == i) {
/* 37 */         return this.tags[b];
/*    */       }
/*    */     } 
/*    */     
/* 41 */     return this.tags[0];
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 48 */   public String[] getTags() { return this.tags; }
/*    */ 
/*    */ 
/*    */   
/* 52 */   public String getJavaInitializationString() { return getValue().toString(); }
/*    */ 
/*    */   
/* 55 */   String[] tags = new String[0];
/* 56 */   int[] opts = new int[0];
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\design_pro.jar!\inetsoft\beans\IntegerEditorSupport.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */