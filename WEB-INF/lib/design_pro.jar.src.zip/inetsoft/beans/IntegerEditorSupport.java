package inetsoft.beans;

import java.beans.PropertyEditorSupport;

public class IntegerEditorSupport extends PropertyEditorSupport {
  public void setValues(String[] paramArrayOfString, int[] paramArrayOfInt) {
    this.tags = paramArrayOfString;
    this.opts = paramArrayOfInt;
  }
  
  public void setAsText(String paramString) {
    for (byte b = 0; b < this.tags.length; b++) {
      if (this.tags[b].equals(paramString)) {
        setValue(new Integer(this.opts[b]));
        break;
      } 
    } 
  }
  
  public String getAsText() {
    int i = ((Integer)getValue()).intValue();
    for (byte b = 0; b < this.opts.length; b++) {
      if (this.opts[b] == i)
        return this.tags[b]; 
    } 
    return this.tags[0];
  }
  
  public String[] getTags() { return this.tags; }
  
  public String getJavaInitializationString() { return getValue().toString(); }
  
  String[] tags = new String[0];
  
  int[] opts = new int[0];
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\design_pro.jar!\inetsoft\beans\IntegerEditorSupport.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */