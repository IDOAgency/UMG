/*     */ package javax.xml.namespace;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.Serializable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class QName
/*     */   implements Serializable
/*     */ {
/*  36 */   private static final String emptyString = "".intern();
/*     */ 
/*     */ 
/*     */   
/*     */   private String namespaceURI;
/*     */ 
/*     */   
/*     */   private String localPart;
/*     */ 
/*     */   
/*     */   private String prefix;
/*     */ 
/*     */ 
/*     */   
/*  50 */   public QName(String localPart) { this(emptyString, localPart, emptyString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   public QName(String namespaceURI, String localPart) { this(namespaceURI, localPart, emptyString); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public QName(String namespaceURI, String localPart, String prefix) {
/*  71 */     this.namespaceURI = (namespaceURI == null) ? emptyString : namespaceURI.intern();
/*     */ 
/*     */     
/*  74 */     if (localPart == null) {
/*  75 */       throw new IllegalArgumentException("invalid QName local part");
/*     */     }
/*  77 */     this.localPart = localPart.intern();
/*     */ 
/*     */     
/*  80 */     if (prefix == null) {
/*  81 */       throw new IllegalArgumentException("invalid QName prefix");
/*     */     }
/*  83 */     this.prefix = prefix.intern();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  93 */   public String getNamespaceURI() { return this.namespaceURI; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 102 */   public String getLocalPart() { return this.localPart; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 111 */   public String getPrefix() { return this.prefix; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 121 */   public String toString() { return (this.namespaceURI == emptyString) ? this.localPart : ('{' + this.namespaceURI + '}' + this.localPart); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object obj) {
/* 147 */     if (obj == this) {
/* 148 */       return true;
/*     */     }
/*     */     
/* 151 */     if (!(obj instanceof QName)) {
/* 152 */       return false;
/*     */     }
/*     */     
/* 155 */     if (this.namespaceURI == ((QName)obj).namespaceURI && this.localPart == ((QName)obj).localPart)
/*     */     {
/* 157 */       return true;
/*     */     }
/*     */     
/* 160 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static QName valueOf(String s) {
/* 181 */     if (s == null || s.equals("")) {
/* 182 */       throw new IllegalArgumentException("invalid QName literal");
/*     */     }
/*     */     
/* 185 */     if (s.charAt(0) == '{') {
/* 186 */       int i = s.indexOf('}');
/*     */       
/* 188 */       if (i == -1) {
/* 189 */         throw new IllegalArgumentException("invalid QName literal");
/*     */       }
/*     */       
/* 192 */       if (i == s.length() - 1) {
/* 193 */         throw new IllegalArgumentException("invalid QName literal");
/*     */       }
/* 195 */       return new QName(s.substring(1, i), s.substring(i + 1));
/*     */     } 
/*     */     
/* 198 */     return new QName(s);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 211 */   public int hashCode() { return this.namespaceURI.hashCode() ^ this.localPart.hashCode(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
/* 223 */     in.defaultReadObject();
/*     */     
/* 225 */     this.namespaceURI = this.namespaceURI.intern();
/* 226 */     this.localPart = this.localPart.intern();
/* 227 */     this.prefix = this.prefix.intern();
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\jaxrpc.jar!\javax\xml\namespace\QName.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */