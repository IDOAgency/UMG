package javax.xml.messaging;

public class URLEndpoint extends Endpoint {
  public URLEndpoint(String url) { super(url); }
  
  public String getURL() { return this.id; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\jaxrpc.jar!\javax\xml\messaging\URLEndpoint.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */