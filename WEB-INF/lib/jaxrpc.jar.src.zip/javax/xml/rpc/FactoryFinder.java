package javax.xml.rpc;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Properties;

class FactoryFinder {
  private static final boolean debug = false;
  
  private static void debugPrintln(String msg) {}
  
  private static ClassLoader findClassLoader() throws ConfigurationError {
    m = null;
    try {
      m = Thread.class.getMethod("getContextClassLoader", null);
    } catch (NoSuchMethodException e) {
      debugPrintln("assuming JDK 1.1");
      return FactoryFinder.class.getClassLoader();
    } 
    try {
      return (ClassLoader)m.invoke(Thread.currentThread(), null);
    } catch (IllegalAccessException e) {
      throw new ConfigurationError("Unexpected IllegalAccessException", e);
    } catch (InvocationTargetException e) {
      throw new ConfigurationError("Unexpected InvocationTargetException", e);
    } 
  }
  
  private static Object newInstance(String className, ClassLoader classLoader) throws ConfigurationError {
    try {
      if (classLoader != null)
        try {
          return classLoader.loadClass(className).newInstance();
        } catch (ClassNotFoundException x) {} 
      return Class.forName(className).newInstance();
    } catch (ClassNotFoundException x) {
      throw new ConfigurationError("Provider " + className + " not found", x);
    } catch (Exception x) {
      throw new ConfigurationError("Provider " + className + " could not be instantiated: " + x, x);
    } 
  }
  
  static Object find(String factoryId, String fallbackClassName) throws ConfigurationError {
    debugPrintln("debug is on");
    ClassLoader classLoader = findClassLoader();
    try {
      String systemProp = System.getProperty(factoryId);
      if (systemProp != null) {
        debugPrintln("found system property " + systemProp);
        return newInstance(systemProp, classLoader);
      } 
    } catch (SecurityException se) {}
    try {
      String javah = System.getProperty("java.home");
      String configFile = javah + File.separator + "lib" + File.separator + "jaxrpc.properties";
      File f = new File(configFile);
      if (f.exists()) {
        Properties props = new Properties();
        props.load(new FileInputStream(f));
        String factoryClassName = props.getProperty(factoryId);
        debugPrintln("found java.home property " + factoryClassName);
        return newInstance(factoryClassName, classLoader);
      } 
    } catch (Exception ex) {}
    String serviceId = "META-INF/services/" + factoryId;
    try {
      InputStream is = null;
      if (classLoader == null) {
        is = ClassLoader.getSystemResourceAsStream(serviceId);
      } else {
        is = classLoader.getResourceAsStream(serviceId);
      } 
      if (is != null) {
        BufferedReader rd;
        debugPrintln("found " + serviceId);
        try {
          rd = new BufferedReader(new InputStreamReader(is, "UTF-8"));
        } catch (UnsupportedEncodingException e) {
          rd = new BufferedReader(new InputStreamReader(is));
        } 
        String factoryClassName = rd.readLine();
        rd.close();
        if (factoryClassName != null && !"".equals(factoryClassName)) {
          debugPrintln("loaded from services: " + factoryClassName);
          return newInstance(factoryClassName, classLoader);
        } 
      } 
    } catch (Exception ex) {}
    if (fallbackClassName == null)
      throw new ConfigurationError("Provider for " + factoryId + " cannot be found", null); 
    debugPrintln("loaded from fallback value: " + fallbackClassName);
    return newInstance(fallbackClassName, classLoader);
  }
  
  static class ConfigurationError extends Error {
    private Exception exception;
    
    ConfigurationError(String msg, Exception x) {
      super(msg);
      this.exception = x;
    }
    
    Exception getException() { return this.exception; }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\jaxrpc.jar!\javax\xml\rpc\FactoryFinder.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */