/*     */ package javax.xml.rpc;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class FactoryFinder
/*     */ {
/*     */   private static final boolean debug = false;
/*     */   
/*     */   private static void debugPrintln(String msg) {}
/*     */   
/*     */   private static ClassLoader findClassLoader() throws ConfigurationError {
/*  59 */     m = null;
/*     */     
/*     */     try {
/*  62 */       m = Thread.class.getMethod("getContextClassLoader", null);
/*  63 */     } catch (NoSuchMethodException e) {
/*     */       
/*  65 */       debugPrintln("assuming JDK 1.1");
/*  66 */       return FactoryFinder.class.getClassLoader();
/*     */     } 
/*     */     
/*     */     try {
/*  70 */       return (ClassLoader)m.invoke(Thread.currentThread(), null);
/*  71 */     } catch (IllegalAccessException e) {
/*     */       
/*  73 */       throw new ConfigurationError("Unexpected IllegalAccessException", e);
/*     */     }
/*  75 */     catch (InvocationTargetException e) {
/*     */       
/*  77 */       throw new ConfigurationError("Unexpected InvocationTargetException", e);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Object newInstance(String className, ClassLoader classLoader) throws ConfigurationError {
/*     */     try {
/* 100 */       if (classLoader != null) {
/*     */         try {
/* 102 */           return classLoader.loadClass(className).newInstance();
/* 103 */         } catch (ClassNotFoundException x) {}
/*     */       }
/*     */ 
/*     */       
/* 107 */       return Class.forName(className).newInstance();
/* 108 */     } catch (ClassNotFoundException x) {
/* 109 */       throw new ConfigurationError("Provider " + className + " not found", x);
/*     */     }
/* 111 */     catch (Exception x) {
/* 112 */       throw new ConfigurationError("Provider " + className + " could not be instantiated: " + x, x);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Object find(String factoryId, String fallbackClassName) throws ConfigurationError {
/* 135 */     debugPrintln("debug is on");
/*     */     
/* 137 */     ClassLoader classLoader = findClassLoader();
/*     */ 
/*     */     
/*     */     try {
/* 141 */       String systemProp = System.getProperty(factoryId);
/*     */       
/* 143 */       if (systemProp != null) {
/* 144 */         debugPrintln("found system property " + systemProp);
/* 145 */         return newInstance(systemProp, classLoader);
/*     */       } 
/* 147 */     } catch (SecurityException se) {}
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 152 */       String javah = System.getProperty("java.home");
/* 153 */       String configFile = javah + File.separator + "lib" + File.separator + "jaxrpc.properties";
/*     */       
/* 155 */       File f = new File(configFile);
/* 156 */       if (f.exists()) {
/* 157 */         Properties props = new Properties();
/* 158 */         props.load(new FileInputStream(f));
/* 159 */         String factoryClassName = props.getProperty(factoryId);
/* 160 */         debugPrintln("found java.home property " + factoryClassName);
/* 161 */         return newInstance(factoryClassName, classLoader);
/*     */       } 
/* 163 */     } catch (Exception ex) {}
/*     */ 
/*     */ 
/*     */     
/* 167 */     String serviceId = "META-INF/services/" + factoryId;
/*     */     
/*     */     try {
/* 170 */       InputStream is = null;
/* 171 */       if (classLoader == null) {
/* 172 */         is = ClassLoader.getSystemResourceAsStream(serviceId);
/*     */       } else {
/* 174 */         is = classLoader.getResourceAsStream(serviceId);
/*     */       } 
/*     */       
/* 177 */       if (is != null) {
/* 178 */         BufferedReader rd; debugPrintln("found " + serviceId);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         try {
/* 198 */           rd = new BufferedReader(new InputStreamReader(is, "UTF-8"));
/* 199 */         } catch (UnsupportedEncodingException e) {
/* 200 */           rd = new BufferedReader(new InputStreamReader(is));
/*     */         } 
/*     */         
/* 203 */         String factoryClassName = rd.readLine();
/* 204 */         rd.close();
/*     */         
/* 206 */         if (factoryClassName != null && !"".equals(factoryClassName)) {
/*     */           
/* 208 */           debugPrintln("loaded from services: " + factoryClassName);
/* 209 */           return newInstance(factoryClassName, classLoader);
/*     */         } 
/*     */       } 
/* 212 */     } catch (Exception ex) {}
/*     */ 
/*     */ 
/*     */     
/* 216 */     if (fallbackClassName == null) {
/* 217 */       throw new ConfigurationError("Provider for " + factoryId + " cannot be found", null);
/*     */     }
/*     */ 
/*     */     
/* 221 */     debugPrintln("loaded from fallback value: " + fallbackClassName);
/* 222 */     return newInstance(fallbackClassName, classLoader);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class ConfigurationError
/*     */     extends Error
/*     */   {
/*     */     private Exception exception;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     ConfigurationError(String msg, Exception x) {
/* 239 */       super(msg);
/* 240 */       this.exception = x;
/*     */     }
/*     */ 
/*     */     
/* 244 */     Exception getException() { return this.exception; }
/*     */   }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\jaxrpc.jar!\javax\xml\rpc\FactoryFinder.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */