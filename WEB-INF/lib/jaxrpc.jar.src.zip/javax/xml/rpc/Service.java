package javax.xml.rpc;

import java.net.URL;
import java.rmi.Remote;
import java.util.Iterator;
import javax.xml.namespace.QName;
import javax.xml.rpc.encoding.TypeMappingRegistry;
import javax.xml.rpc.handler.HandlerRegistry;

public interface Service {
  Remote getPort(QName paramQName, Class paramClass) throws ServiceException;
  
  Remote getPort(Class paramClass) throws ServiceException;
  
  Call[] getCalls(QName paramQName) throws ServiceException;
  
  Call createCall(QName paramQName) throws ServiceException;
  
  Call createCall(QName paramQName1, QName paramQName2) throws ServiceException;
  
  Call createCall(QName paramQName, String paramString) throws ServiceException;
  
  Call createCall() throws ServiceException;
  
  QName getServiceName();
  
  Iterator getPorts() throws ServiceException;
  
  URL getWSDLDocumentLocation();
  
  TypeMappingRegistry getTypeMappingRegistry();
  
  HandlerRegistry getHandlerRegistry();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\jaxrpc.jar!\javax\xml\rpc\Service.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */