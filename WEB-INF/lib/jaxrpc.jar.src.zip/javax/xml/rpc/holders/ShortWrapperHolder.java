package javax.xml.rpc.holders;

public final class ShortWrapperHolder implements Holder {
  public Short value;
  
  public ShortWrapperHolder() {}
  
  public ShortWrapperHolder(Short value) { this.value = value; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\jaxrpc.jar!\javax\xml\rpc\holders\ShortWrapperHolder.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */