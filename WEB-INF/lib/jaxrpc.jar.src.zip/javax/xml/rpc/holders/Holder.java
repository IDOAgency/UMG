package javax.xml.rpc.holders;

public interface Holder {}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\jaxrpc.jar!\javax\xml\rpc\holders\Holder.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */