/*    */ package javax.xml.rpc.holders;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class LongWrapperHolder
/*    */   implements Holder
/*    */ {
/*    */   public Long value;
/*    */   
/*    */   public LongWrapperHolder() {}
/*    */   
/* 40 */   public LongWrapperHolder(Long value) { this.value = value; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\jaxrpc.jar!\javax\xml\rpc\holders\LongWrapperHolder.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */