package javax.xml.rpc.holders;

import java.util.Calendar;

public final class CalendarHolder implements Holder {
  public Calendar value;
  
  public CalendarHolder() {}
  
  public CalendarHolder(Calendar value) { this.value = value; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\jaxrpc.jar!\javax\xml\rpc\holders\CalendarHolder.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */