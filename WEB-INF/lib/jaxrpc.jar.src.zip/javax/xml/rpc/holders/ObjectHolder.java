package javax.xml.rpc.holders;

public final class ObjectHolder implements Holder {
  public Object value;
  
  public ObjectHolder() {}
  
  public ObjectHolder(Object value) { this.value = value; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\jaxrpc.jar!\javax\xml\rpc\holders\ObjectHolder.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */