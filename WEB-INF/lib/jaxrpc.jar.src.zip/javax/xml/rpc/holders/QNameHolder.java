package javax.xml.rpc.holders;

import javax.xml.namespace.QName;

public final class QNameHolder implements Holder {
  public QName value;
  
  public QNameHolder() {}
  
  public QNameHolder(QName value) { this.value = value; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\jaxrpc.jar!\javax\xml\rpc\holders\QNameHolder.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */