package javax.xml.rpc.holders;

public final class ByteHolder implements Holder {
  public byte value;
  
  public ByteHolder() {}
  
  public ByteHolder(byte value) { this.value = value; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\jaxrpc.jar!\javax\xml\rpc\holders\ByteHolder.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */