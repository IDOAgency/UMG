package javax.xml.rpc.holders;

public final class ByteWrapperHolder implements Holder {
  public Byte value;
  
  public ByteWrapperHolder() {}
  
  public ByteWrapperHolder(Byte value) { this.value = value; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\jaxrpc.jar!\javax\xml\rpc\holders\ByteWrapperHolder.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */