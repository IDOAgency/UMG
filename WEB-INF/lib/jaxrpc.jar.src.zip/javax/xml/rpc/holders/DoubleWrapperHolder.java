package javax.xml.rpc.holders;

public final class DoubleWrapperHolder implements Holder {
  public Double value;
  
  public DoubleWrapperHolder() {}
  
  public DoubleWrapperHolder(Double value) { this.value = value; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\jaxrpc.jar!\javax\xml\rpc\holders\DoubleWrapperHolder.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */