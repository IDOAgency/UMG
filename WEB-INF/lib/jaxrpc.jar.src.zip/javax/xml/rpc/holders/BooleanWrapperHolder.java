/*    */ package javax.xml.rpc.holders;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class BooleanWrapperHolder
/*    */   implements Holder
/*    */ {
/*    */   public Boolean value;
/*    */   
/*    */   public BooleanWrapperHolder() {}
/*    */   
/* 40 */   public BooleanWrapperHolder(Boolean value) { this.value = value; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\jaxrpc.jar!\javax\xml\rpc\holders\BooleanWrapperHolder.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */