package javax.xml.rpc.holders;

public final class IntHolder implements Holder {
  public int value;
  
  public IntHolder() {}
  
  public IntHolder(int value) { this.value = value; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\jaxrpc.jar!\javax\xml\rpc\holders\IntHolder.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */