package javax.xml.rpc.holders;

public final class FloatWrapperHolder implements Holder {
  public Float value;
  
  public FloatWrapperHolder() {}
  
  public FloatWrapperHolder(Float value) { this.value = value; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\jaxrpc.jar!\javax\xml\rpc\holders\FloatWrapperHolder.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */