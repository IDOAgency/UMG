/*    */ package javax.xml.rpc.holders;
/*    */ 
/*    */ import java.math.BigInteger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class BigIntegerHolder
/*    */   implements Holder
/*    */ {
/*    */   public BigInteger value;
/*    */   
/*    */   public BigIntegerHolder() {}
/*    */   
/* 42 */   public BigIntegerHolder(BigInteger value) { this.value = value; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\jaxrpc.jar!\javax\xml\rpc\holders\BigIntegerHolder.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */