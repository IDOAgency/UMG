/*    */ package javax.xml.rpc.holders;
/*    */ 
/*    */ import java.math.BigDecimal;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class BigDecimalHolder
/*    */   implements Holder
/*    */ {
/*    */   public BigDecimal value;
/*    */   
/*    */   public BigDecimalHolder() {}
/*    */   
/* 42 */   public BigDecimalHolder(BigDecimal value) { this.value = value; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\jaxrpc.jar!\javax\xml\rpc\holders\BigDecimalHolder.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */