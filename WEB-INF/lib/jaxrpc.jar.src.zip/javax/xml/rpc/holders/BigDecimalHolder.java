package javax.xml.rpc.holders;

import java.math.BigDecimal;

public final class BigDecimalHolder implements Holder {
  public BigDecimal value;
  
  public BigDecimalHolder() {}
  
  public BigDecimalHolder(BigDecimal value) { this.value = value; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\jaxrpc.jar!\javax\xml\rpc\holders\BigDecimalHolder.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */