package javax.xml.rpc.holders;

public final class ShortHolder implements Holder {
  public short value;
  
  public ShortHolder() {}
  
  public ShortHolder(short value) { this.value = value; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\jaxrpc.jar!\javax\xml\rpc\holders\ShortHolder.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */