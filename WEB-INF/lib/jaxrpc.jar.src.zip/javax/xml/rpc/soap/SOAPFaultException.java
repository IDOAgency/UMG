/*    */ package javax.xml.rpc.soap;
/*    */ 
/*    */ import javax.xml.namespace.QName;
/*    */ import javax.xml.soap.Detail;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SOAPFaultException
/*    */   extends RuntimeException
/*    */ {
/*    */   private QName faultcode;
/*    */   private String faultstring;
/*    */   private String faultactor;
/*    */   private Detail detail;
/*    */   
/*    */   public SOAPFaultException(QName faultcode, String faultstring, String faultactor, Detail detail) {
/* 54 */     super(faultstring);
/*    */     
/* 56 */     this.faultcode = faultcode;
/* 57 */     this.faultstring = faultstring;
/* 58 */     this.faultactor = faultactor;
/* 59 */     this.detail = detail;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 69 */   public QName getFaultCode() { return this.faultcode; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 78 */   public String getFaultString() { return this.faultstring; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 89 */   public String getFaultActor() { return this.faultactor; }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 99 */   public Detail getDetail() { return this.detail; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\jaxrpc.jar!\javax\xml\rpc\soap\SOAPFaultException.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */