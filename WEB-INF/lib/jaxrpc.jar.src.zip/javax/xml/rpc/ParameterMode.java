/*    */ package javax.xml.rpc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParameterMode
/*    */ {
/*    */   private final String mode;
/* 31 */   public static final ParameterMode IN = new ParameterMode("IN");
/*    */ 
/*    */   
/* 34 */   public static final ParameterMode INOUT = new ParameterMode("INOUT");
/*    */ 
/*    */   
/* 37 */   public static final ParameterMode OUT = new ParameterMode("OUT");
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 45 */   private ParameterMode(String mode) { this.mode = mode; }
/*    */ 
/*    */ 
/*    */   
/* 49 */   public String toString() { return this.mode; }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\jaxrpc.jar!\javax\xml\rpc\ParameterMode.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */