package javax.xml.rpc;

public class ParameterMode {
  private final String mode;
  
  public static final ParameterMode IN = new ParameterMode("IN");
  
  public static final ParameterMode INOUT = new ParameterMode("INOUT");
  
  public static final ParameterMode OUT = new ParameterMode("OUT");
  
  private ParameterMode(String mode) { this.mode = mode; }
  
  public String toString() { return this.mode; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\jaxrpc.jar!\javax\xml\rpc\ParameterMode.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */