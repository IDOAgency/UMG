package javax.xml.rpc.encoding;

import java.io.Serializable;

public interface Serializer extends Serializable {
  String getMechanismType();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\jaxrpc.jar!\javax\xml\rpc\encoding\Serializer.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */