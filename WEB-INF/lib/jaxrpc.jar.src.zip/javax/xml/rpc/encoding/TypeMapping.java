package javax.xml.rpc.encoding;

import javax.xml.namespace.QName;

public interface TypeMapping {
  String[] getSupportedEncodings();
  
  void setSupportedEncodings(String[] paramArrayOfString);
  
  boolean isRegistered(Class paramClass, QName paramQName);
  
  void register(Class paramClass, QName paramQName, SerializerFactory paramSerializerFactory, DeserializerFactory paramDeserializerFactory);
  
  SerializerFactory getSerializer(Class paramClass, QName paramQName);
  
  DeserializerFactory getDeserializer(Class paramClass, QName paramQName);
  
  void removeSerializer(Class paramClass, QName paramQName);
  
  void removeDeserializer(Class paramClass, QName paramQName);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\jaxrpc.jar!\javax\xml\rpc\encoding\TypeMapping.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */