/*     */ package javax.xml.rpc.encoding;
/*     */ 
/*     */ import javax.xml.namespace.QName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class XMLType
/*     */ {
/*  31 */   public static final QName XSD_STRING = new QName("http://www.w3.org/2001/XMLSchema", "string");
/*     */ 
/*     */ 
/*     */   
/*  35 */   public static final QName XSD_FLOAT = new QName("http://www.w3.org/2001/XMLSchema", "float");
/*     */ 
/*     */ 
/*     */   
/*  39 */   public static final QName XSD_BOOLEAN = new QName("http://www.w3.org/2001/XMLSchema", "boolean");
/*     */ 
/*     */ 
/*     */   
/*  43 */   public static final QName XSD_DOUBLE = new QName("http://www.w3.org/2001/XMLSchema", "double");
/*     */ 
/*     */ 
/*     */   
/*  47 */   public static final QName XSD_INTEGER = new QName("http://www.w3.org/2001/XMLSchema", "integer");
/*     */ 
/*     */ 
/*     */   
/*  51 */   public static final QName XSD_INT = new QName("http://www.w3.org/2001/XMLSchema", "int");
/*     */ 
/*     */ 
/*     */   
/*  55 */   public static final QName XSD_LONG = new QName("http://www.w3.org/2001/XMLSchema", "long");
/*     */ 
/*     */ 
/*     */   
/*  59 */   public static final QName XSD_SHORT = new QName("http://www.w3.org/2001/XMLSchema", "short");
/*     */ 
/*     */ 
/*     */   
/*  63 */   public static final QName XSD_DECIMAL = new QName("http://www.w3.org/2001/XMLSchema", "decimal");
/*     */ 
/*     */ 
/*     */   
/*  67 */   public static final QName XSD_BASE64 = new QName("http://www.w3.org/2001/XMLSchema", "base64Binary");
/*     */ 
/*     */ 
/*     */   
/*  71 */   public static final QName XSD_HEXBINARY = new QName("http://www.w3.org/2001/XMLSchema", "hexBinary");
/*     */ 
/*     */ 
/*     */   
/*  75 */   public static final QName XSD_BYTE = new QName("http://www.w3.org/2001/XMLSchema", "byte");
/*     */ 
/*     */ 
/*     */   
/*  79 */   public static final QName XSD_DATETIME = new QName("http://www.w3.org/2001/XMLSchema", "dateTime");
/*     */ 
/*     */ 
/*     */   
/*  83 */   public static final QName XSD_QNAME = new QName("http://www.w3.org/2001/XMLSchema", "QName");
/*     */ 
/*     */ 
/*     */   
/*  87 */   public static final QName SOAP_STRING = new QName("http://schemas.xmlsoap.org/soap/encoding/", "string");
/*     */ 
/*     */ 
/*     */   
/*  91 */   public static final QName SOAP_BOOLEAN = new QName("http://schemas.xmlsoap.org/soap/encoding/", "boolean");
/*     */ 
/*     */ 
/*     */   
/*  95 */   public static final QName SOAP_DOUBLE = new QName("http://schemas.xmlsoap.org/soap/encoding/", "double");
/*     */ 
/*     */ 
/*     */   
/*  99 */   public static final QName SOAP_BASE64 = new QName("http://schemas.xmlsoap.org/soap/encoding/", "base64");
/*     */ 
/*     */ 
/*     */   
/* 103 */   public static final QName SOAP_FLOAT = new QName("http://schemas.xmlsoap.org/soap/encoding/", "float");
/*     */ 
/*     */ 
/*     */   
/* 107 */   public static final QName SOAP_INT = new QName("http://schemas.xmlsoap.org/soap/encoding/", "int");
/*     */ 
/*     */ 
/*     */   
/* 111 */   public static final QName SOAP_LONG = new QName("http://schemas.xmlsoap.org/soap/encoding/", "long");
/*     */ 
/*     */ 
/*     */   
/* 115 */   public static final QName SOAP_SHORT = new QName("http://schemas.xmlsoap.org/soap/encoding/", "short");
/*     */ 
/*     */ 
/*     */   
/* 119 */   public static final QName SOAP_BYTE = new QName("http://schemas.xmlsoap.org/soap/encoding/", "byte");
/*     */ 
/*     */ 
/*     */   
/* 123 */   public static final QName SOAP_ARRAY = new QName("http://schemas.xmlsoap.org/soap/encoding/", "Array");
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\jaxrpc.jar!\javax\xml\rpc\encoding\XMLType.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */