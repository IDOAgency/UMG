package javax.xml.rpc.encoding;

public interface DeserializationContext {}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\jaxrpc.jar!\javax\xml\rpc\encoding\DeserializationContext.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */