package javax.xml.rpc.encoding;

import java.io.Serializable;
import java.util.Iterator;

public interface SerializerFactory extends Serializable {
  Serializer getSerializerAs(String paramString);
  
  Iterator getSupportedMechanismTypes();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\jaxrpc.jar!\javax\xml\rpc\encoding\SerializerFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */