package javax.xml.rpc.encoding;

import java.io.Serializable;
import java.util.Iterator;

public interface DeserializerFactory extends Serializable {
  Deserializer getDeserializerAs(String paramString);
  
  Iterator getSupportedMechanismTypes();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\jaxrpc.jar!\javax\xml\rpc\encoding\DeserializerFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */