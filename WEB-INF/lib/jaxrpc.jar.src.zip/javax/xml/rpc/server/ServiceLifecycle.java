package javax.xml.rpc.server;

import javax.xml.rpc.ServiceException;

public interface ServiceLifecycle {
  void init(Object paramObject) throws ServiceException;
  
  void destroy();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\jaxrpc.jar!\javax\xml\rpc\server\ServiceLifecycle.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */