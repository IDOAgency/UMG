package javax.xml.rpc;

import java.util.Iterator;

public interface Stub {
  public static final String USERNAME_PROPERTY = "javax.xml.rpc.security.auth.username";
  
  public static final String PASSWORD_PROPERTY = "javax.xml.rpc.security.auth.password";
  
  public static final String ENDPOINT_ADDRESS_PROPERTY = "javax.xml.rpc.service.endpoint.address";
  
  public static final String SESSION_MAINTAIN_PROPERTY = "javax.xml.rpc.session.maintain";
  
  void _setProperty(String paramString, Object paramObject);
  
  Object _getProperty(String paramString);
  
  Iterator _getPropertyNames();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\jaxrpc.jar!\javax\xml\rpc\Stub.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */