/*    */ package javax.xml.rpc;
/*    */ 
/*    */ import java.net.URL;
/*    */ import java.util.Properties;
/*    */ import javax.xml.namespace.QName;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ServiceFactory
/*    */ {
/*    */   public static final String SERVICEFACTORY_PROPERTY = "javax.xml.rpc.ServiceFactory";
/*    */   
/*    */   public static ServiceFactory newInstance() throws ServiceException {
/*    */     try {
/* 63 */       return (ServiceFactory)FactoryFinder.find("javax.xml.rpc.ServiceFactory", "org.apache.axis.client.ServiceFactory");
/*    */ 
/*    */ 
/*    */     
/*    */     }
/* 68 */     catch (ConfigurationError e) {
/* 69 */       throw new ServiceException(e.getException());
/*    */     } 
/*    */   }
/*    */   
/*    */   public abstract Service createService(URL paramURL, QName paramQName) throws ServiceException;
/*    */   
/*    */   public abstract Service createService(QName paramQName) throws ServiceException;
/*    */   
/*    */   public abstract Service loadService(Class paramClass) throws ServiceException;
/*    */   
/*    */   public abstract Service loadService(URL paramURL, Class paramClass, Properties paramProperties) throws ServiceException;
/*    */   
/*    */   public abstract Service loadService(URL paramURL, QName paramQName, Properties paramProperties) throws ServiceException;
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\WEB-INF\lib\jaxrpc.jar!\javax\xml\rpc\ServiceFactory.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */