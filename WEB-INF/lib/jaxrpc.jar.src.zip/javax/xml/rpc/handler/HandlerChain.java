package javax.xml.rpc.handler;

import java.util.List;
import java.util.Map;

public interface HandlerChain extends List {
  boolean handleRequest(MessageContext paramMessageContext);
  
  boolean handleResponse(MessageContext paramMessageContext);
  
  boolean handleFault(MessageContext paramMessageContext);
  
  void init(Map paramMap);
  
  void destroy();
  
  void setRoles(String[] paramArrayOfString);
  
  String[] getRoles();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\jaxrpc.jar!\javax\xml\rpc\handler\HandlerChain.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */