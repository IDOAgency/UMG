/*     */ package javax.xml.rpc.handler;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.xml.namespace.QName;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HandlerInfo
/*     */   implements Serializable
/*     */ {
/*     */   private Class handlerClass;
/*     */   private Map config;
/*     */   private QName[] headers;
/*     */   
/*     */   public HandlerInfo() {
/*  36 */     this.handlerClass = null;
/*  37 */     this.config = new HashMap();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HandlerInfo(Class handlerClass, Map config, QName[] headers) {
/*  51 */     this.handlerClass = handlerClass;
/*  52 */     this.config = config;
/*  53 */     this.headers = headers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  62 */   public void setHandlerClass(Class handlerClass) { this.handlerClass = handlerClass; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  72 */   public Class getHandlerClass() { return this.handlerClass; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  80 */   public void setHandlerConfig(Map config) { this.config = config; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  90 */   public Map getHandlerConfig() { return this.config; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 100 */   public void setHeaders(QName[] headers) { this.headers = headers; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 110 */   public QName[] getHeaders() { return this.headers; }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\jaxrpc.jar!\javax\xml\rpc\handler\HandlerInfo.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */