package javax.xml.rpc.handler;

import java.io.Serializable;
import java.util.List;
import javax.xml.namespace.QName;

public interface HandlerRegistry extends Serializable {
  List getHandlerChain(QName paramQName);
  
  void setHandlerChain(QName paramQName, List paramList);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\jaxrpc.jar!\javax\xml\rpc\handler\HandlerRegistry.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */