package javax.xml.rpc;

public class JAXRPCException extends RuntimeException {
  Throwable cause;
  
  public JAXRPCException() {}
  
  public JAXRPCException(String message) { super(message); }
  
  public JAXRPCException(String message, Throwable cause) {
    super(message);
    this.cause = cause;
  }
  
  public JAXRPCException(Throwable cause) {
    super((cause == null) ? null : cause.toString());
    this.cause = cause;
  }
  
  public Throwable getLinkedCause() { return this.cause; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\WEB-INF\lib\jaxrpc.jar!\javax\xml\rpc\JAXRPCException.class
 * Java compiler version: 3 (47.0)
 * JD-Core Version:       1.0.7
 */