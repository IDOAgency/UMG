/*     */ package com.bssc.java.help;
/*     */ 
/*     */ import com.sun.java.help.impl.ViewAwareComponent;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dialog;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Point;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import javax.help.JHelpContentViewer;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JList;
/*     */ import javax.swing.ListCellRenderer;
/*     */ import javax.swing.LookAndFeel;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.border.BevelBorder;
/*     */ import javax.swing.plaf.basic.BasicComboPopup;
/*     */ import javax.swing.text.SimpleAttributeSet;
/*     */ import javax.swing.text.StyleConstants;
/*     */ import javax.swing.text.View;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RelatedTopics
/*     */   extends JButton
/*     */   implements ActionListener, ViewAwareComponent
/*     */ {
/*     */   private View myView;
/*     */   private Font font;
/*     */   private SimpleAttributeSet textAttribs;
/*     */   private static final String buttonPropertyPrefix = "Button.";
/*     */   private RelatedTopicsView popupView;
/*     */   
/*     */   public RelatedTopics() {
/* 304 */     this.viewerHeight = 0;
/* 305 */     this.viewerWidth = 0;
/* 306 */     this.viewerX = 0;
/* 307 */     this.viewerY = 0;
/* 308 */     this.viewerName = "";
/* 309 */     this.viewerActivator = 0;
/*     */ 
/*     */     
/* 312 */     this.selectionListener = new SelectionListener(this); setText("Related Topics"); setMargin(new Insets(0, 0, 0, 0)); createLinkButton(); addActionListener(this);
/*     */   } private void createLinkButton() { LookAndFeel.installBorder(this, "Button.border"); setBorderPainted(true); setFocusPainted(true); setAlignmentY(0.5F); setContentAreaFilled(true); setBackground(UIManager.getColor("Button.background")); this.textAttribs = new SimpleAttributeSet(); if (this.textAttribs != null && this.textAttribs.isDefined(StyleConstants.Foreground)) { setForeground((Color)this.textAttribs.getAttribute(StyleConstants.Foreground)); }
/*     */     else
/*     */     { setForeground(UIManager.getColor("Button.foreground")); }
/*     */      invalidate(); } public void setViewData(View paramView) { this.myView = paramView; container = this.myView.getContainer(); this.font = getFont(); } class MyBasicComboPopup extends BasicComboPopup {
/*     */     private final RelatedTopics this$0; public MyBasicComboPopup(RelatedTopics this$0, JComboBox param1JComboBox) { super(param1JComboBox); this.this$0 = this$0; }
/*     */     public int getRequiredHeight(int param1Int) { Insets insets = getBorder().getBorderInsets(this); return getPopupHeightForRowCount(param1Int) + insets.bottom + insets.top; } } private static Component container = null; private int viewerHeight; private int viewerWidth; private int viewerX; private int viewerY; private String viewerName;
/* 319 */   public String getTopicList() { return this.topics.topicList; }
/*     */ 
/*     */   
/*     */   private int viewerActivator;
/*     */   
/*     */   private Icon viewerIcon;
/*     */   private Topics topics;
/*     */   private SelectionListener selectionListener;
/*     */   
/* 328 */   public void setTopicList(String paramString) { this.topics = new Topics(this, paramString); } private static final boolean debug = false; class RelatedTopicsView {
/*     */     private final RelatedTopics this$0; public JComboBox combobox; public RelatedTopics.MyBasicComboPopup popup; public BevelBorder border;
/*     */     public RelatedTopicsView(RelatedTopics this$0, RelatedTopics.MyBasicComboPopup param1MyBasicComboPopup, JComboBox param1JComboBox) {
/*     */       this.this$0 = this$0;
/*     */       this.popup = param1MyBasicComboPopup;
/*     */       this.combobox = param1JComboBox;
/*     */       this.border = new BevelBorder(0);
/*     */     } }
/* 336 */   public void actionPerformed(ActionEvent paramActionEvent) { MyBasicComboPopup myBasicComboPopup = null;
/* 337 */     JComboBox jComboBox = null;
/*     */     
/* 339 */     if (this.popupView == null) {
/*     */       
/* 341 */       jComboBox = new JComboBox();
/* 342 */       for (byte b = 0; b < this.topics.getTopicCount(); b++)
/* 343 */         jComboBox.addItem(this.topics.getTopicString(b)); 
/* 344 */       jComboBox.setSelectedIndex(-1);
/* 345 */       jComboBox.addActionListener(this.selectionListener);
/* 346 */       jComboBox.setRenderer(new PopupCellRenderer(this, jComboBox));
/*     */       
/* 348 */       myBasicComboPopup = new MyBasicComboPopup(this, jComboBox);
/*     */       
/* 350 */       this.popupView = new RelatedTopicsView(this, myBasicComboPopup, jComboBox);
/* 351 */       this.popupView.popup.setFont(this.font);
/* 352 */       this.popupView.popup.setBorder(this.popupView.border);
/* 353 */       this.popupView.combobox.setFont(this.font);
/*     */     } 
/* 355 */     togglePopup(); } class SelectionListener implements ActionListener {
/*     */     private final RelatedTopics this$0; SelectionListener(RelatedTopics this$0) { this.this$0 = this$0; }
/*     */     public void actionPerformed(ActionEvent param1ActionEvent) { if (this.this$0.popupView.combobox.getSelectedIndex() == -1)
/*     */         return;  Component component = container; while (component != null) { if (!(component instanceof JHelpContentViewer)) { component = component.getParent(); continue; }  break; }  String str = (String)this.this$0.popupView.combobox.getSelectedItem(); int i = 0; for (i = 0; i < this.this$0.topics.getTopicCount(); i++) { if (str.compareTo(this.this$0.topics.getTopicString(i)) == 0) { if (component != null) { if (this.this$0.topics.isTopicID(i)) { ((JHelpContentViewer)component).setCurrentID(this.this$0.topics.getTopicID(i)); } else { URL uRL = null; try { uRL = new URL(this.this$0.topics.getTopicURL(i)); } catch (MalformedURLException malformedURLException) { return; }  ((JHelpContentViewer)component).setCurrentURL(uRL); }  container.repaint(); }  i = this.this$0.topics.getTopicCount(); }  }
/*     */        } }
/* 360 */   private Point getPopupPos(Dimension paramDimension, int paramInt1, int paramInt2) { Point point = getLocationOnScreen();
/*     */     
/* 362 */     Toolkit toolkit = getToolkit();
/*     */ 
/*     */     
/* 365 */     if (point.y + paramInt2 + paramDimension.height > (toolkit.getScreenSize()).height)
/*     */     {
/* 367 */       if (paramInt2 + point.y - paramDimension.height > 0) {
/* 368 */         paramInt2 -= paramDimension.height;
/*     */       } else {
/* 370 */         paramInt2 = 1 - point.y;
/*     */       } 
/*     */     }
/*     */     
/* 374 */     if (point.x + paramInt1 + paramDimension.width > (toolkit.getScreenSize()).width)
/*     */     {
/* 376 */       if (paramInt1 + point.x - paramDimension.width > 0) {
/* 377 */         paramInt1 -= paramDimension.width;
/*     */       } else {
/* 379 */         paramInt1 = 1 - point.x;
/*     */       } 
/*     */     }
/* 382 */     return new Point(paramInt1, paramInt2); } class PopupCellRenderer extends JLabel implements ListCellRenderer {
/*     */     private final RelatedTopics this$0; JComboBox combobox; public PopupCellRenderer(RelatedTopics this$0, JComboBox param1JComboBox) { this.this$0 = this$0; this.combobox = param1JComboBox; setOpaque(true); setHorizontalAlignment(2); }
/*     */     public Component getListCellRendererComponent(JList param1JList, Object param1Object, int param1Int, boolean param1Boolean1, boolean param1Boolean2) { if (UIManager.getLookAndFeel().getName().equals("CDE/Motif")) { if (param1Int == -1) { setOpaque(false); } else { setOpaque(true); }  } else { setOpaque(true); }  if (param1Object == null) { setText(""); }
/*     */       else { String str = (String)param1Object; if (!getFont().getName().equals(str)) { setFont(new Font(this.this$0.font.getFamily(), 0, 14)); setText(str); }
/*     */          if (param1Boolean1) { setBackground(UIManager.getColor("ComboBox.selectionBackground")); setForeground(UIManager.getColor("ComboBox.selectionForeground")); }
/*     */         else { setBackground(UIManager.getColor("ComboBox.background")); setForeground(UIManager.getColor("ComboBox.foreground")); }
/*     */          }
/*     */        return this; } }
/* 390 */   private void showPopup() { if (this.popupView.combobox.getSelectedIndex() != -1) {
/* 391 */       this.popupView.combobox.setSelectedIndex(-1);
/*     */     }
/* 393 */     Dimension dimension = this.popupView.popup.getPreferredSize();
/*     */     
/* 395 */     dimension.height = this.popupView.popup.getRequiredHeight(20);
/*     */     
/* 397 */     Insets insets = this.popupView.border.getBorderInsets(this.popupView.popup);
/* 398 */     dimension.width += insets.left;
/*     */     
/* 400 */     this.popupView.popup.setPreferredSize(dimension);
/*     */     
/* 402 */     Toolkit toolkit = this.popupView.popup.getToolkit();
/*     */     
/* 404 */     Point point = getPopupPos(dimension, 5, 5);
/*     */     
/* 406 */     this.popupView.popup.show(this, point.x, point.y); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void hidePopup() {
/* 414 */     this.popupView.popup.hide();
/* 415 */     container.repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void togglePopup() {
/* 424 */     if (this.popupView.popup.isVisible())
/*     */     
/* 426 */     { hidePopup(); }
/*     */     
/*     */     else
/*     */     
/* 430 */     { showPopup(); } 
/*     */   }
/*     */   class Topics {
/*     */     private final RelatedTopics this$0;
/*     */     private String topicList;
/*     */     private int[] topicStringOffsets; private int[] topicURLOffsets; private char delimiter; private int topicCount; private int reqWidth; private int reqHeight; public Topics(RelatedTopics this$0, String param1String) { this.this$0 = this$0; int i = 0; byte b = 0; this.reqHeight = 0; this.reqWidth = 0; this.delimiter = param1String.charAt(0); this.topicCount = 0; i = param1String.indexOf(this.delimiter, i); while (i != -1) { this.topicCount++; i = param1String.indexOf(this.delimiter, i + 1); if (i != -1) i = param1String.indexOf(this.delimiter, i + 1);  }  this.topicStringOffsets = new int[this.topicCount]; this.topicURLOffsets = new int[this.topicCount]; i = 0; for (b = 0; b < this.topicCount; b++) { i = this.topicStringOffsets[b] = param1String.indexOf(this.delimiter, i) + 1; i++; i = this.topicURLOffsets[b] = param1String.indexOf(this.delimiter, i) + 1; i++; }  this.topicList = param1String; } public String getTopicString(int param1Int) { return " " + this.topicList.substring(this.topicStringOffsets[param1Int], this.topicURLOffsets[param1Int] - 1) + " "; } public String getTopicURL(int param1Int) { if (param1Int < this.topicCount - 1) return this.topicList.substring(this.topicURLOffsets[param1Int], this.topicStringOffsets[param1Int + 1] - 1);  return this.topicList.substring(this.topicURLOffsets[param1Int], this.topicList.length()); } public String getTopicID(int param1Int) { if (param1Int < this.topicCount - 1)
/*     */         return this.topicList.substring(this.topicURLOffsets[param1Int] + 1, this.topicStringOffsets[param1Int + 1] - 1);  return this.topicList.substring(this.topicURLOffsets[param1Int] + 1, this.topicList.length()); } public int getTopicCount() { return this.topicCount; } public boolean isTopicID(int param1Int) { if (param1Int < this.topicCount) { if (getTopicURL(param1Int).charAt(0) == '#')
/* 437 */           return true;  return false; }  return false; } } private Dialog getDialog() { Container container1; for (container1 = container.getParent(); container1 != null && !(container1 instanceof Dialog) && 
/* 438 */       !(container1 instanceof java.awt.Window);) container1 = container1.getParent(); 
/* 439 */     if (container1 instanceof Dialog) {
/* 440 */       return (Dialog)container1;
/*     */     }
/* 442 */     return null; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 447 */   private boolean inModalDialog() { return !(getDialog() == null); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 458 */   private static void debug(String paramString) { System.err.println("Related Topics: " + paramString); }
/*     */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\Help\bsscjhrs.jar!\com\bssc\java\help\RelatedTopics.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */