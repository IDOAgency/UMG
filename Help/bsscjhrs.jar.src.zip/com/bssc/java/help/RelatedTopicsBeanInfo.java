package com.bssc.java.help;

import java.beans.PropertyDescriptor;
import java.beans.SimpleBeanInfo;

public class RelatedTopicsBeanInfo extends SimpleBeanInfo {
  public PropertyDescriptor[] getPropertyDescriptors() {
    PropertyDescriptor[] arrayOfPropertyDescriptor = new PropertyDescriptor[12];
    try {
      arrayOfPropertyDescriptor[0] = new PropertyDescriptor("id", RelatedTopics.class);
      arrayOfPropertyDescriptor[1] = new PropertyDescriptor("name", RelatedTopics.class);
      arrayOfPropertyDescriptor[2] = new PropertyDescriptor("topicList", RelatedTopics.class);
      arrayOfPropertyDescriptor[3] = new PropertyDescriptor("text", RelatedTopics.class);
      return arrayOfPropertyDescriptor;
    } catch (Exception exception) {
      return null;
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\Help\bsscjhrs.jar!\com\bssc\java\help\RelatedTopicsBeanInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */