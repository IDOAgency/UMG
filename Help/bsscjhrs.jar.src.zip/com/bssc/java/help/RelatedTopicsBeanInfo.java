/*    */ package com.bssc.java.help;
/*    */ 
/*    */ import java.beans.PropertyDescriptor;
/*    */ import java.beans.SimpleBeanInfo;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RelatedTopicsBeanInfo
/*    */   extends SimpleBeanInfo
/*    */ {
/*    */   public PropertyDescriptor[] getPropertyDescriptors() {
/* 18 */     PropertyDescriptor[] arrayOfPropertyDescriptor = new PropertyDescriptor[12];
/*    */     
/*    */     try {
/* 21 */       arrayOfPropertyDescriptor[0] = new PropertyDescriptor("id", RelatedTopics.class);
/* 22 */       arrayOfPropertyDescriptor[1] = new PropertyDescriptor("name", RelatedTopics.class);
/* 23 */       arrayOfPropertyDescriptor[2] = new PropertyDescriptor("topicList", RelatedTopics.class);
/* 24 */       arrayOfPropertyDescriptor[3] = new PropertyDescriptor("text", RelatedTopics.class);
/* 25 */       return arrayOfPropertyDescriptor;
/*    */     }
/* 27 */     catch (Exception exception) {
/*    */       
/* 29 */       return null;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\Help\bsscjhrs.jar!\com\bssc\java\help\RelatedTopicsBeanInfo.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */