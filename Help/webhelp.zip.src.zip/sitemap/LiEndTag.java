package sitemap;

public class LiEndTag extends Tag {}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\Help\webhelp.zip!\sitemap\LiEndTag.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */