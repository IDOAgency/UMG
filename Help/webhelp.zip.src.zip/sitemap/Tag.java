package sitemap;

import java.io.IOException;

public class Tag {
  protected static Tag parseHTags(char[] paramArrayOfChar, int paramInt) { return (paramArrayOfChar[paramInt] != 't' && paramArrayOfChar[paramInt] != 'T') ? new Tag() : ((paramArrayOfChar[++paramInt] != 'm' && paramArrayOfChar[paramInt] != 'M') ? new Tag() : ((paramArrayOfChar[++paramInt] != 'l' && paramArrayOfChar[paramInt] != 'L') ? new Tag() : ((paramArrayOfChar[++paramInt] != '\000') ? new Tag() : new HtmlTag()))); }
  
  protected static Tag parseUTags(char[] paramArrayOfChar, int paramInt) { return (paramArrayOfChar[paramInt] != 'l' && paramArrayOfChar[paramInt] != 'L') ? new Tag() : ((paramArrayOfChar[++paramInt] != '\000') ? new Tag() : new UlTag()); }
  
  protected static Tag parseTag(char[] paramArrayOfChar, int paramInt) {
    switch (paramArrayOfChar[paramInt]) {
      case 'H':
      case 'h':
        return parseHTags(paramArrayOfChar, paramInt + 1);
      case 'O':
      case 'o':
        return parseOTags(paramArrayOfChar, paramInt + 1);
      case 'L':
      case 'l':
        return parseLTags(paramArrayOfChar, paramInt + 1);
      case 'P':
      case 'p':
        return parsePTags(paramArrayOfChar, paramInt + 1);
      case 'U':
      case 'u':
        return parseUTags(paramArrayOfChar, paramInt + 1);
      case '!':
        return parseCommentTag(paramArrayOfChar, paramInt + 1);
      case '/':
        return parseEndTags(paramArrayOfChar, paramInt + 1);
    } 
    return new Tag();
  }
  
  protected static Tag parseHEndTags(char[] paramArrayOfChar, int paramInt) { return (paramArrayOfChar[paramInt] != 't' && paramArrayOfChar[paramInt] != 'T') ? new Tag() : ((paramArrayOfChar[++paramInt] != 'm' && paramArrayOfChar[paramInt] != 'M') ? new Tag() : ((paramArrayOfChar[++paramInt] != 'l' && paramArrayOfChar[paramInt] != 'L') ? new Tag() : ((paramArrayOfChar[++paramInt] != '\000') ? new Tag() : new HtmlEndTag()))); }
  
  protected static Tag parseLTags(char[] paramArrayOfChar, int paramInt) { return (paramArrayOfChar[paramInt] != 'i' && paramArrayOfChar[paramInt] != 'I') ? new Tag() : ((paramArrayOfChar[++paramInt] != '\000') ? new Tag() : new LiTag()); }
  
  protected static Tag parseUEndTags(char[] paramArrayOfChar, int paramInt) { return (paramArrayOfChar[paramInt] != 'l' && paramArrayOfChar[paramInt] != 'L') ? new Tag() : ((paramArrayOfChar[++paramInt] != '\000') ? new Tag() : new UlEndTag()); }
  
  protected static Tag parseCommentTag(char[] paramArrayOfChar, int paramInt) { return new Tag(); }
  
  protected static Tag parseOTags(char[] paramArrayOfChar, int paramInt) {
    if (paramArrayOfChar[paramInt] != 'b' && paramArrayOfChar[paramInt] != 'B')
      return new Tag(); 
    if (paramArrayOfChar[++paramInt] != 'j' && paramArrayOfChar[paramInt] != 'J')
      return new Tag(); 
    if (paramArrayOfChar[++paramInt] != 'e' && paramArrayOfChar[paramInt] != 'E')
      return new Tag(); 
    if (paramArrayOfChar[++paramInt] != 'c' && paramArrayOfChar[paramInt] != 'C')
      return new Tag(); 
    if (paramArrayOfChar[++paramInt] != 't' && paramArrayOfChar[paramInt] != 'T')
      return new Tag(); 
    if (paramArrayOfChar[++paramInt] > ' ')
      return new Tag(); 
    while (paramArrayOfChar[++paramInt] <= ' ' && paramArrayOfChar[paramInt] != '\000')
      paramInt++; 
    String str = new String(paramArrayOfChar);
    return new ObjectTag(str, paramInt);
  }
  
  protected static Tag parsePTags(char[] paramArrayOfChar, int paramInt) {
    if (paramArrayOfChar[paramInt] != 'a' && paramArrayOfChar[paramInt] != 'A')
      return new Tag(); 
    if (paramArrayOfChar[++paramInt] != 'r' && paramArrayOfChar[paramInt] != 'R')
      return new Tag(); 
    if (paramArrayOfChar[++paramInt] != 'a' && paramArrayOfChar[paramInt] != 'A')
      return new Tag(); 
    if (paramArrayOfChar[++paramInt] != 'm' && paramArrayOfChar[paramInt] != 'M')
      return new Tag(); 
    if (paramArrayOfChar[++paramInt] > ' ')
      return new Tag(); 
    while (paramArrayOfChar[++paramInt] <= ' ' && paramArrayOfChar[paramInt] != '\000')
      paramInt++; 
    String str = new String(paramArrayOfChar);
    return new ParamTag(str, paramInt);
  }
  
  protected static Tag parseLEndTags(char[] paramArrayOfChar, int paramInt) { return (paramArrayOfChar[paramInt] != 'i' && paramArrayOfChar[paramInt] != 'I') ? new Tag() : ((paramArrayOfChar[++paramInt] != '\000') ? new Tag() : new LiEndTag()); }
  
  public static Tag readTag(MyBufferedInputStream paramMyBufferedInputStream) throws TagInvalidException {
    char[] arrayOfChar = new char[256];
    Tag tag = null;
    try {
      boolean bool = false;
      byte b = 0;
      int i = -1;
      for (i = paramMyBufferedInputStream.read(); i != -1; i = paramMyBufferedInputStream.read()) {
        if (bool) {
          if (i == 62) {
            bool = false;
            break;
          } 
          try {
            if (i < 0) {
              arrayOfChar[b] = (char)(i + 256);
            } else {
              arrayOfChar[b] = (char)i;
            } 
          } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
            char[] arrayOfChar1 = new char[arrayOfChar.length + arrayOfChar.length];
            for (byte b1 = 0; b1 < arrayOfChar.length; b1++)
              arrayOfChar1[b1] = arrayOfChar[b1]; 
            if (i < 0) {
              arrayOfChar1[b] = (char)(i + 256);
            } else {
              arrayOfChar1[b] = (char)i;
            } 
            arrayOfChar = arrayOfChar1;
          } 
          b++;
        } else if (i == 60) {
          bool = true;
        } 
        i = -1;
      } 
      if (bool)
        throw new TagInvalidException(1, "EOF reached before end of tag"); 
      if (i == -1 || i == 0)
        throw new TagInvalidException(0, "no more tags detected before end of file"); 
      tag = parseTag(arrayOfChar, 0);
    } catch (IOException iOException) {
      throw new TagInvalidException(2, "IOException thrown : " + iOException.toString());
    } 
    return tag;
  }
  
  protected static Tag parseEndTags(char[] paramArrayOfChar, int paramInt) {
    switch (paramArrayOfChar[paramInt]) {
      case 'H':
      case 'h':
        return parseHEndTags(paramArrayOfChar, paramInt + 1);
      case 'L':
      case 'l':
        return parseLEndTags(paramArrayOfChar, paramInt + 1);
      case 'O':
      case 'o':
        return parseOEndTags(paramArrayOfChar, paramInt + 1);
      case 'U':
      case 'u':
        return parseUEndTags(paramArrayOfChar, paramInt + 1);
    } 
    return new Tag();
  }
  
  protected static Tag parseOEndTags(char[] paramArrayOfChar, int paramInt) { return (paramArrayOfChar[paramInt] != 'b' && paramArrayOfChar[paramInt] != 'B') ? new Tag() : ((paramArrayOfChar[++paramInt] != 'j' && paramArrayOfChar[paramInt] != 'J') ? new Tag() : ((paramArrayOfChar[++paramInt] != 'e' && paramArrayOfChar[paramInt] != 'E') ? new Tag() : ((paramArrayOfChar[++paramInt] != 'c' && paramArrayOfChar[paramInt] != 'C') ? new Tag() : ((paramArrayOfChar[++paramInt] != 't' && paramArrayOfChar[paramInt] != 'T') ? new Tag() : ((paramArrayOfChar[++paramInt] != '\000') ? new Tag() : new ObjectEndTag()))))); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\Help\webhelp.zip!\sitemap\Tag.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */