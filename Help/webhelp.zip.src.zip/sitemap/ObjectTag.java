package sitemap;

public class ObjectTag extends Tag {
  protected String type = "";
  
  public ObjectTag(String paramString, int paramInt) {
    if (paramString.charAt(paramInt) == '\000')
      return; 
    if (paramString.charAt(paramInt) != 't' && paramString.charAt(paramInt) != 'T')
      return; 
    if (paramString.charAt(++paramInt) != 'y' && paramString.charAt(paramInt) != 'Y')
      return; 
    if (paramString.charAt(++paramInt) != 'p' && paramString.charAt(paramInt) != 'P')
      return; 
    if (paramString.charAt(++paramInt) != 'e' && paramString.charAt(paramInt) != 'E')
      return; 
    if (paramString.charAt(++paramInt) != '=')
      return; 
    if (paramString.charAt(++paramInt) == '"')
      paramInt++; 
    int i = paramInt;
    while (paramString.charAt(paramInt) != '\000' && paramString.charAt(paramInt) != '"')
      paramInt++; 
    this.type = paramString.substring(i, paramInt);
  }
  
  public String getType() { return this.type; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\Help\webhelp.zip!\sitemap\ObjectTag.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */