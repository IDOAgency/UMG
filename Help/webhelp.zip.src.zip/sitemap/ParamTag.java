package sitemap;

public class ParamTag extends Tag {
  String name = "";
  
  String value = null;
  
  public String getValue() { return this.value; }
  
  public ParamTag(String paramString, int paramInt) {
    if (paramString.charAt(paramInt) == '\000')
      return; 
    if (paramString.charAt(paramInt) != 'n' && paramString.charAt(paramInt) != 'N')
      return; 
    if (paramString.charAt(++paramInt) != 'a' && paramString.charAt(paramInt) != 'A')
      return; 
    if (paramString.charAt(++paramInt) != 'm' && paramString.charAt(paramInt) != 'M')
      return; 
    if (paramString.charAt(++paramInt) != 'e' && paramString.charAt(paramInt) != 'E')
      return; 
    if (paramString.charAt(++paramInt) != '=')
      return; 
    if (paramString.charAt(++paramInt) == '"')
      paramInt++; 
    int i = paramInt;
    while (paramString.charAt(paramInt) != '\000' && paramString.charAt(paramInt) != '"')
      paramInt++; 
    this.name = paramString.substring(i, paramInt);
    while (paramString.charAt(++paramInt) <= ' ') {
      if (paramString.charAt(paramInt) == '\000')
        return; 
      paramInt++;
    } 
    if (paramString.charAt(paramInt) != 'v' && paramString.charAt(paramInt) != 'V')
      return; 
    if (paramString.charAt(++paramInt) != 'a' && paramString.charAt(paramInt) != 'A')
      return; 
    if (paramString.charAt(++paramInt) != 'l' && paramString.charAt(paramInt) != 'L')
      return; 
    if (paramString.charAt(++paramInt) != 'u' && paramString.charAt(paramInt) != 'U')
      return; 
    if (paramString.charAt(++paramInt) != 'e' && paramString.charAt(paramInt) != 'E')
      return; 
    if (paramString.charAt(++paramInt) != '=')
      return; 
    if (paramString.charAt(++paramInt) == '"')
      paramInt++; 
    i = paramInt;
    while (paramString.charAt(paramInt) != '\000' && paramString.charAt(paramInt) != '"')
      paramInt++; 
    this.value = paramString.substring(i, paramInt);
  }
  
  public String getName() { return this.name; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\Help\webhelp.zip!\sitemap\ParamTag.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */