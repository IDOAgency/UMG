package sitemap;

public class LiTag extends Tag {}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\Help\webhelp.zip!\sitemap\LiTag.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */