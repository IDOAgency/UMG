package sitemap;

public class TagInvalidException extends Exception {
  private int type;
  
  public static final int NOMORE = 0;
  
  public static final int EOF = 1;
  
  public static final int IOERROR = 2;
  
  public TagInvalidException(int paramInt, String paramString) {
    super(paramString);
    this.type = paramInt;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\Help\webhelp.zip!\sitemap\TagInvalidException.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */