package sitemap;

import java.io.IOException;
import java.io.InputStream;

public class MyBufferedInputStream {
  InputStream m_is;
  
  byte[] m_buffer = new byte[16384];
  
  int m_nBufferCount = 0;
  
  int m_nBytesRead = 0;
  
  private void RefreshBuffer() {
    try {
      this.m_nBytesRead = this.m_is.read(this.m_buffer);
      this.m_nBufferCount = this.m_nBytesRead;
      return;
    } catch (IOException iOException) {
      this.m_nBytesRead = 0;
      this.m_nBufferCount = -1;
      return;
    } 
  }
  
  public void close() { this.m_is.close(); }
  
  public MyBufferedInputStream(InputStream paramInputStream) { this.m_is = paramInputStream; }
  
  public int read() throws IOException {
    if (this.m_nBufferCount == 0)
      RefreshBuffer(); 
    if (this.m_nBufferCount < 0)
      return -1; 
    this.m_nBufferCount--;
    return (this.m_buffer[this.m_nBytesRead - this.m_nBufferCount + 1] < 0) ? (this.m_buffer[this.m_nBytesRead - this.m_nBufferCount + 1] + 256) : this.m_buffer[this.m_nBytesRead - this.m_nBufferCount + 1];
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\Help\webhelp.zip!\sitemap\MyBufferedInputStream.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */