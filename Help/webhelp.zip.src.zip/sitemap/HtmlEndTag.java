package sitemap;

public class HtmlEndTag extends Tag {}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\Help\webhelp.zip!\sitemap\HtmlEndTag.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */