package sitemap;

import hhapplet.URLFileHandler;
import java.applet.Applet;
import java.awt.Label;
import java.net.URL;
import java.util.Properties;

public class SiteMapParser extends Thread {
  protected MyBufferedInputStream m_isInputStream;
  
  protected Properties m_properties;
  
  protected SiteMapParserOutput m_smpoOutput;
  
  protected String m_strFileName;
  
  protected URL m_urlDocBase;
  
  protected Applet m_applet;
  
  public void parse() {
    byte b = 0;
    try {
      this.m_isInputStream = new MyBufferedInputStream(URLFileHandler.makeURL(this.m_urlDocBase, this.m_strFileName, null).openStream());
    } catch (Exception exception) {
      this.m_applet.add("Center", new Label("Can't open URL or file " + exception.getMessage()));
      return;
    } 
    this.m_smpoOutput.start();
    try {
      Tag tag;
      for (tag = Tag.readTag(this.m_isInputStream); !(tag instanceof HtmlTag); tag = Tag.readTag(this.m_isInputStream));
      tag = Tag.readTag(this.m_isInputStream);
      while (!(tag instanceof HtmlEndTag)) {
        if (tag instanceof ObjectTag) {
          if (((ObjectTag)tag).getType().equalsIgnoreCase("text/site properties")) {
            for (tag = Tag.readTag(this.m_isInputStream); !(tag instanceof ObjectEndTag); tag = Tag.readTag(this.m_isInputStream)) {
              if (tag instanceof ParamTag)
                try {
                  this.m_smpoOutput.param(((ParamTag)tag).getName(), ((ParamTag)tag).getValue());
                } catch (NullPointerException nullPointerException) {} 
            } 
          } else {
            while (!(tag instanceof ObjectEndTag))
              tag = Tag.readTag(this.m_isInputStream); 
          } 
        } else if (tag instanceof UlTag) {
          parseULTag();
        } 
        tag = Tag.readTag(this.m_isInputStream);
        if (++b % 10 == 0) {
          System.gc();
          Runtime.getRuntime().gc();
        } 
      } 
    } catch (TagInvalidException tagInvalidException) {
      tagInvalidException.printStackTrace();
    } 
    try {
      this.m_isInputStream.close();
    } catch (Exception exception) {}
    this.m_smpoOutput.end();
  }
  
  public SiteMapParserOutput getOutput() { return this.m_smpoOutput; }
  
  public Thread parseInSeparateThread(String paramString, URL paramURL, Applet paramApplet) {
    this.m_strFileName = paramString;
    this.m_urlDocBase = paramURL;
    this.m_applet = paramApplet;
    setPriority(4);
    start();
    return this;
  }
  
  public SiteMapParser(SiteMapParserOutput paramSiteMapParserOutput) {
    this.m_smpoOutput = paramSiteMapParserOutput;
    this.m_properties = new Properties();
  }
  
  public void parseInCurrentThread(String paramString, URL paramURL, Applet paramApplet) {
    this.m_strFileName = paramString;
    this.m_urlDocBase = paramURL;
    this.m_applet = paramApplet;
    parse();
  }
  
  protected void parseULTag() {
    for (Tag tag = Tag.readTag(this.m_isInputStream); !(tag instanceof UlEndTag); tag = Tag.readTag(this.m_isInputStream)) {
      if (tag instanceof LiTag) {
        parseLiTag();
      } else if (tag instanceof UlTag) {
        this.m_smpoOutput.indent(1);
        parseULTag();
        this.m_smpoOutput.indent(-1);
      } 
    } 
  }
  
  public void closeFiles() {
    try {
      this.m_isInputStream.close();
      return;
    } catch (Exception exception) {
      return;
    } 
  }
  
  protected void parseLiTag() {
    Tag tag = Tag.readTag(this.m_isInputStream);
    if (tag instanceof ObjectTag) {
      this.m_smpoOutput.object_start();
      if (((ObjectTag)tag).getType().equalsIgnoreCase("text/sitemap")) {
        for (tag = Tag.readTag(this.m_isInputStream); !(tag instanceof ObjectEndTag); tag = Tag.readTag(this.m_isInputStream)) {
          if (tag instanceof ParamTag)
            this.m_smpoOutput.param(((ParamTag)tag).getName(), ((ParamTag)tag).getValue()); 
        } 
        this.m_smpoOutput.object_end();
        return;
      } 
      while (!(tag instanceof ObjectEndTag))
        tag = Tag.readTag(this.m_isInputStream); 
      return;
    } 
    if (tag instanceof UlTag) {
      this.m_smpoOutput.indent(1);
      parseULTag();
      this.m_smpoOutput.indent(-1);
    } 
  }
  
  public void run() { parse(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\Help\webhelp.zip!\sitemap\SiteMapParser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */