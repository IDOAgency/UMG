package sitemap;

public interface SiteMapParserOutput {
  void end();
  
  void object_start();
  
  void indent(int paramInt);
  
  void start();
  
  void object_end();
  
  void param(String paramString1, String paramString2);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\Help\webhelp.zip!\sitemap\SiteMapParserOutput.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */