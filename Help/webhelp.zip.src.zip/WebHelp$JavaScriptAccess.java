import java.applet.Applet;
import netscape.javascript.JSObject;

class JavaScriptAccess {
  Applet m_a;
  
  final WebHelp this$0;
  
  JavaScriptAccess(WebHelp paramWebHelp, Applet paramApplet) {
    (this.this$0 = paramWebHelp).getClass();
    this.m_a = paramApplet;
  }
  
  public int GetHeight() {
    try {
      JSObject jSObject = JSObject.getWindow(this.m_a);
      Double double = Double.valueOf(jSObject.eval("getheight()").toString());
      return double.intValue();
    } catch (Exception exception) {
      System.out.println("Exception Caught: " + exception.toString());
      return 0;
    } 
  }
  
  public int GetWidth() {
    try {
      JSObject jSObject = JSObject.getWindow(this.m_a);
      Double double = Double.valueOf(jSObject.eval("getwidth()").toString());
      return double.intValue();
    } catch (Exception exception) {
      System.out.println("Exception Caught: " + exception.toString());
      return 0;
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\Help\webhelp.zip!\WebHelp$JavaScriptAccess.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */