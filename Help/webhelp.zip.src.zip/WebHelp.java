import hhapplet.AboutDialogBox;
import hhapplet.ButtonLauncher;
import hhapplet.ButtonPushEvent;
import hhapplet.ButtonPushEventListener;
import hhapplet.FTSPane;
import hhapplet.FTSParser;
import hhapplet.FTSSearcher;
import hhapplet.IndexPane;
import hhapplet.IndexSecondaryDialog;
import hhapplet.IndexSecondaryEntry;
import hhapplet.LabelLauncher;
import hhapplet.PopupMenu;
import hhapplet.SiteMapParserToContents;
import hhapplet.SiteMapParserToIndex;
import hhapplet.SplashScreen;
import hhapplet.TabButton;
import hhapplet.TabPanel;
import hhapplet.URLFileHandler;
import java.applet.Applet;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Image;
import java.awt.Label;
import java.awt.Panel;
import java.awt.Rectangle;
import java.awt.Window;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Vector;
import netscape.javascript.JSObject;
import sitemap.SiteMapParser;
import treeview.TreeViewImageSet;

public class WebHelp extends Applet implements ButtonPushEventListener {
  private static final String STR_APPLET_ID = "WebHelp Applet Version 1.03.131";
  
  private static final String STR_COPYRIGHT = "Copyright (c) 1998-1999 Blue Sky Software Corp. All rights reserved.";
  
  private Window m_winFrameToShow = null;
  
  private String m_strContentsFile = null;
  
  private String m_strIndexFile = null;
  
  private String m_strSearchFile = null;
  
  private String m_strHelpFile = null;
  
  private boolean m_bContentsLoaded = false;
  
  private boolean m_bIndexLoaded = false;
  
  private boolean m_bSearchLoaded = false;
  
  private boolean m_bHelpLoaded = false;
  
  private String m_strCurrentCommand = null;
  
  private Panel m_pnlNav = null;
  
  private TabPanel m_pnlTabs = null;
  
  private CardLayout m_clLayout = null;
  
  private boolean m_bParsing = false;
  
  private Image[] m_imgList = null;
  
  private TreeViewImageSet m_tvisImages = null;
  
  private SiteMapParser m_smpContents = null;
  
  private SiteMapParser m_smpIndex = null;
  
  private SiteMapParser m_smpHelp = null;
  
  private IndexPane m_ipIndex = null;
  
  private FTSPane m_spSearch = null;
  
  private Thread contents_thread = null;
  
  private Thread parser_thread = null;
  
  private Thread search_thread = null;
  
  private TabButton m_tbtnToc = null;
  
  private TabButton m_tbtnIndex = null;
  
  private TabButton m_tbtnSearch = null;
  
  private TabButton m_tbtnHelp = null;
  
  private boolean m_bMustHaveSize = false;
  
  private boolean m_bIsIE3 = false;
  
  private long m_lnTimeCreated = System.currentTimeMillis();
  
  private FTSParser m_ftsParser = null;
  
  private FTSSearcher m_ftsSearcher = null;
  
  public void stop() {
    if (this.m_winFrameToShow != null)
      this.m_winFrameToShow.hide(); 
    System.gc();
    Runtime.getRuntime().gc();
  }
  
  public void notifyButtonPushEvent(ButtonPushEvent paramButtonPushEvent) {
    if (paramButtonPushEvent.getSource() == this.m_tbtnToc) {
      boolean bool = false;
      if (this.m_tbtnToc != null) {
        this.m_tbtnToc.disable();
        this.m_tbtnToc.repaint(0L);
      } 
      if (this.m_tbtnIndex != null) {
        this.m_tbtnIndex.enable();
        this.m_tbtnIndex.SetDrawRight(true);
        if (!bool) {
          bool = true;
          this.m_tbtnIndex.SetDrawLeft(false);
        } else {
          this.m_tbtnIndex.SetDrawLeft(true);
        } 
        this.m_tbtnIndex.repaint(0L);
      } 
      if (this.m_tbtnSearch != null) {
        this.m_tbtnSearch.enable();
        this.m_tbtnSearch.SetDrawRight(true);
        if (!bool) {
          bool = true;
          this.m_tbtnSearch.SetDrawLeft(false);
        } else {
          this.m_tbtnSearch.SetDrawLeft(true);
        } 
        this.m_tbtnSearch.repaint(0L);
      } 
      if (this.m_tbtnHelp != null) {
        this.m_tbtnHelp.enable();
        this.m_tbtnHelp.SetDrawRight(true);
        if (!bool) {
          bool = true;
          this.m_tbtnHelp.SetDrawLeft(false);
        } else {
          this.m_tbtnHelp.SetDrawLeft(true);
        } 
        this.m_tbtnHelp.repaint(0L);
      } 
      RepaintTabs();
      DoContents(this.m_strContentsFile);
      return;
    } 
    if (paramButtonPushEvent.getSource() == this.m_tbtnIndex) {
      boolean bool1 = false;
      boolean bool2 = false;
      if (this.m_tbtnToc != null) {
        this.m_tbtnToc.enable();
        this.m_tbtnToc.SetDrawLeft(true);
        if (!bool2) {
          bool2 = true;
          this.m_tbtnToc.SetDrawRight(false);
        } else {
          this.m_tbtnToc.SetDrawRight(true);
        } 
        this.m_tbtnToc.repaint(0L);
      } 
      if (this.m_tbtnIndex != null) {
        this.m_tbtnIndex.disable();
        this.m_tbtnIndex.repaint(0L);
      } 
      if (this.m_tbtnSearch != null) {
        this.m_tbtnSearch.enable();
        this.m_tbtnSearch.SetDrawRight(true);
        if (!bool1) {
          bool1 = true;
          this.m_tbtnSearch.SetDrawLeft(false);
        } else {
          this.m_tbtnSearch.SetDrawLeft(true);
        } 
        this.m_tbtnSearch.repaint(0L);
      } 
      if (this.m_tbtnHelp != null) {
        this.m_tbtnHelp.enable();
        this.m_tbtnHelp.SetDrawRight(true);
        if (!bool1) {
          bool1 = true;
          this.m_tbtnHelp.SetDrawLeft(false);
        } else {
          this.m_tbtnHelp.SetDrawLeft(true);
        } 
        this.m_tbtnHelp.repaint(0L);
      } 
      RepaintTabs();
      DoIndex(this.m_strIndexFile);
      return;
    } 
    if (paramButtonPushEvent.getSource() == this.m_tbtnSearch) {
      boolean bool1 = false;
      boolean bool2 = false;
      if (this.m_tbtnIndex != null) {
        this.m_tbtnIndex.enable();
        this.m_tbtnIndex.SetDrawLeft(true);
        if (!bool2) {
          bool2 = true;
          this.m_tbtnIndex.SetDrawRight(false);
        } else {
          this.m_tbtnIndex.SetDrawRight(true);
        } 
        this.m_tbtnIndex.repaint(0L);
      } 
      if (this.m_tbtnToc != null) {
        this.m_tbtnToc.enable();
        this.m_tbtnToc.SetDrawLeft(true);
        if (!bool2) {
          bool2 = true;
          this.m_tbtnToc.SetDrawRight(false);
        } else {
          this.m_tbtnToc.SetDrawRight(true);
        } 
        this.m_tbtnToc.repaint(0L);
      } 
      if (this.m_tbtnSearch != null) {
        this.m_tbtnSearch.disable();
        this.m_tbtnSearch.repaint(0L);
      } 
      if (this.m_tbtnHelp != null) {
        this.m_tbtnHelp.enable();
        this.m_tbtnHelp.SetDrawRight(true);
        if (!bool1) {
          bool1 = true;
          this.m_tbtnHelp.SetDrawLeft(false);
        } else {
          this.m_tbtnHelp.SetDrawLeft(true);
        } 
        this.m_tbtnHelp.repaint(0L);
      } 
      RepaintTabs();
      DoSearch(this.m_strSearchFile);
      return;
    } 
    if (this.m_tbtnHelp != null && paramButtonPushEvent.getSource() == this.m_tbtnHelp) {
      boolean bool = false;
      if (this.m_tbtnSearch != null) {
        this.m_tbtnSearch.enable();
        this.m_tbtnSearch.SetDrawLeft(true);
        if (!bool) {
          bool = true;
          this.m_tbtnSearch.SetDrawRight(false);
        } else {
          this.m_tbtnSearch.SetDrawRight(true);
        } 
        this.m_tbtnSearch.repaint(0L);
      } 
      if (this.m_tbtnIndex != null) {
        this.m_tbtnIndex.enable();
        this.m_tbtnIndex.SetDrawLeft(true);
        if (!bool) {
          bool = true;
          this.m_tbtnIndex.SetDrawRight(false);
        } else {
          this.m_tbtnIndex.SetDrawRight(true);
        } 
        this.m_tbtnIndex.repaint(0L);
      } 
      if (this.m_tbtnToc != null) {
        this.m_tbtnToc.enable();
        this.m_tbtnToc.SetDrawLeft(true);
        if (!bool) {
          bool = true;
          this.m_tbtnToc.SetDrawRight(false);
        } else {
          this.m_tbtnToc.SetDrawRight(true);
        } 
        this.m_tbtnToc.repaint(0L);
      } 
      if (this.m_tbtnHelp != null) {
        this.m_tbtnHelp.disable();
        this.m_tbtnHelp.repaint(0L);
      } 
      RepaintTabs();
      DoHelp(this.m_strHelpFile);
    } 
  }
  
  private void DoBadCommand(String paramString) { add(new Label("The command \"" + paramString + "\" is unrecognised")); }
  
  private void DoNavPane() {
    setBackground(new Color(192, 192, 192));
    setLayout(new BorderLayout());
    this.m_strContentsFile = getParameter("ContentsFile");
    this.m_strIndexFile = getParameter("IndexFile");
    this.m_strSearchFile = getParameter("SearchFile");
    this.m_strHelpFile = getParameter("HelpFile");
    String str1 = null;
    if (this.m_strContentsFile != null) {
      str1 = getParameter("TocTab");
      if (str1 == null)
        str1 = " Contents "; 
    } 
    String str2 = null;
    if (this.m_strIndexFile != null) {
      str2 = getParameter("IndexTab");
      if (str2 == null)
        str2 = " Index "; 
    } 
    String str3 = null;
    if (this.m_strSearchFile != null) {
      str3 = getParameter("SearchTab");
      if (str3 == null)
        str3 = " Search "; 
    } 
    String str4 = null;
    if (this.m_strHelpFile != null) {
      str4 = getParameter("HelpTab");
      if (str4 == null)
        str4 = "Help"; 
    } 
    this.m_pnlTabs = null;
    this.m_pnlTabs = new TabPanel();
    this.m_pnlTabs.setLayout(null);
    if (this.m_strContentsFile != null) {
      this.m_tbtnToc = new TabButton(str1);
      this.m_tbtnToc.addButtonPushEventListener(this);
      this.m_pnlTabs.add(this.m_tbtnToc);
    } 
    if (this.m_strIndexFile != null) {
      this.m_tbtnIndex = new TabButton(str2);
      this.m_tbtnIndex.addButtonPushEventListener(this);
      this.m_pnlTabs.add(this.m_tbtnIndex);
    } 
    if (this.m_strSearchFile != null) {
      this.m_tbtnSearch = new TabButton(str3);
      this.m_tbtnSearch.addButtonPushEventListener(this);
      this.m_pnlTabs.add(this.m_tbtnSearch);
    } 
    if (this.m_strHelpFile != null) {
      this.m_tbtnHelp = new TabButton(str4);
      this.m_tbtnHelp.addButtonPushEventListener(this);
      this.m_pnlTabs.add(this.m_tbtnHelp);
    } 
    add("North", this.m_pnlTabs);
    Rectangle rectangle = bounds();
    if (this.m_tbtnToc != null)
      rods_reshape(this.m_tbtnToc, 1, rectangle.y, (this.m_tbtnToc.preferredSize()).width, 25); 
    if (this.m_tbtnIndex != null) {
      int i = 1;
      if (this.m_tbtnToc != null)
        i += (this.m_tbtnToc.bounds()).width; 
      rods_reshape(this.m_tbtnIndex, i, rectangle.y, (this.m_tbtnIndex.preferredSize()).width, 25);
    } 
    if (this.m_tbtnSearch != null) {
      int i = 1;
      if (this.m_tbtnToc != null)
        i += (this.m_tbtnToc.bounds()).width; 
      if (this.m_tbtnIndex != null)
        i += (this.m_tbtnIndex.bounds()).width; 
      rods_reshape(this.m_tbtnSearch, i, rectangle.y, (this.m_tbtnSearch.preferredSize()).width, 25);
    } 
    if (this.m_tbtnHelp != null) {
      int i = 1;
      if (this.m_tbtnToc != null)
        i += (this.m_tbtnToc.bounds()).width; 
      if (this.m_tbtnIndex != null)
        i += (this.m_tbtnIndex.bounds()).width; 
      if (this.m_tbtnSearch != null)
        i += (this.m_tbtnSearch.bounds()).width; 
      rods_reshape(this.m_tbtnHelp, i, rectangle.y, (this.m_tbtnHelp.preferredSize()).width, 25);
    } 
    rods_reshape(this.m_pnlTabs, rectangle.x, rectangle.y, rectangle.width, 28);
    this.m_pnlTabs.requestFocus();
    if (this.m_tbtnIndex != null)
      this.m_tbtnIndex.enable(); 
    if (this.m_tbtnToc != null)
      this.m_tbtnToc.enable(); 
    if (this.m_tbtnSearch != null)
      this.m_tbtnSearch.enable(); 
    if (this.m_tbtnHelp != null)
      this.m_tbtnHelp.enable(); 
    if (this.m_tbtnToc != null)
      this.m_tbtnToc.disable(); 
    if (this.m_tbtnIndex != null)
      this.m_tbtnIndex.disable(); 
    if (this.m_tbtnSearch != null)
      this.m_tbtnSearch.disable(); 
    if (this.m_tbtnHelp != null)
      this.m_tbtnHelp.disable(); 
    boolean bool1 = true;
    boolean bool2 = true;
    String str5 = getParameter("CurrentTab");
    if (str5 != null && (str5.equalsIgnoreCase("Index") || str5.equalsIgnoreCase("Search")))
      bool1 = false; 
    if (str5 != null && (str5.equalsIgnoreCase("Contents") || str5.equalsIgnoreCase("Search")))
      bool2 = false; 
    ButtonPushEvent buttonPushEvent = null;
    if (bool1) {
      buttonPushEvent = new ButtonPushEvent(this.m_tbtnToc, 0, 0);
    } else if (bool2) {
      buttonPushEvent = new ButtonPushEvent(this.m_tbtnIndex, 0, 0);
    } else {
      buttonPushEvent = new ButtonPushEvent(this.m_tbtnSearch, 0, 0);
    } 
    notifyButtonPushEvent(buttonPushEvent);
    try {
      String str = System.getProperty("java.vendor");
      if (str.startsWith("Netscape")) {
        Panel panel = new Panel();
        panel.setLayout(null);
        panel.resize((bounds()).width, 14);
        add("South", panel);
        return;
      } 
    } catch (Exception exception) {}
  }
  
  public void Command(String paramString1, String paramString2) {
    if (paramString1 == null)
      return; 
    if (paramString1.equalsIgnoreCase("Contents")) {
      DoContents(paramString2);
      return;
    } 
    if (paramString1.equalsIgnoreCase("Index")) {
      DoIndex(paramString2);
      return;
    } 
    if (paramString1.equalsIgnoreCase("Search")) {
      DoSearch(paramString2);
      return;
    } 
    if (paramString1.equalsIgnoreCase("Version")) {
      ShowVersion();
      return;
    } 
    DoBadCommand("Command method does not support " + paramString1);
  }
  
  public void destroy() {
    if (this.m_winFrameToShow != null) {
      this.m_winFrameToShow.hide();
      this.m_winFrameToShow.dispose();
      this.m_winFrameToShow = null;
    } 
    if (this.m_smpContents != null) {
      this.m_smpContents.closeFiles();
      this.m_smpContents = null;
    } 
    if (this.m_smpIndex != null) {
      this.m_smpIndex.closeFiles();
      this.m_smpIndex = null;
    } 
    if (this.m_smpHelp != null) {
      this.m_smpHelp.closeFiles();
      this.m_smpHelp = null;
    } 
    if (this.m_ipIndex != null && this.m_ipIndex.getList() != null)
      this.m_ipIndex.getList().clear(); 
    if (this.m_ipIndex != null && this.m_ipIndex.getForAppleList() != null)
      this.m_ipIndex.getForAppleList().clear(); 
    if (this.m_ipIndex != null)
      this.m_ipIndex = null; 
    if (this.m_spSearch != null && this.m_spSearch.getList() != null) {
      this.m_spSearch.getList().clear();
      this.m_spSearch = null;
    } 
    if (this.m_tvisImages != null) {
      this.m_tvisImages.releaseImages(this.m_imgList);
      this.m_tvisImages = null;
    } 
    if (this.contents_thread != null && this.contents_thread.isAlive()) {
      this.contents_thread.stop();
      this.contents_thread = null;
    } 
    if (this.parser_thread != null && this.parser_thread.isAlive()) {
      this.parser_thread.stop();
      this.parser_thread = null;
    } 
    if (this.search_thread != null && this.search_thread.isAlive()) {
      this.search_thread.stop();
      this.search_thread = null;
    } 
    System.gc();
    Runtime.getRuntime().gc();
  }
  
  protected void rods_reshape(Component paramComponent, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    paramComponent.move(paramInt1, paramInt2);
    paramComponent.resize(paramInt3, paramInt4);
  }
  
  private void DoContents(String paramString) {
    if (paramString == null)
      setLayout(new BorderLayout()); 
    if (this.m_pnlNav == null) {
      this.m_clLayout = new CardLayout();
      this.m_pnlNav = new Panel();
      this.m_pnlNav.setLayout(this.m_clLayout);
      add("Center", this.m_pnlNav);
    } 
    if (this.m_tvisImages == null) {
      this.m_tvisImages = new TreeViewImageSet();
      this.m_imgList = new Image[14];
      this.m_imgList = this.m_tvisImages.reallyGetImages();
    } 
    if (paramString == null)
      paramString = getParameter("Item1"); 
    if (this.m_bContentsLoaded && this.m_strContentsFile != null && this.m_strContentsFile.equals(paramString)) {
      this.m_clLayout.show(this.m_pnlNav, "Contents");
      if (this.m_smpContents != null)
        ((SiteMapParserToContents)this.m_smpContents.getOutput()).getTree().requestFocus(); 
      return;
    } 
    this.m_strContentsFile = paramString;
    this.m_bContentsLoaded = true;
    this.m_bMustHaveSize = true;
    repaint(0L);
    RepaintTabs();
    SiteMapParserToContents siteMapParserToContents = new SiteMapParserToContents(this, this.m_imgList);
    if (this.m_smpContents != null)
      this.m_smpContents.closeFiles(); 
    showStatus("Loading Table of Contents...");
    this.m_pnlNav.add("Contents", siteMapParserToContents.getTree());
    this.m_clLayout.show(this.m_pnlNav, "Contents");
    siteMapParserToContents.getTree().requestFocus();
    repaint(0L);
    show();
    this.m_smpContents = new SiteMapParser(siteMapParserToContents);
    this.contents_thread = this.m_smpContents.parseInSeparateThread(paramString, getDocumentBase(), this);
    siteMapParserToContents.getTree().requestFocus();
  }
  
  private void DoHHVersion(boolean paramBoolean) {
    String str1 = null;
    String str2 = null;
    String str3 = null;
    if (!paramBoolean) {
      str1 = getParameter("Button");
      str2 = getParameter("Text");
      if (str1 == null && str2 == null)
        return; 
      str3 = (str1 != null) ? str1 : str2;
    } 
    Vector vector = new Vector();
    vector.addElement("WebHelp Applet Version 1.03.131");
    vector.addElement("Copyright (c) 1998-1999 Blue Sky Software Corp. All rights reserved.");
    try {
      vector.addElement("Java VM vendor: " + System.getProperty("java.vendor"));
    } catch (Exception exception) {}
    try {
      vector.addElement("Java version: " + System.getProperty("java.version"));
    } catch (Exception exception) {}
    try {
      vector.addElement("Java library version: " + System.getProperty("java.class.version"));
    } catch (Exception exception) {}
    try {
      String str = "Operating System: " + System.getProperty("os.name") + " " + System.getProperty("os.version") + " (" + System.getProperty("os.arch") + ")";
      vector.addElement(str);
    } catch (Exception exception) {}
    AboutDialogBox aboutDialogBox = new AboutDialogBox("About WebHelp Applet", vector);
    if (paramBoolean) {
      aboutDialogBox.show();
      return;
    } 
    ButtonLauncher buttonLauncher = (str1 != null) ? new ButtonLauncher(str3, aboutDialogBox) : new LabelLauncher(str3, aboutDialogBox);
    setLayout(new BorderLayout());
    add("Center", buttonLauncher);
    this.m_winFrameToShow = aboutDialogBox;
  }
  
  public void resize(int paramInt1, int paramInt2) {
    if (System.getProperty("java.vendor").startsWith("Netscape") && (System.getProperty("os.name").startsWith("Windows") || System.getProperty("os.name").startsWith("Mac")) && !getParameter("BrowserVersion").equalsIgnoreCase("4.6")) {
      JavaScriptAccess javaScriptAccess = new JavaScriptAccess(this, this);
      int i = javaScriptAccess.GetHeight();
      if (i >= 0)
        paramInt2 = i; 
    } 
    super.resize(paramInt1, paramInt2);
  }
  
  public boolean checkSize() {
    if ((bounds()).width == 0 && (bounds()).height == 0) {
      String str1 = getDocumentBase().toString();
      int i = str1.lastIndexOf(".");
      String str2 = str1.substring(i, str1.length());
      str1 = str1.substring(0, i);
      str1 = str1 + "f" + str2;
      try {
        URL uRL = new URL(str1);
        getAppletContext().showDocument(uRL, "_self");
        return false;
      } catch (Exception exception) {}
    } 
    return true;
  }
  
  private void DoSearch(String paramString) {
    if (paramString == null)
      setLayout(new BorderLayout()); 
    if (this.m_pnlNav == null) {
      this.m_clLayout = new CardLayout();
      this.m_pnlNav = new Panel();
      this.m_pnlNav.setLayout(this.m_clLayout);
      add("Center", this.m_pnlNav);
    } 
    if (paramString == null)
      paramString = getParameter("Item1"); 
    if (this.m_bSearchLoaded && this.m_strSearchFile != null && this.m_strSearchFile.equals(paramString)) {
      this.m_clLayout.show(this.m_pnlNav, "Search");
      if (this.m_spSearch != null)
        this.m_spSearch.getEditBox().requestFocus(); 
      return;
    } 
    this.m_strSearchFile = paramString;
    this.m_bSearchLoaded = true;
    this.m_bMustHaveSize = true;
    this.m_ftsParser = new FTSParser(this);
    this.m_spSearch = this.m_ftsParser.getFTS();
    this.m_ftsSearcher = this.m_ftsParser.getSearcher();
    if (this.m_spSearch != null && this.m_spSearch.getList() != null) {
      this.m_spSearch.getList().clear();
      this.m_spSearch.getList().addItem("Reading Search Data...");
    } 
    this.m_pnlNav.add("Search", this.m_spSearch);
    this.m_clLayout.show(this.m_pnlNav, "Search");
    repaint();
    RepaintTabs();
    showStatus("Reading Search Data...");
    show();
    this.search_thread = this.m_ftsParser.parseInSeparateThread(paramString, getDocumentBase());
  }
  
  private void DoSplash() {
    showStatus("Loading Splash Image...");
    try {
      Image image = null;
      String str = null;
      try {
        image = getImage(URLFileHandler.makeURL(getDocumentBase(), getParameter("Item1"), null));
      } finally {}
      int i = 2500;
      try {
        i = (new Integer(getParameter("Item2"))).intValue();
      } catch (NumberFormatException numberFormatException) {}
      SplashScreen splashScreen = new SplashScreen(this, image, i, str);
      splashScreen.show();
      return;
    } catch (MalformedURLException malformedURLException) {
      add("Center", new Label("Can't open URL or file " + malformedURLException.getMessage()));
      return;
    } 
  }
  
  private void DoAboutBox() {
    String str1 = getParameter("Button");
    String str2 = getParameter("Text");
    if (str1 == null && str2 == null)
      return; 
    String str3 = (str1 != null) ? str1 : str2;
    String str4 = getParameter("Item1");
    Vector vector = new Vector();
    String str5;
    for (byte b = 0; (str5 = getParameter("Item" + (b + 2))) != null; b++)
      vector.addElement(str5); 
    AboutDialogBox aboutDialogBox = new AboutDialogBox(str4, vector);
    ButtonLauncher buttonLauncher = (str1 != null) ? new ButtonLauncher(str3, aboutDialogBox) : new LabelLauncher(str3, aboutDialogBox);
    setLayout(new BorderLayout());
    add("Center", buttonLauncher);
    this.m_winFrameToShow = aboutDialogBox;
  }
  
  private void RepaintTabs() {
    if (this.m_pnlNav != null)
      this.m_pnlNav.paintAll(this.m_pnlNav.getGraphics()); 
    if (this.m_tbtnToc != null)
      this.m_tbtnToc.paint(this.m_tbtnToc.getGraphics()); 
    if (this.m_tbtnIndex != null)
      this.m_tbtnIndex.paint(this.m_tbtnIndex.getGraphics()); 
    if (this.m_tbtnSearch != null)
      this.m_tbtnSearch.paint(this.m_tbtnSearch.getGraphics()); 
    if (this.m_tbtnHelp != null)
      this.m_tbtnHelp.paint(this.m_tbtnHelp.getGraphics()); 
  }
  
  private void DoIndex(String paramString) {
    if (paramString == null)
      setLayout(new BorderLayout()); 
    if (this.m_pnlNav == null) {
      this.m_clLayout = new CardLayout();
      this.m_pnlNav = new Panel();
      this.m_pnlNav.setLayout(this.m_clLayout);
      add("Center", this.m_pnlNav);
    } 
    if (paramString == null)
      paramString = getParameter("Item1"); 
    if (this.m_bIndexLoaded && this.m_strIndexFile != null && this.m_strIndexFile.equals(paramString)) {
      this.m_clLayout.show(this.m_pnlNav, "Index");
      if (this.m_ipIndex != null)
        this.m_ipIndex.getEditBox().requestFocus(); 
      return;
    } 
    this.m_strIndexFile = paramString;
    this.m_bIndexLoaded = true;
    this.m_bMustHaveSize = true;
    SiteMapParserToIndex siteMapParserToIndex = new SiteMapParserToIndex(this);
    if (this.m_ipIndex != null && this.m_ipIndex.getList() != null)
      this.m_ipIndex.getList().clear(); 
    this.m_ipIndex = siteMapParserToIndex.getIndex();
    this.m_pnlNav.add("Index", this.m_ipIndex);
    this.m_clLayout.show(this.m_pnlNav, "Index");
    this.m_pnlNav.paintAll(this.m_pnlNav.getGraphics());
    RepaintTabs();
    showStatus("Loading Index...");
    if (this.m_smpIndex != null)
      this.m_smpIndex.closeFiles(); 
    if (this.m_ipIndex != null)
      this.m_ipIndex.getEditBox().requestFocus(); 
    show();
    this.m_smpIndex = new SiteMapParser(siteMapParserToIndex);
    if (this.m_ipIndex.GetUseForAppleListFlag()) {
      this.m_ipIndex.paintAll(this.m_ipIndex.getGraphics());
      this.m_smpIndex.parseInCurrentThread(paramString, getDocumentBase(), this);
      return;
    } 
    this.parser_thread = this.m_smpIndex.parseInSeparateThread(paramString, getDocumentBase(), this);
  }
  
  public void start() {
    if (this.m_bMustHaveSize)
      checkSize(); 
  }
  
  public String getAppletInfo() { return "WebHelp Applet Version 1.03.131" + "\r\n" + "Copyright (c) 1998-1999 Blue Sky Software Corp. All rights reserved."; }
  
  public void Click() {
    if (this.m_winFrameToShow != null) {
      if (this.m_bIsIE3) {
        MethodRunner methodRunner = new MethodRunner(this.m_winFrameToShow, "ClickThread");
        methodRunner.start();
        return;
      } 
      this.m_winFrameToShow.show();
    } 
  }
  
  private void ShowVersion() { DoHHVersion(true); }
  
  public static int GetFontSize() { return 12; }
  
  public static String GetFontName() { return "Dialog"; }
  
  public void init() {
    System.gc();
    Runtime.getRuntime().gc();
    this.m_lnTimeCreated = System.currentTimeMillis();
    System.out.println("********************Java Information*********************");
    System.out.println("Java VM");
    System.out.println("  Version = " + System.getProperty("java.version"));
    System.out.println("  Vender = " + System.getProperty("java.vendor"));
    System.out.println("Operating System");
    System.out.println("  Name = " + System.getProperty("os.name"));
    System.out.println("Memory");
    System.out.println("  Total = " + Runtime.getRuntime().totalMemory());
    System.out.println("  Free = " + Runtime.getRuntime().freeMemory());
    System.out.println("*********************************************************");
    if (System.getProperty("java.vendor").startsWith("Microsoft") && System.getProperty("java.version").startsWith("1.0"))
      this.m_bIsIE3 = true; 
    String str = getParameter("Command");
    if (str == null)
      return; 
    if (str.equalsIgnoreCase("Contents")) {
      DoContents(null);
    } else if (str.equalsIgnoreCase("Index")) {
      DoIndex(null);
    } else if (str.equalsIgnoreCase("Search")) {
      DoSearch(null);
    } else if (str.equalsIgnoreCase("Splash")) {
      DoSplash();
    } else if (str.equalsIgnoreCase("Help")) {
      DoHelp(null);
    } else if (str.equalsIgnoreCase("Related Topics")) {
      DoRelatedTopics(false);
    } else if (str.equalsIgnoreCase("Related Topics,MENU")) {
      DoRelatedTopics(true);
    } else if (str.equalsIgnoreCase("HH Version")) {
      DoHHVersion(false);
    } else if (str.equalsIgnoreCase("AboutBox")) {
      DoAboutBox();
    } else if (str.equalsIgnoreCase("NavPane")) {
      DoNavPane();
    } else {
      DoBadCommand(str);
    } 
    this.m_strCurrentCommand = str;
    show();
  }
  
  private void DoHelp(String paramString) {}
  
  private void DoRelatedTopics(boolean paramBoolean) {
    showStatus("Loading Related Topics Button...");
    String str1 = getParameter("Button");
    String str2 = getParameter("Text");
    String str3 = getParameter("Frame");
    if (paramBoolean && System.getProperty("os.name").startsWith("SunOS"))
      paramBoolean = false; 
    boolean bool = (str1 != null || str2 != null) ? 0 : 1;
    String str4 = "";
    if (!bool)
      str4 = (str1 != null) ? str1 : str2; 
    Vector vector = new Vector();
    byte b = 0;
    String str5;
    while ((str5 = getParameter("Item" + (b + true))) != null) {
      IndexSecondaryEntry indexSecondaryEntry = new IndexSecondaryEntry();
      int i = str5.indexOf(';');
      if (i != -1 && i != str5.length() - 1) {
        int j = str5.indexOf(';', i + 1);
        String str6 = str5.substring(0, i);
        String str7 = (j == -1) ? str5.substring(i + 1) : str5.substring(i + 1, j);
        String str8 = (j == -1) ? null : str5.substring(i + 1);
        indexSecondaryEntry.name = str6;
        indexSecondaryEntry.local = str7;
        indexSecondaryEntry.url = str8;
        indexSecondaryEntry.frame = str3;
        vector.addElement(indexSecondaryEntry);
        b++;
      } 
    } 
    if (b == 0)
      return; 
    if (paramBoolean) {
      PopupMenu popupMenu = new PopupMenu(this, vector);
      this.m_winFrameToShow = popupMenu;
    } else {
      IndexSecondaryDialog indexSecondaryDialog = new IndexSecondaryDialog(this, vector, null);
      this.m_winFrameToShow = indexSecondaryDialog;
    } 
    if (!bool) {
      LabelLauncher labelLauncher;
      if (str1 != null) {
        labelLauncher = new ButtonLauncher(str4, this.m_winFrameToShow);
      } else {
        labelLauncher = new LabelLauncher(str4, this.m_winFrameToShow);
      } 
      setLayout(new BorderLayout());
      add("Center", labelLauncher);
    } 
  }
  
  public void reshape(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (System.getProperty("java.vendor").startsWith("Netscape") && (System.getProperty("os.name").startsWith("Windows") || System.getProperty("os.name").startsWith("Mac")) && !getParameter("BrowserVersion").equalsIgnoreCase("4.6")) {
      JavaScriptAccess javaScriptAccess = new JavaScriptAccess(this, this);
      int i = javaScriptAccess.GetHeight();
      if (i >= 0)
        paramInt4 = i; 
    } 
    super.reshape(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  class JavaScriptAccess {
    Applet m_a;
    
    final WebHelp this$0;
    
    JavaScriptAccess(WebHelp this$0, Applet param1Applet) {
      (this.this$0 = this$0).getClass();
      this.m_a = param1Applet;
    }
    
    public int GetHeight() {
      try {
        JSObject jSObject = JSObject.getWindow(this.m_a);
        Double double = Double.valueOf(jSObject.eval("getheight()").toString());
        return double.intValue();
      } catch (Exception exception) {
        System.out.println("Exception Caught: " + exception.toString());
        return 0;
      } 
    }
    
    public int GetWidth() {
      try {
        JSObject jSObject = JSObject.getWindow(this.m_a);
        Double double = Double.valueOf(jSObject.eval("getwidth()").toString());
        return double.intValue();
      } catch (Exception exception) {
        System.out.println("Exception Caught: " + exception.toString());
        return 0;
      } 
    }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\Help\webhelp.zip!\WebHelp.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */