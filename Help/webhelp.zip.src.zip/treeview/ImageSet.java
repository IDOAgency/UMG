package treeview;

import java.awt.Image;

public class ImageSet {
  protected Image[] images;
  
  public ImageSet() { this(null); }
  
  public ImageSet(Image[] paramArrayOfImage) {
    if (paramArrayOfImage == null) {
      paramArrayOfImage = null;
      return;
    } 
    this.images = new Image[paramArrayOfImage.length];
    for (byte b = 0; b < paramArrayOfImage.length; b++)
      this.images[b] = paramArrayOfImage[b]; 
  }
  
  public Image getImage(int paramInt) {
    try {
      return this.images[paramInt];
    } catch (NullPointerException nullPointerException) {
      throw new IndexOutOfBoundsException("ImageSet(): no images set for this ImageSet.");
    } 
  }
  
  public ImageSet getImages(int paramInt1, int paramInt2) {
    if (this.images == null)
      throw new IndexOutOfBoundsException("ImageSet(): no images set for this ImageSet."); 
    if (paramInt1 < 0)
      throw new IndexOutOfBoundsException("ImageSet(): offset less than zero"); 
    if (paramInt1 >= this.images.length)
      throw new IndexOutOfBoundsException("ImageSet(): offset greater than number of images in set"); 
    if (paramInt1 + paramInt2 > this.images.length)
      throw new IndexOutOfBoundsException("ImageSet(): to many images requested"); 
    Image[] arrayOfImage = new Image[paramInt2];
    for (int i = 0; i < paramInt2; i++)
      arrayOfImage[i] = this.images[paramInt1 + i]; 
    return new ImageSet(arrayOfImage);
  }
  
  public ImageSet getImages(int[] paramArrayOfInt) {
    if (this.images == null)
      throw new IndexOutOfBoundsException("ImageSet(): no images set for this ImageSet."); 
    if (paramArrayOfInt == null)
      throw new NullPointerException("ImageSet(): images_to_retrieve is a null reference"); 
    Image[] arrayOfImage = new Image[paramArrayOfInt.length];
    for (byte b = 0; b < paramArrayOfInt.length; b++)
      arrayOfImage[b] = getImage(paramArrayOfInt[b]); 
    return new ImageSet(arrayOfImage);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\Help\webhelp.zip!\treeview\ImageSet.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */