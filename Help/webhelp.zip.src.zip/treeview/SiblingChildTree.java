package treeview;

public class SiblingChildTree {
  protected SiblingChildTree parent = null;
  
  protected SiblingChildTree sibling_left = null;
  
  protected SiblingChildTree sibling_right = null;
  
  protected SiblingChildTree child = null;
  
  public SiblingChildTree getChild() { return this.child; }
  
  public SiblingChildTree pruneThisSubtree() {
    if (this.sibling_left != null) {
      this.sibling_left.sibling_right = this.sibling_right;
      if (this.sibling_right != null)
        this.sibling_right.sibling_left = this.sibling_left; 
    } else if (this.sibling_right != null) {
      this.sibling_right.sibling_left = null;
      if (this.parent != null)
        this.parent.child = this.sibling_right; 
    } 
    SiblingChildTree siblingChildTree;
    for (siblingChildTree = this; siblingChildTree.parent != null; siblingChildTree = siblingChildTree.parent);
    while (siblingChildTree.sibling_left != null)
      siblingChildTree = siblingChildTree.sibling_left; 
    if (siblingChildTree == this)
      siblingChildTree = this.sibling_right; 
    this.parent = null;
    this.sibling_left = null;
    this.sibling_right = null;
    return siblingChildTree;
  }
  
  protected void setParent(SiblingChildTree paramSiblingChildTree) {
    this.parent = paramSiblingChildTree;
    if (this.sibling_right != null)
      this.sibling_right.setParent(paramSiblingChildTree); 
  }
  
  public SiblingChildTree getParent() { return this.parent; }
  
  public SiblingChildTree nextNode() {
    if (this.child != null)
      return this.child; 
    if (this.sibling_right != null)
      return this.sibling_right; 
    for (SiblingChildTree siblingChildTree = this.parent; siblingChildTree != null; siblingChildTree = siblingChildTree.parent) {
      if (siblingChildTree.sibling_right != null)
        return siblingChildTree.sibling_right; 
    } 
    return null;
  }
  
  public SiblingChildTree getSibling() { return this.sibling_right; }
  
  public SiblingChildTree prevNode() {
    if (this.sibling_left != null) {
      SiblingChildTree siblingChildTree = this.sibling_left.child;
      if (siblingChildTree == null)
        return this.sibling_left; 
      while (siblingChildTree.sibling_right != null)
        siblingChildTree = siblingChildTree.sibling_right; 
      return lastBeforeMatch(siblingChildTree);
    } 
    return (this.parent != null) ? lastBeforeMatch(this.parent) : null;
  }
  
  private SiblingChildTree lastBeforeMatch(SiblingChildTree paramSiblingChildTree) {
    SiblingChildTree siblingChildTree = null;
    do {
      if (siblingChildTree != null)
        paramSiblingChildTree = siblingChildTree; 
      siblingChildTree = paramSiblingChildTree.nextNode();
    } while (siblingChildTree != this);
    return paramSiblingChildTree;
  }
  
  public SiblingChildTree[] getChildren() {
    SiblingChildTree[] arrayOfSiblingChildTree = new SiblingChildTree[numberOfChildren()];
    SiblingChildTree siblingChildTree = this.child;
    for (byte b = 0; b < arrayOfSiblingChildTree.length; b++) {
      arrayOfSiblingChildTree[b] = siblingChildTree;
      siblingChildTree = siblingChildTree.sibling_right;
    } 
    return arrayOfSiblingChildTree;
  }
  
  public int numberOfChildren() {
    byte b = 0;
    for (SiblingChildTree siblingChildTree = this.child; siblingChildTree != null; siblingChildTree = siblingChildTree.sibling_right)
      b++; 
    return b;
  }
  
  public SiblingChildTree pruneChildren() {
    if (this.child == null)
      return null; 
    this.child.setParent(null);
    SiblingChildTree siblingChildTree = this.child;
    this.child = null;
    return siblingChildTree;
  }
  
  public boolean isSibling(SiblingChildTree paramSiblingChildTree) {
    if (this == paramSiblingChildTree)
      return false; 
    SiblingChildTree siblingChildTree;
    for (siblingChildTree = this; siblingChildTree.sibling_left != null; siblingChildTree = siblingChildTree.sibling_left);
    while (siblingChildTree != null) {
      if (siblingChildTree == paramSiblingChildTree)
        return true; 
      siblingChildTree = siblingChildTree.sibling_right;
    } 
    return false;
  }
  
  public void addChild(SiblingChildTree paramSiblingChildTree) {
    if (paramSiblingChildTree == null)
      throw new IllegalArgumentException("SiblingChildTree.addChild(): child is a null reference"); 
    if (this.child == null) {
      this.child = paramSiblingChildTree;
      paramSiblingChildTree.setParent(this);
      return;
    } 
    this.child.addSibling(paramSiblingChildTree);
  }
  
  public SiblingChildTree getSiblingLeft() { return this.sibling_left; }
  
  public void addSibling(SiblingChildTree paramSiblingChildTree) {
    if (paramSiblingChildTree == null)
      throw new IllegalArgumentException("SiblingChildTree.addSibling(): sibling is a null reference"); 
    if (this.sibling_right == null) {
      this.sibling_right = paramSiblingChildTree;
      paramSiblingChildTree.sibling_left = this;
      paramSiblingChildTree.setParent(this.parent);
      return;
    } 
    for (SiblingChildTree siblingChildTree = this.sibling_right; siblingChildTree.getSibling() != null; siblingChildTree = siblingChildTree.getSibling());
    siblingChildTree.addSibling(paramSiblingChildTree);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\Help\webhelp.zip!\treeview\SiblingChildTree.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */