package treeview;

public interface ImageSetSource {
  ImageSet getImages();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\Help\webhelp.zip!\treeview\ImageSetSource.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */