package treeview;

import java.awt.Image;
import java.awt.Toolkit;
import java.awt.image.ColorModel;
import java.awt.image.IndexColorModel;
import java.awt.image.MemoryImageSource;

public class TreeViewConnectorImageSet extends ImageSet {
  protected static Image vertical_line;
  
  protected static Image line;
  
  protected static Image line_start;
  
  protected static Image line_tee;
  
  protected static Image line_end;
  
  protected static Image button_collapsed;
  
  protected static Image button_expanded;
  
  protected static final int IMAGE_WIDTH = 16;
  
  protected static final int IMAGE_HEIGHT = 16;
  
  public static final int VERTICAL_LINE = 0;
  
  public static final int LINE = 1;
  
  public static final int LINE_START = 2;
  
  public static final int LINE_TEE = 3;
  
  public static final int LINE_END = 4;
  
  public static final int BUTTON_COLLAPSED = 5;
  
  public static final int BUTTON_EXPANDED = 6;
  
  private static Image makeImage(byte[] paramArrayOfByte, ColorModel paramColorModel) { return Toolkit.getDefaultToolkit().createImage(new MemoryImageSource(16, 16, paramColorModel, paramArrayOfByte, 0, 16)); }
  
  private static void drawLine(byte[] paramArrayOfByte) {
    byte b = 4;
    do {
      paramArrayOfByte['' + b] = 1;
      b += 2;
    } while (b < 15);
  }
  
  private static void drawEnd(byte[] paramArrayOfByte) {
    drawLine(paramArrayOfByte);
    boolean bool = true;
    do {
      paramArrayOfByte[bool * 16 + 4] = 1;
      bool += true;
    } while (bool <= 9);
  }
  
  private static void drawVertLine(byte[] paramArrayOfByte) {
    boolean bool = true;
    do {
      paramArrayOfByte[bool * 16 + 4] = 1;
      bool += true;
    } while (bool <= 15);
  }
  
  private static void drawStart(byte[] paramArrayOfByte) {
    drawLine(paramArrayOfByte);
    byte b = 9;
    do {
      paramArrayOfByte[b * 16 + 4] = 1;
      b += 2;
    } while (b <= 15);
  }
  
  private static void drawTee(byte[] paramArrayOfByte) {
    drawLine(paramArrayOfByte);
    boolean bool = true;
    do {
      paramArrayOfByte[bool * 16 + 4] = 1;
      bool += true;
    } while (bool <= 15);
  }
  
  public TreeViewConnectorImageSet() {
    this.images = new Image[7];
    this.images[0] = vertical_line;
    this.images[1] = line;
    this.images[2] = line_start;
    this.images[3] = line_tee;
    this.images[4] = line_end;
    this.images[5] = button_collapsed;
    this.images[6] = button_expanded;
  }
  
  private static void drawMinus(byte[] paramArrayOfByte) {
    byte b = 2;
    do {
      paramArrayOfByte['' + b] = 2;
    } while (++b <= 6);
  }
  
  private static void drawPlus(byte[] paramArrayOfByte) {
    drawMinus(paramArrayOfByte);
    byte b = 7;
    do {
      paramArrayOfByte[b * 16 + 4] = 2;
    } while (++b <= 11);
  }
  
  private static void drawBox(byte[] paramArrayOfByte) {
    byte b = 5;
    do {
      byte b1 = 0;
      do {
        if (!b1) {
          paramArrayOfByte[b * 16 + b1] = 1;
        } else if (b1 == 8) {
          paramArrayOfByte[b * 16 + b1] = 1;
        } else if (b == 5) {
          paramArrayOfByte[b * 16 + b1] = 1;
        } else if (b == 13) {
          paramArrayOfByte[b * 16 + b1] = 1;
        } else {
          paramArrayOfByte[b * 16 + b1] = 3;
        } 
      } while (++b1 < 9);
    } while (++b < 14);
  }
  
  static  {
    IndexColorModel indexColorModel;
    byte[] arrayOfByte1 = new byte[4];
    byte[] arrayOfByte2 = new byte[4];
    byte[] arrayOfByte3 = new byte[4];
    arrayOfByte1[0] = -1;
    arrayOfByte2[0] = -1;
    arrayOfByte3[0] = -1;
    arrayOfByte1[1] = Byte.MIN_VALUE;
    arrayOfByte2[1] = Byte.MIN_VALUE;
    arrayOfByte3[1] = Byte.MIN_VALUE;
    arrayOfByte1[2] = 0;
    arrayOfByte2[2] = 0;
    arrayOfByte3[2] = 0;
    arrayOfByte1[3] = -1;
    arrayOfByte2[3] = -1;
    arrayOfByte3[3] = -1;
    if (System.getProperty("java.vendor").startsWith("Microsoft") && System.getProperty("java.version").startsWith("1.1") && System.getProperty("os.name").startsWith("Windows NT")) {
      indexColorModel = new IndexColorModel(8, 4, arrayOfByte1, arrayOfByte2, arrayOfByte3);
    } else {
      indexColorModel = new IndexColorModel(8, 4, arrayOfByte1, arrayOfByte2, arrayOfByte3, 0);
    } 
    byte[] arrayOfByte4 = new byte[256];
    drawVertLine(arrayOfByte4);
    vertical_line = makeImage(arrayOfByte4, indexColorModel);
    arrayOfByte4 = new byte[256];
    drawLine(arrayOfByte4);
    line = makeImage(arrayOfByte4, indexColorModel);
    arrayOfByte4 = new byte[256];
    drawStart(arrayOfByte4);
    line_start = makeImage(arrayOfByte4, indexColorModel);
    arrayOfByte4 = new byte[256];
    drawTee(arrayOfByte4);
    line_tee = makeImage(arrayOfByte4, indexColorModel);
    arrayOfByte4 = new byte[256];
    drawEnd(arrayOfByte4);
    line_end = makeImage(arrayOfByte4, indexColorModel);
    arrayOfByte4 = new byte[256];
    drawBox(arrayOfByte4);
    drawMinus(arrayOfByte4);
    button_expanded = makeImage(arrayOfByte4, indexColorModel);
    arrayOfByte4 = new byte[256];
    drawBox(arrayOfByte4);
    drawPlus(arrayOfByte4);
    button_collapsed = makeImage(arrayOfByte4, indexColorModel);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\Help\webhelp.zip!\treeview\TreeViewConnectorImageSet.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */