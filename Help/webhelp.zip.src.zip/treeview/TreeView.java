package treeview;

import WebHelp;
import java.applet.Applet;
import java.awt.Button;
import java.awt.Color;
import java.awt.Component;
import java.awt.Event;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Panel;
import java.awt.Rectangle;
import java.awt.Scrollbar;

public class TreeView extends Panel implements ImageSetSource {
  protected int m_nLabelOffset = 6;
  
  protected ImageSet m_isImages;
  
  protected ImageSet m_isConnectors;
  
  protected TreeViewNode m_tvnRoot;
  
  protected boolean m_bLayoutComplete = false;
  
  protected boolean m_bUseButtons = true;
  
  protected boolean m_bUseLines = false;
  
  protected boolean m_bRootsConnected = true;
  
  protected Applet m_applet = null;
  
  protected TreeViewNode m_tvnCurrentSelection;
  
  protected Image m_imgDoubleBuffer;
  
  protected Rectangle m_rectDisplayArea;
  
  protected Scrollbar m_sbHorizontal = new Scrollbar(0);
  
  protected Scrollbar m_sbVertical = new Scrollbar(1);
  
  protected Button m_btnScrollerCorner = new Button();
  
  protected int m_nInsetX = 5;
  
  protected int m_nInsetY = 1;
  
  protected int m_nConnectorWidth = 16;
  
  protected int m_nIndent = 7 + this.m_nConnectorWidth;
  
  protected int m_nIconWidth = 20;
  
  protected int m_nIconHeight = 16;
  
  protected int m_nCellHeight = this.m_nIconHeight + 1;
  
  protected int m_nFontBaseOffset = this.m_nIconHeight;
  
  private boolean m_bNetscapeScrollers = false;
  
  private boolean m_bLayedOutByMouseOver = false;
  
  private boolean m_bCompletelyFilled = false;
  
  private int m_nHorizPosPixels = 0;
  
  private int m_nVerticalPosPixels = 0;
  
  private int m_nImageWidth = 0;
  
  private int m_nImageHeight = 0;
  
  public static final int LEAF = 0;
  
  public static final int BRANCH_COLLAPSED = 1;
  
  public static final int BRANCH_EXPANDED = 2;
  
  public static final int LEAF_SELECTED = 3;
  
  public static final int BRANCH_COLLAPSED_SELECTED = 4;
  
  public static final int BRANCH_EXPANDED_SELECTED = 5;
  
  public static final int MIN_NUMBER_IMAGES = 3;
  
  public static final int MIN_NUMBER_IMAGES_SELECTED = 6;
  
  protected static final int HEIGHT_HORIZONTAL_SB = 16;
  
  protected static final int WIDTH_VERTICAL_SB = 16;
  
  protected static final int ICON_VERTICAL_PADDING = 1;
  
  protected long c_lnDoubleClickWindow = 500L;
  
  private boolean m_bIsNS3Win32 = false;
  
  private boolean m_bIsNSWin16 = false;
  
  private boolean m_bIsUnix = false;
  
  private long m_lnLastClickTime = 0L;
  
  private boolean m_bIsMac = false;
  
  private boolean m_bNeedTreeSize = true;
  
  protected boolean m_bMaxWidthIsValid = false;
  
  protected boolean m_bMaxHeightIsValid = false;
  
  private int m_nMaxWidth = 0;
  
  private int m_nMaxHeight = 0;
  
  private boolean m_bUseDoubleBuffer = true;
  
  public boolean mouseEnter(Event paramEvent, int paramInt1, int paramInt2) {
    if (paramEvent.target == this.m_sbHorizontal || paramEvent.target == this.m_sbVertical)
      return super.mouseEnter(paramEvent, paramInt1, paramInt2); 
    if (!this.m_bLayoutComplete)
      layout(); 
    if (this.m_applet != null) {
      TreeViewNode treeViewNode = nodeAtLocation(paramInt1, paramInt2);
      if (treeViewNode != null && this.m_bCompletelyFilled)
        this.m_applet.showStatus(treeViewNode.getLabel()); 
    } 
    return false;
  }
  
  public boolean gotFocus(Event paramEvent, Object paramObject) {
    if (this.m_tvnCurrentSelection == null) {
      setSelectionToTop();
      repaint();
    } 
    return true;
  }
  
  public void MoveSelectionDown() { MoveSelectionDown(true); }
  
  public void MoveSelectionDown(boolean paramBoolean) {
    if (this.m_tvnCurrentSelection.nextNode(true) == null)
      return; 
    this.m_tvnCurrentSelection.select(false);
    this.m_tvnCurrentSelection = this.m_tvnCurrentSelection.nextNode(true);
    this.m_tvnCurrentSelection.select(true);
    EnsureDisplayed(this.m_tvnCurrentSelection);
    if (paramBoolean)
      InternalSelectionHasChanged(); 
    repaint();
  }
  
  public void ScrollSubTreeIntoView(TreeViewNode paramTreeViewNode) {
    if (paramTreeViewNode == null)
      return; 
    int i = GetNodePosition(paramTreeViewNode);
    if (i < this.m_sbVertical.getValue()) {
      this.m_sbVertical.setValue(i);
    } else {
      int j = GetOpenChildSiblingCount((TreeViewNode)paramTreeViewNode.getChild());
      int k = this.m_rectDisplayArea.height / this.m_nCellHeight - 1;
      if (j > 0)
        if (j >= k - 1) {
          this.m_sbVertical.setValue(i);
        } else if (this.m_sbVertical.getValue() < i - k - j) {
          this.m_sbVertical.setValue(i - k - j - 1);
        }  
    } 
    this.m_nVerticalPosPixels = this.m_sbVertical.getValue() * this.m_nCellHeight;
  }
  
  public int getLabelOffset() { return this.m_nLabelOffset; }
  
  public void setLabelOffset(int paramInt) { this.m_nLabelOffset = paramInt; }
  
  public void CollapseTree() {
    this.m_bMaxHeightIsValid = false;
    this.m_bMaxWidthIsValid = false;
    this.m_tvnCurrentSelection.collapseTree();
    layout();
    repaint();
  }
  
  protected int getMaxWidth(TreeViewNode paramTreeViewNode, int paramInt, boolean paramBoolean) {
    if (!this.m_bMaxWidthIsValid)
      this.m_nMaxWidth = getMaxSubTreeWidth(paramTreeViewNode, paramInt, paramBoolean); 
    return this.m_nMaxWidth;
  }
  
  public void expandAll() {
    this.m_bMaxHeightIsValid = false;
    this.m_bMaxWidthIsValid = false;
    try {
      this.m_tvnRoot.expandTree();
      return;
    } catch (NullPointerException nullPointerException) {
      return;
    } 
  }
  
  public int GetNodePosition(TreeViewNode paramTreeViewNode) {
    TreeViewNode treeViewNode = this.m_tvnRoot;
    byte b = 0;
    while (treeViewNode != null) {
      if (paramTreeViewNode == treeViewNode)
        return b; 
      if (treeViewNode.getLabel() != null)
        b++; 
      treeViewNode = treeViewNode.nextNode(true);
    } 
    return -1;
  }
  
  protected void sizeTree(TreeViewNode paramTreeViewNode) {
    for (TreeViewNode treeViewNode = paramTreeViewNode; treeViewNode != null; treeViewNode = (TreeViewNode)treeViewNode.getSibling()) {
      sizeNode(treeViewNode);
      sizeTree((TreeViewNode)treeViewNode.getChild());
    } 
    this.m_bNeedTreeSize = false;
  }
  
  public void setSelectionToTop() {
    if (this.m_tvnCurrentSelection != null)
      this.m_tvnCurrentSelection.select(false); 
    this.m_tvnCurrentSelection = this.m_tvnRoot;
    while (this.m_tvnCurrentSelection != null && this.m_tvnCurrentSelection.getLabel() == null)
      this.m_tvnCurrentSelection = this.m_tvnCurrentSelection.nextNode(true); 
    if (this.m_tvnCurrentSelection != null)
      this.m_tvnCurrentSelection.select(true); 
  }
  
  public int getCellHeight() { return this.m_nCellHeight; }
  
  public void setCellHeight(int paramInt) {
    if (paramInt < this.m_nIconHeight + 1) {
      this.m_nCellHeight = this.m_nIconHeight + 1;
      return;
    } 
    this.m_nCellHeight = paramInt;
  }
  
  public void layout() {
    this.m_bLayoutComplete = false;
    this.m_rectDisplayArea.reshape(0, 0, (bounds()).width, (bounds()).height);
    if (this.m_rectDisplayArea.width < 1 || this.m_rectDisplayArea.height < 1)
      return; 
    try {
      if (this.m_bNeedTreeSize)
        sizeTree(this.m_tvnRoot); 
      int i = getMaxWidth(this.m_tvnRoot, 0, true);
      int j = getMaxHeight(this.m_tvnRoot, 0, true) / this.m_nCellHeight - 1;
      if (j < 1)
        return; 
      if (i + 1 > this.m_rectDisplayArea.width)
        this.m_rectDisplayArea.height -= 16; 
      int k = this.m_rectDisplayArea.height / this.m_nCellHeight;
      if (j > k)
        this.m_rectDisplayArea.width -= 16; 
      rods_reshape(this.m_sbHorizontal, 0, this.m_rectDisplayArea.height, this.m_rectDisplayArea.width, 16);
      this.m_sbHorizontal.setValues(this.m_nHorizPosPixels, this.m_rectDisplayArea.width, 0, i - (this.m_bNetscapeScrollers ? this.m_rectDisplayArea.width : 0));
      rods_reshape(this.m_sbVertical, this.m_rectDisplayArea.width, 0, 16, this.m_rectDisplayArea.height);
      int m = this.m_nVerticalPosPixels / this.m_nCellHeight;
      if (m + k > j)
        m = j - k; 
      if (m < 0)
        m = 0; 
      this.m_sbVertical.setValues(m, k - 1, 0, j - (this.m_bNetscapeScrollers ? k : 1));
      this.m_nVerticalPosPixels = this.m_sbVertical.getValue() * this.m_nCellHeight;
      rods_reshape(this.m_btnScrollerCorner, this.m_rectDisplayArea.width, this.m_rectDisplayArea.height, 16, 16);
      if (this.m_rectDisplayArea.height < 0)
        this.m_rectDisplayArea.height = 0; 
      if (this.m_rectDisplayArea.width < 0)
        this.m_rectDisplayArea.width = 0; 
      if (this.m_imgDoubleBuffer != null && (this.m_nImageWidth != this.m_rectDisplayArea.width || this.m_nImageHeight != this.m_rectDisplayArea.height)) {
        this.m_imgDoubleBuffer.flush();
        this.m_imgDoubleBuffer = null;
      } 
      if (this.m_imgDoubleBuffer == null) {
        this.m_imgDoubleBuffer = createImage(this.m_rectDisplayArea.width, this.m_rectDisplayArea.height);
        this.m_nImageWidth = this.m_rectDisplayArea.width;
        this.m_nImageHeight = this.m_rectDisplayArea.height;
      } 
      this.m_bLayoutComplete = true;
      return;
    } catch (Exception exception) {
      this.m_imgDoubleBuffer = null;
      return;
    } 
  }
  
  public boolean IsDisplayed(TreeViewNode paramTreeViewNode) {
    TreeViewNode treeViewNode = GetFirstDisplayedNode();
    int i = this.m_rectDisplayArea.height / this.m_nCellHeight;
    while (treeViewNode != null && i > 0) {
      if (treeViewNode.getLabel() != null)
        i--; 
      if (paramTreeViewNode == treeViewNode)
        return true; 
      treeViewNode = treeViewNode.nextNode(true);
    } 
    return false;
  }
  
  protected void toggleOpenCloseNode(TreeViewNode paramTreeViewNode) {
    this.m_bMaxHeightIsValid = false;
    this.m_bMaxWidthIsValid = false;
    paramTreeViewNode.setCollapsedState(!paramTreeViewNode.getCollapsedState());
    if (paramTreeViewNode.getCollapsedState()) {
      this.m_tvnCurrentSelection.select(false);
      for (TreeViewNode treeViewNode = (TreeViewNode)this.m_tvnCurrentSelection.getParent(); treeViewNode != null; treeViewNode = (TreeViewNode)treeViewNode.getParent()) {
        if (treeViewNode.getCollapsedState())
          this.m_tvnCurrentSelection = treeViewNode; 
      } 
      this.m_tvnCurrentSelection.select(true);
      InternalSelectionHasChanged();
      int i = getMaxHeight(this.m_tvnRoot, 0, true) / this.m_nCellHeight - 1;
      int j = this.m_rectDisplayArea.height / this.m_nCellHeight;
      int k = this.m_nVerticalPosPixels / this.m_nCellHeight;
      if (k + j > i)
        k = Math.max(i - j, 0); 
      this.m_nVerticalPosPixels = k * this.m_nCellHeight;
      return;
    } 
    layout();
    ScrollSubTreeIntoView(this.m_tvnCurrentSelection);
  }
  
  public TreeViewNode nextVisibleNode() {
    try {
      return this.m_tvnRoot.nextNode(true);
    } catch (NullPointerException nullPointerException) {
      return null;
    } 
  }
  
  public TreeViewNode previousVisibleNode() {
    try {
      return this.m_tvnRoot.prevNode(true);
    } catch (NullPointerException nullPointerException) {
      return null;
    } 
  }
  
  public void setTopIndex(int paramInt) {
    int i = this.m_rectDisplayArea.height / this.m_nCellHeight;
    int j = getMaxHeight(this.m_tvnRoot, 0, true) / this.m_nCellHeight - 1;
    this.m_nVerticalPosPixels = paramInt * this.m_nCellHeight;
    this.m_sbVertical.setValues(paramInt, i - 1, 0, j - (this.m_bNetscapeScrollers ? i : 1));
    paintAll(getGraphics());
  }
  
  public void MoveSelectionHome() {
    setSelectionToTop();
    this.m_sbVertical.setValue(0);
    this.m_nVerticalPosPixels = this.m_sbVertical.getValue() * this.m_nCellHeight;
    repaint();
  }
  
  public void CollapseBranch() {
    this.m_bMaxHeightIsValid = false;
    this.m_bMaxWidthIsValid = false;
    this.m_tvnCurrentSelection.setCollapsedState(true);
    layout();
    repaint();
  }
  
  public boolean mouseExit(Event paramEvent, int paramInt1, int paramInt2) {
    if (paramEvent.target == this.m_sbHorizontal || paramEvent.target == this.m_sbVertical)
      return super.mouseExit(paramEvent, paramInt1, paramInt2); 
    if (this.m_applet != null && this.m_bCompletelyFilled)
      this.m_applet.showStatus(""); 
    return false;
  }
  
  public void setFilled(boolean paramBoolean) {
    this.m_bCompletelyFilled = paramBoolean;
    this.m_bLayoutComplete = false;
    this.m_bNeedTreeSize = true;
    this.m_bMaxHeightIsValid = false;
    this.m_bMaxWidthIsValid = false;
    repaint();
  }
  
  public void setApplet(Applet paramApplet) { this.m_applet = paramApplet; }
  
  protected void rods_reshape(Component paramComponent, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    paramComponent.move(paramInt1, paramInt2);
    paramComponent.resize(paramInt3, paramInt4);
  }
  
  public boolean getUseLines() { return this.m_bUseLines; }
  
  public TreeViewNode getRoot() { return this.m_tvnRoot; }
  
  public void setRoot(TreeViewNode paramTreeViewNode) {
    this.m_tvnRoot = paramTreeViewNode;
    setSelectionToTop();
  }
  
  public void setUseLines(boolean paramBoolean) { this.m_bUseLines = paramBoolean; }
  
  protected void InternalSelectionHasChanged() {}
  
  protected int drawConnector(Graphics paramGraphics, TreeViewNode paramTreeViewNode, int paramInt1, int paramInt2) {
    if (this.m_bUseButtons && this.m_bUseLines) {
      Image image1 = null;
      Image image2 = null;
      try {
        if (paramTreeViewNode.getChild() != null)
          if (paramTreeViewNode.getCollapsedState() == true) {
            image1 = this.m_isConnectors.getImage(5);
          } else {
            image1 = this.m_isConnectors.getImage(6);
          }  
      } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
        image1 = null;
      } catch (NullPointerException nullPointerException) {
        image1 = null;
      } 
      try {
        if (paramTreeViewNode.getParent() == null) {
          if (this.m_bRootsConnected) {
            if (paramTreeViewNode.getSiblingLeft() == null) {
              if (paramTreeViewNode.getSibling() == null) {
                image2 = this.m_isConnectors.getImage(1);
              } else {
                image2 = this.m_isConnectors.getImage(2);
              } 
            } else if (paramTreeViewNode.getSibling() == null) {
              image2 = this.m_isConnectors.getImage(4);
            } else {
              image2 = this.m_isConnectors.getImage(3);
            } 
          } else {
            image2 = this.m_isConnectors.getImage(1);
          } 
        } else if (paramTreeViewNode.getSiblingLeft() == null && paramTreeViewNode.getParent() != null && ((TreeViewNode)paramTreeViewNode.getParent()).getLabel() == null) {
          image2 = this.m_isConnectors.getImage(2);
        } else if (paramTreeViewNode.getSibling() == null) {
          image2 = this.m_isConnectors.getImage(4);
        } else {
          image2 = this.m_isConnectors.getImage(3);
        } 
      } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
        image2 = null;
      } catch (NullPointerException nullPointerException) {
        image2 = null;
      } 
      if (image2 != null)
        paramGraphics.drawImage(image2, paramInt1, paramInt2, this); 
      if (image1 != null)
        paramGraphics.drawImage(image1, paramInt1, paramInt2, this); 
      paramInt1 += this.m_nConnectorWidth;
    } else if (this.m_bUseButtons) {
      Image image = null;
      try {
        if (paramTreeViewNode.getChild() != null)
          if (paramTreeViewNode.getCollapsedState() == true) {
            image = this.m_isConnectors.getImage(5);
          } else {
            image = this.m_isConnectors.getImage(6);
          }  
      } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
        image = null;
      } catch (NullPointerException nullPointerException) {
        image = null;
      } 
      if (image != null)
        paramGraphics.drawImage(image, paramInt1, paramInt2, this); 
      paramInt1 += this.m_nConnectorWidth;
    } else if (this.m_bUseLines) {
      Image image = null;
      try {
        if (paramTreeViewNode.getParent() == null) {
          if (this.m_bRootsConnected) {
            if (paramTreeViewNode.getSiblingLeft() == null) {
              if (paramTreeViewNode.getSibling() == null) {
                image = this.m_isConnectors.getImage(1);
              } else {
                image = this.m_isConnectors.getImage(2);
              } 
            } else if (paramTreeViewNode.getSibling() == null) {
              image = this.m_isConnectors.getImage(4);
            } else {
              image = this.m_isConnectors.getImage(3);
            } 
          } else {
            image = this.m_isConnectors.getImage(1);
          } 
        } else if (paramTreeViewNode.getSibling() == null) {
          image = this.m_isConnectors.getImage(4);
        } else {
          image = this.m_isConnectors.getImage(3);
        } 
      } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
        image = null;
      } catch (NullPointerException nullPointerException) {
        image = null;
      } 
      if (image != null)
        paramGraphics.drawImage(image, paramInt1, paramInt2, this); 
      paramInt1 += this.m_nConnectorWidth;
    } 
    return paramInt1;
  }
  
  protected void paintBorder(Graphics paramGraphics) {
    Rectangle rectangle = this.m_rectDisplayArea;
    Color color1 = getBackground();
    Color color2 = color1.darker();
    Color color3 = color2.darker();
    Color color4 = color3.darker();
    paramGraphics.setColor(color3);
    paramGraphics.drawLine(0, 0, rectangle.width - 1, 0);
    paramGraphics.drawLine(0, 0, 0, rectangle.height - 1);
    paramGraphics.setColor(color4);
    paramGraphics.drawLine(1, 1, rectangle.width - 2, 1);
    paramGraphics.drawLine(1, 1, 1, rectangle.height - 2);
    paramGraphics.setColor(color2);
    paramGraphics.drawLine(rectangle.width - 2, 1, rectangle.width - 2, rectangle.height - 2);
    paramGraphics.drawLine(1, rectangle.height - 2, rectangle.width - 2, rectangle.height - 2);
    paramGraphics.setColor(color1);
    paramGraphics.drawLine(rectangle.width - 1, 1, rectangle.width - 1, rectangle.height - 1);
    paramGraphics.drawLine(0, rectangle.height - 1, rectangle.width - 1, rectangle.height - 1);
  }
  
  public void collapseAll() {
    this.m_bMaxHeightIsValid = false;
    this.m_bMaxWidthIsValid = false;
    try {
      this.m_tvnRoot.collapseTree();
      return;
    } catch (NullPointerException nullPointerException) {
      return;
    } 
  }
  
  public int getIconHeight() { return this.m_nIconHeight; }
  
  public void setIconHeight(int paramInt) {
    if (paramInt < 0)
      paramInt = 0; 
    this.m_nIconHeight = paramInt;
    if (paramInt > this.m_nCellHeight - 1)
      this.m_nCellHeight = paramInt + 1; 
  }
  
  protected int getMaxSubTreeHeight(TreeViewNode paramTreeViewNode, int paramInt, boolean paramBoolean) {
    int i = paramInt;
    for (TreeViewNode treeViewNode = paramTreeViewNode; treeViewNode != null; treeViewNode = (TreeViewNode)treeViewNode.getSibling()) {
      i += treeViewNode.getHeight();
      if (!paramBoolean || !treeViewNode.getCollapsedState())
        i = getMaxSubTreeHeight((TreeViewNode)treeViewNode.getChild(), i, paramBoolean); 
    } 
    return i;
  }
  
  public int getIndent() { return this.m_nIndent; }
  
  public void setIndent(int paramInt) { this.m_nIndent = paramInt; }
  
  public boolean getRootsConnected() { return this.m_bRootsConnected; }
  
  public void setRootsConnected(boolean paramBoolean) { this.m_bRootsConnected = paramBoolean; }
  
  public boolean handleEvent(Event paramEvent) {
    switch (paramEvent.id) {
      case 501:
        if (paramEvent.target != this.m_sbHorizontal && paramEvent.target != this.m_sbVertical && this.m_rectDisplayArea.inside(paramEvent.x, paramEvent.y)) {
          int i = paramEvent.x + this.m_nHorizPosPixels;
          int j = 11;
          TreeViewNode treeViewNode = nodeAtLocation(paramEvent.x, paramEvent.y);
          if (treeViewNode != null) {
            boolean bool = (this.m_bIsMac || paramEvent.clickCount % 2 != 0) ? 0 : 1;
            if (this.m_bIsUnix || this.m_bIsMac || this.m_bIsNSWin16) {
              long l = System.currentTimeMillis();
              if (this.m_lnLastClickTime > l - this.c_lnDoubleClickWindow) {
                bool = true;
                this.m_lnLastClickTime = 0L;
              } else {
                this.m_lnLastClickTime = l;
              } 
            } 
            if (this.m_bIsMac && !bool)
              paramEvent.clickCount = 1; 
            if (treeViewNode.getChild() != null && i > (treeViewNode.getBounds()).x && (i < (treeViewNode.getBounds()).x + j || bool)) {
              requestFocus();
              if (this.m_tvnCurrentSelection != null)
                this.m_tvnCurrentSelection.select(false); 
              this.m_tvnCurrentSelection = treeViewNode;
              this.m_tvnCurrentSelection.select(true);
              InternalSelectionHasChanged();
              treeViewNode.doAction();
              toggleOpenCloseNode(treeViewNode);
              layout();
              requestFocus();
              repaint();
            } else if (i > (treeViewNode.getBounds()).x + j && paramEvent.clickCount < 2) {
              if (this.m_tvnCurrentSelection != null)
                this.m_tvnCurrentSelection.select(false); 
              this.m_tvnCurrentSelection = treeViewNode;
              this.m_tvnCurrentSelection.select(true);
              InternalSelectionHasChanged();
              treeViewNode.doAction();
              repaint();
            } 
            if (bool)
              treeViewNode.doDblClick(); 
          } 
        } 
        break;
      case 601:
      case 602:
      case 603:
      case 604:
      case 605:
        if (paramEvent.target == this.m_sbHorizontal) {
          this.m_nHorizPosPixels = this.m_sbHorizontal.getValue();
        } else if (paramEvent.target == this.m_sbVertical) {
          this.m_nVerticalPosPixels = this.m_sbVertical.getValue() * this.m_nCellHeight;
        } 
        repaint();
        break;
      case 402:
        if (System.getProperty("java.vendor").startsWith("Netscape") && System.getProperty("java.version").equalsIgnoreCase("1.1.2") && System.getProperty("os.name").startsWith("Mac"))
          this.m_tvnCurrentSelection.doAction(); 
        break;
      case 401:
        switch (paramEvent.key) {
          case 10:
            if (System.getProperty("java.vendor").startsWith("Netscape") && System.getProperty("java.version").equalsIgnoreCase("1.02"))
              this.m_tvnCurrentSelection.doAction(); 
            if (System.getProperty("java.vendor").startsWith("Netscape") && System.getProperty("java.version").equalsIgnoreCase("1.1.5")) {
              this.m_tvnCurrentSelection.doAction();
              break;
            } 
            if (System.getProperty("java.vendor").startsWith("Microsoft") && System.getProperty("java.version").equalsIgnoreCase("1.0.2"))
              this.m_tvnCurrentSelection.doAction(); 
            break;
          case 45:
            CollapseBranch();
            break;
          case 43:
            ExpandBranch();
            break;
        } 
        break;
      case 403:
        switch (paramEvent.key) {
          case 10:
            this.m_tvnCurrentSelection.doAction();
            break;
          case 1004:
            MoveSelectionUp();
            break;
          case 1005:
            MoveSelectionDown();
            break;
          case 1006:
            if (this.m_tvnCurrentSelection.getChild() == null || this.m_tvnCurrentSelection.getCollapsedState() == true) {
              if (this.m_tvnCurrentSelection.getParent() != null)
                MoveSelectionToParent(); 
              break;
            } 
            if ((paramEvent.modifiers & true) == 1) {
              CollapseTree();
              break;
            } 
            CollapseBranch();
            break;
          case 1007:
            if (!this.m_tvnCurrentSelection.getCollapsedState()) {
              if (this.m_tvnCurrentSelection.getChild() != null)
                MoveSelectionDown(); 
              break;
            } 
            if ((paramEvent.modifiers & true) == 1) {
              ExpandTree();
              break;
            } 
            ExpandBranch();
            break;
          case 1002:
            MoveSelectionPgUp();
            break;
          case 1003:
            MoveSelectionPgDn();
            break;
          case 1001:
            MoveSelectionEnd();
            break;
          case 1000:
            MoveSelectionHome();
            break;
        } 
        break;
    } 
    return super.handleEvent(paramEvent);
  }
  
  public void MoveSelectionToParent() {
    if (this.m_tvnCurrentSelection.getParent() == null)
      return; 
    if (this.m_tvnCurrentSelection.getParent() == this.m_tvnRoot)
      return; 
    this.m_tvnCurrentSelection.select(false);
    this.m_tvnCurrentSelection = (TreeViewNode)this.m_tvnCurrentSelection.getParent();
    this.m_tvnCurrentSelection.select(true);
    EnsureDisplayed(this.m_tvnCurrentSelection);
    InternalSelectionHasChanged();
    repaint();
  }
  
  public void ExpandTree() {
    this.m_bMaxHeightIsValid = false;
    this.m_bMaxWidthIsValid = false;
    this.m_tvnCurrentSelection.expandTree();
    layout();
    repaint();
  }
  
  protected int paintTree(Graphics paramGraphics, TreeViewNode paramTreeViewNode, int paramInt1, int paramInt2, Rectangle paramRectangle) {
    TreeViewNode treeViewNode = paramTreeViewNode;
    while (treeViewNode != null) {
      int i = paramInt1;
      int j = paramInt2;
      if (treeViewNode.getLabel() != null) {
        if (paramRectangle.inside(paramInt1, paramInt2) || paramRectangle.inside(paramInt1, paramInt2 + this.m_nCellHeight))
          paintNode(paramGraphics, treeViewNode, paramInt1, paramInt2); 
        i += this.m_nIndent;
        j += this.m_nCellHeight;
      } 
      if (!treeViewNode.getCollapsedState()) {
        paramInt2 = paintTree(paramGraphics, (TreeViewNode)treeViewNode.getChild(), i, j, paramRectangle);
      } else {
        paramInt2 = j;
      } 
      treeViewNode = (TreeViewNode)treeViewNode.getSibling();
      if (j > paramRectangle.y + paramRectangle.height)
        treeViewNode = null; 
    } 
    return paramInt2;
  }
  
  protected TreeViewNode nodeAtLocation(int paramInt1, int paramInt2) {
    if (!this.m_rectDisplayArea.inside(paramInt1, paramInt2))
      return null; 
    int i = paramInt2 + this.m_nVerticalPosPixels;
    for (TreeViewNode treeViewNode = this.m_tvnRoot; treeViewNode != null; treeViewNode = treeViewNode.nextNode(true)) {
      Rectangle rectangle = treeViewNode.getBounds();
      if (i > rectangle.y && i <= rectangle.y + rectangle.height && treeViewNode.getLabel() != null)
        return treeViewNode; 
    } 
    return null;
  }
  
  public boolean mouseMove(Event paramEvent, int paramInt1, int paramInt2) {
    if (paramEvent.target == this.m_sbHorizontal || paramEvent.target == this.m_sbVertical)
      return super.mouseMove(paramEvent, paramInt1, paramInt2); 
    if (!this.m_bLayoutComplete)
      layout(); 
    if (this.m_applet != null) {
      TreeViewNode treeViewNode = nodeAtLocation(paramInt1, paramInt2);
      if (treeViewNode != null) {
        if (this.m_bCompletelyFilled)
          this.m_applet.showStatus(treeViewNode.getLabel()); 
      } else if (this.m_bCompletelyFilled) {
        this.m_applet.showStatus("");
      } 
    } 
    return false;
  }
  
  protected void sizeNode(TreeViewNode paramTreeViewNode) {
    if (paramTreeViewNode == null)
      return; 
    FontMetrics fontMetrics = getFontMetrics(getFont());
    int i = 0;
    if (this.m_bUseButtons || this.m_bUseLines)
      i = this.m_nIconWidth; 
    if (paramTreeViewNode.getCurrentImage() != null)
      i += this.m_nIconWidth + this.m_nLabelOffset; 
    if (paramTreeViewNode.getLabel() != null) {
      i += fontMetrics.stringWidth(paramTreeViewNode.getLabel());
    } else if (paramTreeViewNode.getCurrentImage() != null) {
      i -= this.m_nLabelOffset;
    } 
    paramTreeViewNode.setBounds(0, 0, i, this.m_nCellHeight);
  }
  
  public TreeViewNode nextNode(boolean paramBoolean) {
    try {
      return (TreeViewNode)this.m_tvnRoot.prevNode();
    } catch (NullPointerException nullPointerException) {
      return null;
    } 
  }
  
  public TreeViewNode previousNode(boolean paramBoolean) {
    try {
      return (TreeViewNode)this.m_tvnRoot.prevNode();
    } catch (NullPointerException nullPointerException) {
      return null;
    } 
  }
  
  public void ExpandBranch() {
    this.m_bMaxHeightIsValid = false;
    this.m_bMaxWidthIsValid = false;
    this.m_tvnCurrentSelection.setCollapsedState(false);
    layout();
    ScrollSubTreeIntoView(this.m_tvnCurrentSelection);
    repaint();
  }
  
  public void update(Graphics paramGraphics) {
    if (!this.m_bLayoutComplete)
      layout(); 
    paint(paramGraphics);
  }
  
  public int getXInset() { return this.m_nInsetX; }
  
  public void setXInset(int paramInt) {
    if (paramInt < 0)
      paramInt = 0; 
    paramInt = paramInt;
  }
  
  public void MoveSelectionUp() { MoveSelectionUp(true); }
  
  public ImageSet getConnectors() { return this.m_isConnectors; }
  
  public void setConnectors(ImageSet paramImageSet) { this.m_isConnectors = paramImageSet; }
  
  public int getIconWidth() { return this.m_nIconWidth; }
  
  public void setIconWidth(int paramInt) {
    if (paramInt < 0)
      paramInt = 0; 
    this.m_nIconWidth = paramInt;
  }
  
  public void MoveSelectionUp(boolean paramBoolean) {
    if (this.m_tvnCurrentSelection.prevNode(true) == null)
      return; 
    if (this.m_tvnCurrentSelection.prevNode(true) == this.m_tvnRoot)
      return; 
    this.m_tvnCurrentSelection.select(false);
    this.m_tvnCurrentSelection = this.m_tvnCurrentSelection.prevNode(true);
    this.m_tvnCurrentSelection.select(true);
    EnsureDisplayed(this.m_tvnCurrentSelection);
    if (paramBoolean)
      InternalSelectionHasChanged(); 
    repaint();
  }
  
  protected int getMaxSubTreeWidth(TreeViewNode paramTreeViewNode, int paramInt, boolean paramBoolean) {
    int i = 0;
    for (TreeViewNode treeViewNode = paramTreeViewNode; treeViewNode != null; treeViewNode = (TreeViewNode)treeViewNode.getSibling()) {
      if (treeViewNode.getWidth() + paramInt > i)
        i = treeViewNode.getWidth() + paramInt; 
      if (!paramBoolean || !treeViewNode.getCollapsedState()) {
        int j = getMaxSubTreeWidth((TreeViewNode)treeViewNode.getChild(), paramInt + this.m_nIndent, paramBoolean);
        if (j > i)
          i = j; 
      } 
    } 
    return i;
  }
  
  public boolean isFocusTraversable() { return true; }
  
  protected int getMaxHeight(TreeViewNode paramTreeViewNode, int paramInt, boolean paramBoolean) {
    if (!this.m_bMaxHeightIsValid)
      this.m_nMaxHeight = getMaxSubTreeHeight(paramTreeViewNode, paramInt, paramBoolean); 
    return this.m_nMaxHeight;
  }
  
  public int getYInset() { return this.m_nInsetY; }
  
  public void setYInset(int paramInt) {
    if (paramInt < 0)
      paramInt = 0; 
    paramInt = paramInt;
  }
  
  public void MoveSelectionPgDn() {
    int i = this.m_rectDisplayArea.height / this.m_nCellHeight - 1;
    for (byte b = 0; b < i; b++)
      MoveSelectionDown(false); 
    InternalSelectionHasChanged();
    repaint();
  }
  
  public TreeView() { this(null, null); }
  
  public TreeView(ImageSet paramImageSet) { this(paramImageSet, null); }
  
  public TreeView(TreeViewNode paramTreeViewNode) { this(null, paramTreeViewNode); }
  
  public TreeView(ImageSet paramImageSet, TreeViewNode paramTreeViewNode) {
    try {
      if (System.getProperty("java.vendor").startsWith("Netscape"))
        if (System.getProperty("java.version").startsWith("1.0") && System.getProperty("os.name").startsWith("Windows") && System.getProperty("os.version").startsWith("4")) {
          this.m_bIsNS3Win32 = true;
        } else if (System.getProperty("os.name").startsWith("16-bit Windows")) {
          this.c_lnDoubleClickWindow = 1500L;
          this.m_bIsNSWin16 = true;
        }  
    } finally {}
    this.m_tvnRoot = paramTreeViewNode;
    this.m_isImages = paramImageSet;
    this.m_isConnectors = new TreeViewConnectorImageSet();
    this.m_imgDoubleBuffer = null;
    this.m_rectDisplayArea = new Rectangle();
    setLayout(null);
    try {
      String str = System.getProperty("os.name");
      if (!str.startsWith("Windows")) {
        this.m_bIsMac = str.startsWith("Mac");
        this.m_bIsUnix = !this.m_bIsMac;
      } 
    } finally {}
    int i = WebHelp.GetFontSize();
    setFont(new Font(WebHelp.GetFontName(), 0, i));
    FontMetrics fontMetrics = getFontMetrics(getFont());
    int j = fontMetrics.getLeading() + fontMetrics.getAscent() + fontMetrics.getDescent();
    setCellHeight(j);
    if (j < this.m_nCellHeight) {
      this.m_nFontBaseOffset = (this.m_nCellHeight + j) / 2 - fontMetrics.getDescent();
    } else {
      this.m_nFontBaseOffset = this.m_nCellHeight - fontMetrics.getDescent();
    } 
    setSelectionToTop();
    Scrollbar scrollbar = new Scrollbar();
    scrollbar.setValues(0, 3, 0, 10);
    scrollbar.setValue(10);
    this.m_bNetscapeScrollers = !(scrollbar.getValue() != 10);
    this.m_sbHorizontal.setLineIncrement(16);
    if (this.m_sbHorizontal.getPageIncrement() < 128)
      this.m_sbHorizontal.setPageIncrement(128); 
    this.m_sbHorizontal.setBackground(new Color(192, 192, 192));
    add(this.m_sbHorizontal);
    this.m_sbVertical.setBackground(new Color(192, 192, 192));
    add(this.m_sbVertical);
    this.m_btnScrollerCorner.enable(false);
    add(this.m_btnScrollerCorner);
  }
  
  public void EnsureDisplayed(TreeViewNode paramTreeViewNode) {
    int i = this.m_rectDisplayArea.height / this.m_nCellHeight;
    if (IsDisplayed(paramTreeViewNode) == true)
      return; 
    int j = GetNodePosition(paramTreeViewNode);
    if (j < this.m_sbVertical.getValue()) {
      this.m_sbVertical.setValue(j);
    } else {
      this.m_sbVertical.setValue(j - i + 1);
    } 
    this.m_nVerticalPosPixels = this.m_sbVertical.getValue() * this.m_nCellHeight;
  }
  
  public int GetOpenChildSiblingCount(TreeViewNode paramTreeViewNode) {
    int i = 0;
    if (paramTreeViewNode == null)
      return 0; 
    if (paramTreeViewNode.getLabel() != null)
      i++; 
    if (!paramTreeViewNode.getCollapsedState()) {
      TreeViewNode treeViewNode1 = (TreeViewNode)paramTreeViewNode.getChild();
      if (treeViewNode1 != null)
        i += GetOpenChildSiblingCount(treeViewNode1); 
    } 
    TreeViewNode treeViewNode = (TreeViewNode)paramTreeViewNode.getSibling();
    if (treeViewNode != null)
      i += GetOpenChildSiblingCount(treeViewNode); 
    return i;
  }
  
  public void paint(Graphics paramGraphics) {
    if (!this.m_bLayoutComplete)
      layout(); 
    if (this.m_bUseDoubleBuffer && this.m_imgDoubleBuffer == null)
      return; 
    if (this.m_bIsNS3Win32)
      paramGraphics.dispose(); 
    Graphics graphics = null;
    if (this.m_bUseDoubleBuffer) {
      graphics = this.m_imgDoubleBuffer.getGraphics();
    } else {
      graphics = getGraphics();
    } 
    graphics.setFont(getFont());
    graphics.setColor(getBackground());
    graphics.fillRect(0, 0, (bounds()).width, (bounds()).height);
    graphics.setColor(getForeground());
    graphics.translate(-this.m_nHorizPosPixels, -this.m_nVerticalPosPixels);
    try {
      Rectangle rectangle = new Rectangle(this.m_rectDisplayArea.x, this.m_rectDisplayArea.y, this.m_rectDisplayArea.width, this.m_rectDisplayArea.height);
      rectangle.y += this.m_nVerticalPosPixels;
      paintTree(graphics, this.m_tvnRoot, this.m_nInsetX, this.m_nInsetY, rectangle);
    } catch (NullPointerException nullPointerException) {}
    if (this.m_bUseDoubleBuffer) {
      graphics.dispose();
      graphics = this.m_imgDoubleBuffer.getGraphics();
    } else {
      graphics.translate(this.m_nHorizPosPixels, this.m_nVerticalPosPixels);
    } 
    paintBorder(graphics);
    if (this.m_bUseDoubleBuffer) {
      if (this.m_bIsNS3Win32) {
        graphics.dispose();
        paramGraphics = getGraphics();
      } 
      paramGraphics.drawImage(this.m_imgDoubleBuffer, 0, 0, this);
    } 
  }
  
  protected void paintNode(Graphics paramGraphics, TreeViewNode paramTreeViewNode, int paramInt1, int paramInt2) {
    paramTreeViewNode.moveBounds(paramInt1, paramInt2);
    paramInt1 = drawConnector(paramGraphics, paramTreeViewNode, paramInt1, paramInt2);
    if (paramTreeViewNode.getCurrentImage() != null) {
      paramGraphics.drawImage(paramTreeViewNode.getCurrentImage(), paramInt1, paramInt2 + 1, this.m_nIconWidth, this.m_nIconHeight, this);
      paramInt1 += this.m_nIconWidth + this.m_nLabelOffset;
    } 
    if (paramTreeViewNode.getLabel() != null)
      drawText(paramGraphics, paramTreeViewNode, paramInt1, paramInt2); 
  }
  
  public void MoveSelectionEnd() {
    this.m_tvnCurrentSelection.select(false);
    while (this.m_tvnCurrentSelection.nextNode(true) != null)
      this.m_tvnCurrentSelection = this.m_tvnCurrentSelection.nextNode(true); 
    this.m_tvnCurrentSelection.select(true);
    this.m_sbVertical.setValue(this.m_sbVertical.getMaximum());
    this.m_nVerticalPosPixels = this.m_sbVertical.getValue() * this.m_nCellHeight;
    InternalSelectionHasChanged();
    repaint();
  }
  
  public void MoveSelectionPgUp() {
    int i = this.m_rectDisplayArea.height / this.m_nCellHeight - 1;
    for (byte b = 0; b < i; b++)
      MoveSelectionUp(false); 
    InternalSelectionHasChanged();
    repaint();
  }
  
  TreeViewNode GetFirstDisplayedNode() {
    TreeViewNode treeViewNode = this.m_tvnRoot;
    int i = this.m_sbVertical.getValue();
    while (treeViewNode != null && i > 0) {
      if (treeViewNode.getLabel() != null)
        i--; 
      treeViewNode = treeViewNode.nextNode(true);
    } 
    return treeViewNode;
  }
  
  public boolean getUseButtons() { return this.m_bUseButtons; }
  
  public void setUseButtons(boolean paramBoolean) { this.m_bUseButtons = paramBoolean; }
  
  public ImageSet getImages() { return this.m_isImages; }
  
  public void setImages(ImageSet paramImageSet) { this.m_isImages = paramImageSet; }
  
  protected void drawText(Graphics paramGraphics, TreeViewNode paramTreeViewNode, int paramInt1, int paramInt2) {
    paramInt2 += this.m_nFontBaseOffset;
    if (paramTreeViewNode.isSelected()) {
      paramGraphics.setColor(new Color(0, 0, 128));
      Rectangle rectangle = paramTreeViewNode.getBounds();
      int i = rectangle.width + rectangle.x - paramInt1;
      paramGraphics.fillRect(paramInt1, rectangle.y, i, rectangle.height);
      paramGraphics.setColor(Color.white);
    } else {
      paramGraphics.setColor(getForeground());
    } 
    paramGraphics.setFont(getFont());
    paramGraphics.drawString(paramTreeViewNode.getLabel(), paramInt1, paramInt2);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\Help\webhelp.zip!\treeview\TreeView.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */