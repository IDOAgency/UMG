package treeview;

import java.awt.Image;
import java.awt.Rectangle;

public class TreeViewNode extends SiblingChildTree {
  protected ImageSet m_isImages = null;
  
  protected ImageSetSource m_issrcSource = null;
  
  protected String m_strLabel = null;
  
  protected Rectangle m_rectBounds = new Rectangle();
  
  protected boolean m_bCollapsed = false;
  
  protected boolean m_bSelected = false;
  
  protected boolean m_bUseSpecificImgIndex = false;
  
  protected int m_nImageIndex = -1;
  
  public void doDblClick() {}
  
  public void moveBounds(int paramInt1, int paramInt2) {
    this.m_rectBounds.x = paramInt1;
    this.m_rectBounds.y = paramInt2;
  }
  
  public boolean getCollapsedState() { return this.m_bCollapsed; }
  
  public void setCollapsedState(boolean paramBoolean) { this.m_bCollapsed = paramBoolean; }
  
  public TreeViewNode nextNode(boolean paramBoolean) {
    if ((!paramBoolean || !this.m_bCollapsed) && this.child != null)
      return (TreeViewNode)this.child; 
    if (this.sibling_right != null)
      return (TreeViewNode)this.sibling_right; 
    for (SiblingChildTree siblingChildTree = this.parent; siblingChildTree != null; siblingChildTree = siblingChildTree.parent) {
      if (siblingChildTree.sibling_right != null)
        return (TreeViewNode)siblingChildTree.sibling_right; 
    } 
    return null;
  }
  
  public void select(boolean paramBoolean) { this.m_bSelected = paramBoolean; }
  
  public void collapseTree() {
    for (TreeViewNode treeViewNode = this; treeViewNode != null; treeViewNode = (TreeViewNode)treeViewNode.sibling_right) {
      treeViewNode.m_bCollapsed = true;
      try {
        ((TreeViewNode)treeViewNode.child).collapseTree();
      } catch (NullPointerException nullPointerException) {}
    } 
  }
  
  public Rectangle getBounds() { return new Rectangle(this.m_rectBounds.x, this.m_rectBounds.y, this.m_rectBounds.width, this.m_rectBounds.height); }
  
  public void setBounds(int paramInt1, int paramInt2, int paramInt3, int paramInt4) { this.m_rectBounds.reshape(paramInt1, paramInt2, paramInt3, paramInt4); }
  
  public void setBounds(Rectangle paramRectangle) { this.m_rectBounds.reshape(paramRectangle.x, paramRectangle.y, paramRectangle.width, paramRectangle.height); }
  
  public int getWidth() { return this.m_rectBounds.width; }
  
  public int getImageIndex() { return this.m_nImageIndex; }
  
  public void setImageIndex(int paramInt) { this.m_nImageIndex = paramInt; }
  
  public void setImageSetSource(ImageSetSource paramImageSetSource) { this.m_issrcSource = paramImageSetSource; }
  
  public ImageSetSource getImageSetSource() { return this.m_issrcSource; }
  
  public void expandTree() {
    for (TreeViewNode treeViewNode = this; treeViewNode != null; treeViewNode = (TreeViewNode)treeViewNode.sibling_right) {
      treeViewNode.m_bCollapsed = false;
      try {
        ((TreeViewNode)treeViewNode.child).expandTree();
      } catch (NullPointerException nullPointerException) {}
    } 
  }
  
  public TreeViewNode() {}
  
  public TreeViewNode(String paramString) {}
  
  public TreeViewNode(ImageSet paramImageSet) {}
  
  public TreeViewNode(ImageSetSource paramImageSetSource) {}
  
  public TreeViewNode(String paramString, ImageSetSource paramImageSetSource) {}
  
  public TreeViewNode(String paramString, ImageSet paramImageSet) {}
  
  public boolean isSelected() { return this.m_bSelected; }
  
  public TreeViewNode prevNode(boolean paramBoolean) {
    if (this.sibling_left != null) {
      if (!paramBoolean || !((TreeViewNode)this.sibling_left).m_bCollapsed) {
        SiblingChildTree siblingChildTree = this.sibling_left.child;
        if (siblingChildTree == null)
          return (TreeViewNode)lastBeforeMatch((TreeViewNode)this.sibling_left, paramBoolean); 
        while (siblingChildTree.sibling_right != null)
          siblingChildTree = siblingChildTree.sibling_right; 
        return (TreeViewNode)lastBeforeMatch((TreeViewNode)siblingChildTree, paramBoolean);
      } 
      return (TreeViewNode)lastBeforeMatch((TreeViewNode)this.sibling_left, paramBoolean);
    } 
    return (this.parent != null) ? (TreeViewNode)lastBeforeMatch((TreeViewNode)this.parent, paramBoolean) : null;
  }
  
  private SiblingChildTree lastBeforeMatch(TreeViewNode paramTreeViewNode, boolean paramBoolean) {
    TreeViewNode treeViewNode = null;
    do {
      if (treeViewNode != null)
        paramTreeViewNode = treeViewNode; 
      treeViewNode = paramTreeViewNode.nextNode(paramBoolean);
    } while (treeViewNode != this);
    return paramTreeViewNode;
  }
  
  public Image getCurrentImage() {
    ImageSet imageSet = this.m_isImages;
    if (imageSet == null) {
      if (this.m_issrcSource != null)
        imageSet = this.m_issrcSource.getImages(); 
      if (imageSet == null)
        return null; 
    } 
    try {
      if (this.m_bUseSpecificImgIndex)
        try {
          return imageSet.getImage(this.m_nImageIndex);
        } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
          return null;
        }  
      if (this.child == null) {
        if (this.m_bSelected)
          try {
            return imageSet.getImage(3);
          } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
            return imageSet.getImage(0);
          }  
        return imageSet.getImage(0);
      } 
      if (this.m_bSelected)
        try {
          return this.m_bCollapsed ? imageSet.getImage(4) : imageSet.getImage(5);
        } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
          return this.m_bCollapsed ? imageSet.getImage(1) : imageSet.getImage(2);
        }  
      return this.m_bCollapsed ? imageSet.getImage(1) : imageSet.getImage(2);
    } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
      return null;
    } 
  }
  
  public boolean getUseSpecifiedImageIndex() { return this.m_bUseSpecificImgIndex; }
  
  public void setUseSpecifiedImageIndex(boolean paramBoolean) { this.m_bUseSpecificImgIndex = paramBoolean; }
  
  public int getHeight() { return this.m_rectBounds.height; }
  
  public ImageSet getImages() { return this.m_isImages; }
  
  public void setImages(ImageSet paramImageSet) { this.m_isImages = paramImageSet; }
  
  public boolean isInside(int paramInt1, int paramInt2) { return this.m_rectBounds.inside(paramInt1, paramInt2); }
  
  public String getLabel() { return this.m_strLabel; }
  
  public void setLabel(String paramString) { this.m_strLabel = paramString; }
  
  public void doAction() {}
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\Help\webhelp.zip!\treeview\TreeViewNode.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */