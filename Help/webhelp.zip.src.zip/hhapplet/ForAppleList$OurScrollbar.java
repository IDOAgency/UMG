package hhapplet;

import java.awt.Event;
import java.awt.Scrollbar;

class OurScrollbar extends Scrollbar {
  final ForAppleList this$0;
  
  public OurScrollbar(ForAppleList paramForAppleList, int paramInt) {
    super(paramInt);
    (this.this$0 = paramForAppleList).getClass();
  }
  
  public boolean mouseUp(Event paramEvent, int paramInt1, int paramInt2) {
    this.this$0.UpdateList();
    return super.mouseUp(paramEvent, paramInt1, paramInt2);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\Help\webhelp.zip!\hhapplet\ForAppleList$OurScrollbar.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */