package hhapplet;

import java.applet.Applet;
import java.util.Vector;
import sitemap.SiteMapParserOutput;

public class SiteMapParserToIndex implements SiteMapParserOutput {
  protected Applet m_applet;
  
  protected IndexPane m_ipIndex;
  
  protected int indent = 0;
  
  protected int real_indent = 0;
  
  protected boolean done_a_node = false;
  
  protected int param_no = -1;
  
  protected String m_strName;
  
  protected Vector secondary_entries;
  
  protected boolean m_bInGlobal = true;
  
  protected char m_chCurrentStart = ' ';
  
  protected int m_nItemsFound = 0;
  
  protected String default_frame_name;
  
  public void end() {
    this.m_ipIndex.getEditBox().enable(true);
    this.m_ipIndex.ShowList();
    this.m_ipIndex.getEditBox().requestFocus();
    this.m_applet.showStatus("Done");
  }
  
  public SiteMapParserToIndex(Applet paramApplet) {
    this.m_applet = paramApplet;
    this.m_ipIndex = new IndexPane(this.m_applet);
  }
  
  public void object_start() {
    this.done_a_node = true;
    this.m_bInGlobal = false;
    this.param_no = -1;
    this.secondary_entries = new Vector();
  }
  
  public void indent(int paramInt) {
    if (paramInt == 1) {
      this.real_indent++;
      if (this.done_a_node)
        this.indent++; 
    } else if (paramInt == -1) {
      this.indent = --this.real_indent;
    } 
    this.done_a_node = false;
  }
  
  private String indent_string() {
    String str = "";
    for (byte b = 0; b < this.indent; b++)
      str = str + "  "; 
    return str;
  }
  
  public IndexPane getIndex() { return this.m_ipIndex; }
  
  public void start() {
    this.m_ipIndex.getEditBox().enable(false);
    this.m_ipIndex.HideList();
  }
  
  public void object_end() {
    if ((getLatestEntry()).local != null && (getLatestEntry()).local.length() > 0)
      this.m_ipIndex.add(indent_string() + this.m_strName, this.secondary_entries); 
    if (this.m_strName == null || this.m_strName.length() == 0)
      return; 
    char c = Character.toUpperCase(this.m_strName.charAt(0));
    if (this.indent == 0 && c != this.m_chCurrentStart) {
      this.m_chCurrentStart = c;
      String str = "Loading Index [";
      str = str + c;
      str = str + "]...";
      this.m_applet.showStatus(str);
    } 
    this.m_nItemsFound++;
    if (this.m_nItemsFound % 50 == 0)
      this.m_ipIndex.paintAll(this.m_ipIndex.getGraphics()); 
  }
  
  public IndexSecondaryEntry getLatestEntry() {
    byte b = (this.param_no == 0) ? 0 : (this.param_no - 1);
    if (this.secondary_entries.size() < b + true) {
      this.secondary_entries.setSize(b + true);
      this.secondary_entries.setElementAt(new IndexSecondaryEntry(), b);
    } 
    return (IndexSecondaryEntry)this.secondary_entries.elementAt(b);
  }
  
  public void param(String paramString1, String paramString2) {
    char c = Character.toUpperCase(paramString1.charAt(0));
    if (this.m_bInGlobal) {
      if (c == 'F' && paramString1.equalsIgnoreCase("FrameName")) {
        this.default_frame_name = paramString2;
        return;
      } 
    } else {
      switch (c) {
        case 'N':
          if (paramString1.equalsIgnoreCase("Name")) {
            this.param_no++;
            paramString2 = fixSpecialCharacters(paramString2);
            (getLatestEntry()).name = paramString2;
            if ((getLatestEntry()).frame == null)
              (getLatestEntry()).frame = this.default_frame_name; 
            if (this.param_no == 0) {
              this.m_strName = paramString2;
              return;
            } 
          } 
          break;
        case 'L':
          if (paramString1.equalsIgnoreCase("Local")) {
            (getLatestEntry()).local = paramString2;
            return;
          } 
          break;
        case 'U':
          if (paramString1.equalsIgnoreCase("URL")) {
            (getLatestEntry()).url = paramString2;
            return;
          } 
          break;
        case 'F':
          if (paramString1.equalsIgnoreCase("Frame")) {
            (getLatestEntry()).frame = paramString2;
            return;
          } 
          break;
        case 'S':
          if (paramString1.equalsIgnoreCase("See Also")) {
            (getLatestEntry()).see_also = paramString2;
            return;
          } 
          break;
      } 
    } 
  }
  
  public String fixSpecialCharacters(String paramString) {
    if (paramString == null)
      return null; 
    int i = paramString.indexOf('&');
    if (i < 0)
      return paramString; 
    String str = "";
    while (i > -1 && i < paramString.length() - 2) {
      str = str + paramString.substring(0, i);
      String str1 = paramString.substring(i);
      int j = str1.indexOf(';');
      if (j < 0) {
        str = str + str1;
        break;
      } 
      if (j < str1.length() - 1) {
        paramString = str1.substring(j + 1);
      } else {
        paramString = "";
      } 
      str1 = str1.substring(1, j);
      switch (Character.toUpperCase(str1.charAt(0))) {
        case 'A':
          if (str1.equalsIgnoreCase("amp"))
            str1 = "&"; 
          break;
        case 'C':
          if (str1.equalsIgnoreCase("copy"))
            str1 = "(c)"; 
          break;
        case 'G':
          if (str1.equalsIgnoreCase("gt"))
            str1 = ">"; 
          break;
        case 'L':
          if (str1.equalsIgnoreCase("lt"))
            str1 = "<"; 
          break;
        case 'N':
          if (str1.equalsIgnoreCase("nbsp"))
            str1 = " "; 
          break;
        case 'Q':
          if (str1.equalsIgnoreCase("quot"))
            str1 = "\""; 
          break;
        case 'R':
          if (str1.equalsIgnoreCase("reg"))
            str1 = "(R)"; 
          break;
      } 
      str = str + str1;
      i = paramString.indexOf('&');
      if (i < 0)
        str = str + paramString; 
    } 
    return str;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\Help\webhelp.zip!\hhapplet\SiteMapParserToIndex.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */