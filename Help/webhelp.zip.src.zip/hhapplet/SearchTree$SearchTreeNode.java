package hhapplet;

import treeview.TreeViewNode;

class SearchTreeNode extends TreeViewNode {
  final SearchTree this$0;
  
  public void doDblClick() { this.this$0.m_sp.gotoSelectedIndex(); }
  
  SearchTreeNode(SearchTree paramSearchTree) { (this.this$0 = paramSearchTree).getClass(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\Help\webhelp.zip!\hhapplet\SearchTree$SearchTreeNode.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */