package hhapplet;

import java.awt.BorderLayout;
import java.awt.LayoutManager;
import java.awt.Panel;

class FTSNorthPanel extends Panel {
  private LayoutManager m_layout;
  
  final FTSPane this$0;
  
  FTSNorthPanel(FTSPane paramFTSPane) {
    (this.this$0 = paramFTSPane).getClass();
    this.m_layout = new BorderLayout(2, 2);
    setLayout(this.m_layout);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\Help\webhelp.zip!\hhapplet\FTSPane$FTSNorthPanel.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */