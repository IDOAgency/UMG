package hhapplet;

import treeview.TreeViewNode;

class IndexTreeNode extends TreeViewNode {
  final IndexTree this$0;
  
  public void doDblClick() { this.this$0.m_ip.gotoSelectedIndex(); }
  
  IndexTreeNode(IndexTree paramIndexTree) { (this.this$0 = paramIndexTree).getClass(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\Help\webhelp.zip!\hhapplet\IndexTree$IndexTreeNode.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */