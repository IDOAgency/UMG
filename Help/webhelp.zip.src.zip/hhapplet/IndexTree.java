package hhapplet;

import java.awt.Color;
import treeview.TreeView;
import treeview.TreeViewNode;

public class IndexTree extends TreeView {
  IndexPane m_ip;
  
  private IndexTreeNode m_root = new IndexTreeNode(this);
  
  int m_nVisibleIndex = -1;
  
  int m_nCountCache = -1;
  
  public String getItem(int paramInt) {
    IndexTreeNode indexTreeNode = (IndexTreeNode)this.m_root.getChild();
    for (byte b = 0; b < paramInt; b++)
      indexTreeNode = (IndexTreeNode)indexTreeNode.getSibling(); 
    return indexTreeNode.getLabel();
  }
  
  public IndexTree(IndexPane paramIndexPane) {
    this.m_ip = paramIndexPane;
    setRoot(this.m_root);
    setBackground(new Color(255, 255, 255));
  }
  
  public int getVisibleIndex() { return this.m_nVisibleIndex; }
  
  public int countItems() {
    if (this.m_nCountCache == -1) {
      IndexTreeNode indexTreeNode = (IndexTreeNode)this.m_root.getChild();
      this.m_nCountCache = 0;
      while (indexTreeNode != null) {
        this.m_nCountCache++;
        indexTreeNode = (IndexTreeNode)indexTreeNode.getSibling();
      } 
    } 
    return this.m_nCountCache;
  }
  
  public String getSelectedItem() {
    for (IndexTreeNode indexTreeNode = (IndexTreeNode)this.m_root.getChild(); indexTreeNode != null; indexTreeNode = (IndexTreeNode)indexTreeNode.getSibling()) {
      if (indexTreeNode.isSelected() == true)
        return indexTreeNode.getLabel(); 
    } 
    return "";
  }
  
  public void select(int paramInt) {
    IndexTreeNode indexTreeNode = (IndexTreeNode)this.m_root.getChild();
    for (byte b = 0; indexTreeNode != null; b++) {
      if (b == paramInt) {
        indexTreeNode.select(true);
        this.m_tvnCurrentSelection = indexTreeNode;
      } else {
        indexTreeNode.select(false);
      } 
      indexTreeNode = (IndexTreeNode)indexTreeNode.getSibling();
    } 
    paintAll(getGraphics());
  }
  
  protected void InternalSelectionHasChanged() { this.m_ip.getEditBox().setText(getSelectedItem()); }
  
  public void addItem(String paramString) {
    IndexTreeNode indexTreeNode = new IndexTreeNode(this);
    indexTreeNode.setLabel(paramString);
    this.m_root.addChild(indexTreeNode);
    this.m_nCountCache = -1;
    repaint();
  }
  
  public void makeVisible(int paramInt) {
    this.m_nVisibleIndex = paramInt;
    IndexTreeNode indexTreeNode = (IndexTreeNode)this.m_root.getChild();
    for (byte b = 0; b <= paramInt; b++)
      indexTreeNode = (IndexTreeNode)indexTreeNode.getSibling(); 
    EnsureDisplayed(indexTreeNode);
    paintAll(getGraphics());
  }
  
  public int getSelectedIndex() {
    IndexTreeNode indexTreeNode = (IndexTreeNode)this.m_root.getChild();
    for (byte b = 0; indexTreeNode != null; b++) {
      if (indexTreeNode.isSelected() == true)
        return b; 
      indexTreeNode = (IndexTreeNode)indexTreeNode.getSibling();
    } 
    return -1;
  }
  
  public void clear() {
    this.m_root = new IndexTreeNode(this);
    setRoot(this.m_root);
    this.m_nCountCache = -1;
    paintAll(getGraphics());
  }
  
  class IndexTreeNode extends TreeViewNode {
    final IndexTree this$0;
    
    public void doDblClick() { this.this$0.m_ip.gotoSelectedIndex(); }
    
    IndexTreeNode(IndexTree this$0) { (this.this$0 = this$0).getClass(); }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\Help\webhelp.zip!\hhapplet\IndexTree.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */