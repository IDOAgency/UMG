package hhapplet;

import WebHelp;
import java.applet.Applet;
import java.awt.Image;
import java.net.MalformedURLException;
import treeview.ImageSet;
import treeview.TreeViewNode;

public class ContentsTree extends TreeViewNode {
  public String local;
  
  public String url;
  
  public String frame_name;
  
  private Applet a;
  
  private Image[] images;
  
  private boolean use_folder_images;
  
  private boolean new_topic;
  
  public ContentsTree(Applet paramApplet, Image[] paramArrayOfImage, String paramString1, String paramString2, String paramString3, String paramString4, boolean paramBoolean1, boolean paramBoolean2) {
    super(paramString1, new ImageSet(paramArrayOfImage));
    this.a = paramApplet;
    this.images = paramArrayOfImage;
    this.local = paramString2;
    this.url = paramString3;
    this.frame_name = paramString4;
    this.use_folder_images = paramBoolean1;
    this.new_topic = paramBoolean2;
    setCollapsedState(true);
  }
  
  public Image getCurrentImage() { return getImages().getImage(imageIndex()); }
  
  private int imageIndex() { return (numberOfChildren() == 0) ? ((this.local != null && (this.local.toUpperCase().startsWith("HTTP") || this.local.toUpperCase().startsWith("FTP") || this.local.toUpperCase().startsWith("MAILTO") || this.local.toUpperCase().startsWith("NEWS")) && !this.use_folder_images) ? (14 + (this.new_topic ? 1 : 0)) : (8 + (this.use_folder_images ? 2 : 0) + (this.new_topic ? 1 : 0))) : ((!getCollapsedState() ? 1 : 0) + (this.new_topic ? 2 : 0) + (this.use_folder_images ? 4 : 0)); }
  
  public void doAction() {
    if (this.local == null && this.url == null)
      return; 
    if (this.local.charAt(0) == 'W' && this.local.startsWith("WebHelp:")) {
      String str = this.local.substring(8);
      ((WebHelp)this.a).Command(str, "");
      return;
    } 
    try {
      if (this.frame_name != null) {
        this.a.getAppletContext().showDocument(URLFileHandler.makeURL(this.a.getDocumentBase(), this.local, this.url), this.frame_name);
        return;
      } 
      this.a.getAppletContext().showDocument(URLFileHandler.makeURL(this.a.getDocumentBase(), this.local, this.url), "_self");
      return;
    } catch (MalformedURLException malformedURLException) {
      return;
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\Help\webhelp.zip!\hhapplet\ContentsTree.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */