package hhapplet;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Event;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;
import java.util.Vector;

public class CanvasButton extends Canvas {
  protected Rectangle inside;
  
  protected Image img = null;
  
  protected Vector listeners = new Vector();
  
  protected boolean button_push_state = false;
  
  public CanvasButton(Image paramImage) {
    this();
    this.img = paramImage;
  }
  
  public CanvasButton() {
    this.button_push_state = false;
    setBackground(new Color(192, 192, 192));
  }
  
  public void paint(Graphics paramGraphics) {
    paramGraphics.setColor(getBackground());
    paramGraphics.fillRect(0, 0, (bounds()).width, (bounds()).height);
    if (this.img != null)
      paramGraphics.drawImage(this.img, 2, 2, null); 
    if (this.button_push_state) {
      paintBorderIn(paramGraphics);
      return;
    } 
    paintBorderOut(paramGraphics);
  }
  
  public void paintBorderOut(Graphics paramGraphics) {
    Rectangle rectangle = bounds();
    Color color1 = getBackground().brighter();
    Color color2 = color1.darker();
    Color color3 = color2.darker();
    Color color4 = color3.darker();
    paramGraphics.setColor(color1);
    paramGraphics.drawLine(0, 0, rectangle.width - 1, 0);
    paramGraphics.drawLine(0, 0, 0, rectangle.height - 1);
    paramGraphics.setColor(color2);
    paramGraphics.drawLine(1, 1, rectangle.width - 2, 1);
    paramGraphics.drawLine(1, 1, 1, rectangle.height - 2);
    paramGraphics.setColor(color4);
    paramGraphics.drawLine(rectangle.width - 2, 1, rectangle.width - 2, rectangle.height - 2);
    paramGraphics.drawLine(1, rectangle.height - 2, rectangle.width - 2, rectangle.height - 2);
    paramGraphics.setColor(color3);
    paramGraphics.drawLine(rectangle.width - 1, 1, rectangle.width - 1, rectangle.height - 1);
    paramGraphics.drawLine(0, rectangle.height - 1, rectangle.width - 1, rectangle.height - 1);
  }
  
  public void update(Graphics paramGraphics) { paint(paramGraphics); }
  
  public void paintBorderIn(Graphics paramGraphics) {
    Rectangle rectangle = bounds();
    Color color1 = getBackground().brighter();
    Color color2 = color1.darker();
    Color color3 = color2.darker();
    Color color4 = color3.darker();
    paramGraphics.setColor(color4);
    paramGraphics.drawLine(0, 0, rectangle.width - 1, 0);
    paramGraphics.drawLine(0, 0, 0, rectangle.height - 1);
    paramGraphics.setColor(color3);
    paramGraphics.drawLine(1, 1, rectangle.width - 2, 1);
    paramGraphics.drawLine(1, 1, 1, rectangle.height - 2);
    paramGraphics.setColor(color2);
    paramGraphics.drawLine(rectangle.width - 2, 1, rectangle.width - 2, rectangle.height - 2);
    paramGraphics.drawLine(1, rectangle.height - 2, rectangle.width - 2, rectangle.height - 2);
    paramGraphics.setColor(color1);
    paramGraphics.drawLine(rectangle.width - 1, 1, rectangle.width - 1, rectangle.height - 1);
    paramGraphics.drawLine(0, rectangle.height - 1, rectangle.width - 1, rectangle.height - 1);
  }
  
  public void removeButtonPushEventListener(ButtonPushEventListener paramButtonPushEventListener) { this.listeners.removeElement(paramButtonPushEventListener); }
  
  public Dimension preferredSize() { return (this.img != null) ? new Dimension(this.img.getWidth(this) + 4, this.img.getHeight(this) + 4) : new Dimension(20, 20); }
  
  public void addButtonPushEventListener(ButtonPushEventListener paramButtonPushEventListener) { this.listeners.addElement(paramButtonPushEventListener); }
  
  public boolean handleEvent(Event paramEvent) {
    if (paramEvent.id == 501) {
      this.button_push_state = true;
      repaint();
      return true;
    } 
    if (paramEvent.id == 502 && this.button_push_state) {
      this.button_push_state = false;
      repaint();
      Rectangle rectangle = bounds();
      rectangle.x = 0;
      rectangle.y = 0;
      if (rectangle.inside(paramEvent.x, paramEvent.y))
        doAction(paramEvent); 
      return true;
    } 
    if (paramEvent.id == 506) {
      Rectangle rectangle = bounds();
      rectangle.x = 0;
      rectangle.y = 0;
      if (!rectangle.inside(paramEvent.x, paramEvent.y)) {
        if (this.button_push_state) {
          this.button_push_state = false;
          repaint();
        } 
      } else if (!this.button_push_state) {
        this.button_push_state = true;
        repaint();
      } 
      return true;
    } 
    return false;
  }
  
  protected void doAction(Event paramEvent) {
    Vector vector;
    ButtonPushEvent buttonPushEvent = new ButtonPushEvent(this, paramEvent.x, paramEvent.y);
    synchronized (this) {
      vector = (Vector)this.listeners.clone();
    } 
    for (byte b = 0; b < vector.size(); b++) {
      ButtonPushEventListener buttonPushEventListener = (ButtonPushEventListener)this.listeners.elementAt(b);
      buttonPushEventListener.notifyButtonPushEvent(buttonPushEvent);
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\Help\webhelp.zip!\hhapplet\CanvasButton.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */