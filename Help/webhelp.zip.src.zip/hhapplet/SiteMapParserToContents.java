package hhapplet;

import java.applet.Applet;
import java.awt.Color;
import java.awt.Image;
import java.util.Vector;
import sitemap.SiteMapParserOutput;
import treeview.ImageSet;
import treeview.TreeView;
import treeview.TreeViewNode;

public class SiteMapParserToContents implements SiteMapParserOutput {
  protected TreeViewNode root_tree = new TreeViewNode();
  
  protected int ind = 0;
  
  protected int real_ind = 0;
  
  protected Vector parent_list = new Vector();
  
  protected boolean done_a_node = false;
  
  protected boolean in_global = true;
  
  protected Image[] images;
  
  protected Applet a;
  
  protected TreeView m_tvTheTree = null;
  
  protected String default_frame_name;
  
  protected boolean use_folder_images = false;
  
  protected String name;
  
  protected String local;
  
  protected String url;
  
  protected String frame_name;
  
  protected boolean new_topic;
  
  private int m_nItems = 0;
  
  public void end() {
    getTree();
    this.m_tvTheTree.setFilled(true);
    RemoveEmptyBooks(this.m_tvTheTree.getRoot());
    this.a.showStatus("Completing Contents...");
    this.m_tvTheTree.layout();
    this.a.showStatus("Done");
    if (this.m_tvTheTree.isVisible()) {
      this.m_tvTheTree.requestFocus();
      this.m_tvTheTree.repaint();
    } 
    this.m_tvTheTree.setSelectionToTop();
    this.m_tvTheTree.repaint();
  }
  
  public SiteMapParserToContents(Applet paramApplet, Image[] paramArrayOfImage) {
    this.a = paramApplet;
    this.images = paramArrayOfImage;
    this.parent_list.setSize(1);
    this.parent_list.setElementAt(this.root_tree, 0);
  }
  
  public void object_start() { this.in_global = false; }
  
  public void indent(int paramInt) {
    if (paramInt == 1) {
      this.real_ind++;
      if (this.done_a_node)
        this.ind++; 
    } else if (paramInt == -1) {
      this.ind = --this.real_ind;
    } 
    this.done_a_node = false;
  }
  
  public TreeView getTree() {
    if (this.m_tvTheTree == null)
      this.m_tvTheTree = new TreeView(new ImageSet(this.images), this.root_tree); 
    this.m_tvTheTree.setApplet(this.a);
    this.m_tvTheTree.setBackground(Color.white);
    return this.m_tvTheTree;
  }
  
  public void RemoveEmptyBooks(TreeViewNode paramTreeViewNode) {
    if (paramTreeViewNode == null)
      return; 
    if (paramTreeViewNode.getChild() != null);
    RemoveEmptyBooks((TreeViewNode)paramTreeViewNode.getChild());
    if (paramTreeViewNode.getSibling() != null);
    RemoveEmptyBooks((TreeViewNode)paramTreeViewNode.getSibling());
    if (paramTreeViewNode instanceof ContentsTree && ((ContentsTree)paramTreeViewNode).local == null && paramTreeViewNode.getChild() == null)
      paramTreeViewNode.pruneThisSubtree(); 
  }
  
  public void start() {
    if (this.m_tvTheTree != null) {
      this.m_tvTheTree.setFilled(false);
      this.m_tvTheTree.requestFocus();
    } 
    if (this.m_tvTheTree == null)
      this.m_tvTheTree = new TreeView(new ImageSet(this.images), this.root_tree); 
  }
  
  public void object_end() {
    if (this.ind < 1 && this.m_tvTheTree.isVisible())
      this.m_tvTheTree.repaint(); 
    ContentsTree contentsTree = new ContentsTree(this.a, this.images, this.name, this.local, this.url, (this.frame_name == null) ? this.default_frame_name : this.frame_name, this.use_folder_images, this.new_topic);
    this.parent_list.setSize(this.ind + 2);
    TreeViewNode treeViewNode = (TreeViewNode)this.parent_list.elementAt(this.ind);
    treeViewNode.addChild(contentsTree);
    this.parent_list.setElementAt(contentsTree, this.ind + 1);
    this.done_a_node = true;
    if (this.m_nItems % 3 == 0 && this.m_nItems % 4 == 0)
      this.a.showStatus("Loading Table of Contents [" + this.m_nItems + "]..."); 
    this.m_nItems++;
    this.name = null;
    this.local = null;
    this.frame_name = null;
    this.new_topic = false;
  }
  
  public void param(String paramString1, String paramString2) {
    if (this.in_global) {
      if (paramString1.equalsIgnoreCase("ImageType")) {
        this.use_folder_images = paramString2.equalsIgnoreCase("Folder");
        return;
      } 
      if (paramString1.equalsIgnoreCase("FrameName")) {
        this.default_frame_name = paramString2;
        return;
      } 
    } else {
      switch (Character.toUpperCase(paramString1.charAt(0))) {
        case 'N':
          if (paramString1.equalsIgnoreCase("Name")) {
            this.name = fixSpecialCharacters(paramString2);
            return;
          } 
          if (paramString1.equalsIgnoreCase("New")) {
            this.new_topic = paramString2.equalsIgnoreCase("1");
            return;
          } 
          break;
        case 'L':
          if (paramString1.equalsIgnoreCase("Local")) {
            this.local = paramString2;
            return;
          } 
          break;
        case 'U':
          if (paramString1.equalsIgnoreCase("URL")) {
            this.url = paramString2;
            return;
          } 
          break;
        case 'F':
          if (paramString1.equalsIgnoreCase("FrameName")) {
            this.frame_name = paramString2;
            return;
          } 
          break;
      } 
    } 
  }
  
  String fixSpecialCharacters(String paramString) {
    if (paramString == null)
      return null; 
    int i = paramString.indexOf('&');
    if (i < 0)
      return paramString; 
    String str = "";
    while (i > -1 && i < paramString.length() - 2) {
      str = str + paramString.substring(0, i);
      String str1 = paramString.substring(i);
      int j = str1.indexOf(';');
      if (j < 0) {
        str = str + str1;
        break;
      } 
      if (j < str1.length() - 1) {
        paramString = str1.substring(j + 1);
      } else {
        paramString = "";
      } 
      str1 = str1.substring(1, j);
      switch (Character.toUpperCase(str1.charAt(0))) {
        case 'A':
          if (str1.equalsIgnoreCase("amp"))
            str1 = "&"; 
          break;
        case 'C':
          if (str1.equalsIgnoreCase("copy"))
            str1 = "(c)"; 
          break;
        case 'G':
          if (str1.equalsIgnoreCase("gt"))
            str1 = ">"; 
          break;
        case 'L':
          if (str1.equalsIgnoreCase("lt"))
            str1 = "<"; 
          break;
        case 'N':
          if (str1.equalsIgnoreCase("nbsp"))
            str1 = " "; 
          break;
        case 'Q':
          if (str1.equalsIgnoreCase("quot"))
            str1 = "\""; 
          break;
        case 'R':
          if (str1.equalsIgnoreCase("reg"))
            str1 = "(R)"; 
          break;
      } 
      str = str + str1;
      i = paramString.indexOf('&');
      if (i < 0)
        str = str + paramString; 
    } 
    return str;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\Help\webhelp.zip!\hhapplet\SiteMapParserToContents.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */