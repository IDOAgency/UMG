package hhapplet;

import java.awt.Button;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Event;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.util.Vector;

public class AboutDialogBox extends Frame {
  private boolean m_bIsIE3 = false;
  
  private Point m_pntPosition;
  
  public AboutDialogBox(String paramString, Vector paramVector) {
    super(paramString);
    if (System.getProperty("java.vendor").startsWith("Microsoft") && System.getProperty("java.version").startsWith("1.0"))
      this.m_bIsIE3 = true; 
    Panel panel = new Panel();
    panel.add(new Button("OK"));
    setBackground(Color.lightGray);
    setLayout(new GridLayout(paramVector.size() + 1, 1, 0, 0));
    for (byte b = 0; b < paramVector.size(); b++) {
      String str = (String)paramVector.elementAt(b);
      add(new Label(str, 1));
    } 
    add(panel);
    pack();
    Rectangle rectangle = bounds();
    if (rectangle.width < 250) {
      rectangle.width = 250;
      resize(rectangle.width, rectangle.height);
    } 
    Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
    int i = dimension.width / 2 - rectangle.width / 2;
    int j = dimension.height / 2 - rectangle.height / 2;
    this.m_pntPosition = new Point(i, j);
    move(i, j);
    setResizable(false);
  }
  
  public void show() {
    if (this.m_bIsIE3) {
      Dimension dimension = size();
      reshape(this.m_pntPosition.x, this.m_pntPosition.y, dimension.width, dimension.height);
      super.show();
      reshape(this.m_pntPosition.x, this.m_pntPosition.y, dimension.width, dimension.height);
      return;
    } 
    super.show();
  }
  
  public boolean action(Event paramEvent, Object paramObject) {
    dispose();
    return true;
  }
  
  public boolean handleEvent(Event paramEvent) {
    if (paramEvent.id == 201)
      dispose(); 
    return super.handleEvent(paramEvent);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\Help\webhelp.zip!\hhapplet\AboutDialogBox.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */