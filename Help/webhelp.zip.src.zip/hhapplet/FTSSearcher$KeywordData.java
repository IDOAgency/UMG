package hhapplet;

class KeywordData {
  public String m_strKeyword;
  
  public int[] m_aryTopicLinks;
  
  final FTSSearcher this$0;
  
  KeywordData(FTSSearcher paramFTSSearcher) { (this.this$0 = paramFTSSearcher).getClass(); }
  
  public void addTopicLink(int paramInt) {
    int[] arrayOfInt = new int[(this.m_aryTopicLinks == null) ? 1 : (this.m_aryTopicLinks.length + 1)];
    arrayOfInt[this.m_aryTopicLinks.length] = paramInt;
    this.m_aryTopicLinks = null;
    this.m_aryTopicLinks = arrayOfInt;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\Help\webhelp.zip!\hhapplet\FTSSearcher$KeywordData.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */