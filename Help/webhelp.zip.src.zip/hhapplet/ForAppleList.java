package hhapplet;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Event;
import java.awt.LayoutManager;
import java.awt.List;
import java.awt.Panel;
import java.awt.Scrollbar;
import java.util.Vector;

public class ForAppleList extends Panel {
  Vector items = new Vector();
  
  int rows = 0;
  
  int visibleIndex = -1;
  
  int selected = -1;
  
  private static final String base = "list";
  
  private static int nameCounter = 0;
  
  private LayoutManager m_layout;
  
  private Panel m_pnlCenter = new Panel();
  
  private Panel m_pnlBlank = new Panel();
  
  private LayoutManager m_layCenter = new BorderLayout(-16, 0);
  
  private OurScrollbar m_sbVert = new OurScrollbar(this, 1);
  
  private List m_itemList = new List();
  
  private IndexPane m_ixPane;
  
  private boolean m_bScrollChanged = true;
  
  protected int m_nTopIndex = 0;
  
  static final int DEFAULT_VISIBLE_ROWS = 0;
  
  public String getSelectedItem() {
    int i = getSelectedIndex();
    return (i < 0) ? null : getItem(i);
  }
  
  public int countItems() { return this.items.size(); }
  
  public int getVisibleIndex() { return this.visibleIndex; }
  
  public void UpdateList() {
    if (this.m_bScrollChanged == true) {
      CalculateRows();
      this.m_itemList.clear();
      for (int i = this.m_nTopIndex; i < this.m_nTopIndex + this.rows; i++) {
        if (i < this.items.size())
          this.m_itemList.addItem((String)this.items.elementAt(i)); 
      } 
      if (this.items.size() > this.rows) {
        this.m_sbVert.enable(true);
        this.m_sbVert.setValues(this.m_sbVert.getValue(), this.rows, 0, this.items.size());
      } else {
        this.m_sbVert.enable(false);
      } 
      if (this.selected > -1)
        this.m_itemList.select(this.selected - this.m_nTopIndex); 
      this.m_bScrollChanged = false;
    } 
  }
  
  public void select(int paramInt) {}
  
  public int getItemCount() { return countItems(); }
  
  public boolean isIndexSelected(int paramInt) { return isSelected(paramInt); }
  
  public void makeVisible(int paramInt) {
    if (paramInt >= 0 && paramInt != this.m_nTopIndex) {
      this.m_sbVert.setValue(paramInt);
      this.m_bScrollChanged = true;
      this.m_nTopIndex = paramInt;
      UpdateList();
    } 
  }
  
  public Dimension preferredSize(int paramInt) { return new Dimension(0, 0); }
  
  public Dimension preferredSize() {
    synchronized (getTreeLock()) {
      if (this.rows > 0)
        return preferredSize(this.rows); 
      return super.preferredSize();
    } 
  }
  
  protected String paramString() { return super.paramString() + ",selected=" + getSelectedItem(); }
  
  public void delItems(int paramInt1, int paramInt2) {
    for (int i = paramInt2; i >= paramInt1; i--)
      this.items.removeElementAt(i); 
  }
  
  public void remove(String paramString) {
    int i = this.items.indexOf(paramString);
    if (i < 0)
      throw new IllegalArgumentException("item " + paramString + " not found in list"); 
    remove(i);
  }
  
  public void remove(int paramInt) { delItem(paramInt); }
  
  public void removeAll() { clear(); }
  
  public Object[] getSelectedObjects() { return getSelectedItems(); }
  
  public void deselect(int paramInt) {}
  
  public String getItem(int paramInt) { return getItemImpl(paramInt); }
  
  public void replaceItem(String paramString, int paramInt) {
    remove(paramInt);
    addItem(paramString, paramInt);
  }
  
  public ForAppleList(IndexPane paramIndexPane) { this(0, paramIndexPane); }
  
  public ForAppleList(int paramInt, IndexPane paramIndexPane) {
    this.m_ixPane = paramIndexPane;
    this.rows = (paramInt != 0) ? paramInt : 0;
    this.m_layout = new BorderLayout(0, 0);
    setLayout(this.m_layout);
    this.m_pnlCenter.setLayout(this.m_layCenter);
    this.m_pnlBlank.resize(1, 0);
    this.m_pnlCenter.add("East", this.m_pnlBlank);
    this.m_pnlCenter.add("Center", this.m_itemList);
    add("East", this.m_sbVert);
    add("Center", this.m_pnlCenter);
    this.m_sbVert.enable(false);
  }
  
  public boolean isSelected(int paramInt) { return (paramInt == this.selected); }
  
  public boolean mouseUp(Event paramEvent, int paramInt1, int paramInt2) {
    UpdateList();
    return super.mouseUp(paramEvent, paramInt1, paramInt2);
  }
  
  public Dimension minimumSize(int paramInt) { return new Dimension(0, 0); }
  
  public Dimension minimumSize() {
    synchronized (getTreeLock()) {
      if (this.rows > 0)
        return minimumSize(this.rows); 
      return super.minimumSize();
    } 
  }
  
  final String getItemImpl(int paramInt) { return (String)this.items.elementAt(paramInt); }
  
  public void addItem(String paramString) { addItem(paramString, -1); }
  
  public String[] getItems() {
    String[] arrayOfString = new String[this.items.size()];
    this.items.copyInto(arrayOfString);
    return arrayOfString;
  }
  
  public void addItem(String paramString, int paramInt) {
    if (paramInt < -1 || paramInt >= this.items.size())
      paramInt = -1; 
    if (paramInt == -1) {
      this.items.addElement(paramString);
      return;
    } 
    this.items.insertElementAt(paramString, paramInt);
  }
  
  public void delItem(int paramInt) { delItems(paramInt, paramInt); }
  
  public int getSelectedIndex() { return this.selected; }
  
  public Dimension getPreferredSize(int paramInt) { return preferredSize(paramInt); }
  
  public Dimension getPreferredSize() { return preferredSize(); }
  
  public void clear() {
    this.items = new Vector();
    this.selected = -1;
    this.m_bScrollChanged = true;
    UpdateList();
  }
  
  public Dimension getMinimumSize(int paramInt) { return minimumSize(paramInt); }
  
  public Dimension getMinimumSize() { return minimumSize(); }
  
  public boolean handleEvent(Event paramEvent) {
    System.out.println("Event = " + paramEvent.toString());
    switch (paramEvent.id) {
      case 605:
        this.m_bScrollChanged = true;
        this.m_nTopIndex = this.m_sbVert.getValue();
        break;
      case 601:
      case 602:
      case 603:
      case 604:
        this.m_bScrollChanged = true;
        this.m_nTopIndex = this.m_sbVert.getValue();
        UpdateList();
        break;
      case 701:
        this.selected = this.m_nTopIndex + this.m_itemList.getSelectedIndex();
        break;
    } 
    return super.handleEvent(paramEvent);
  }
  
  public String[] getSelectedItems() {
    if (this.selected < 0)
      return null; 
    String[] arrayOfString = new String[1];
    arrayOfString[0] = getItem(this.selected);
    return arrayOfString;
  }
  
  public int getRows() { return this.rows; }
  
  private void CalculateRows() {
    int i = (this.m_itemList.size()).height;
    this.rows = 1;
    while ((this.m_itemList.preferredSize(this.rows)).height < i)
      this.rows++; 
    this.rows += 3;
  }
  
  private class OurScrollbar extends Scrollbar {
    final ForAppleList this$0;
    
    public OurScrollbar(ForAppleList this$0, int param1Int) {
      super(param1Int);
      (this.this$0 = this$0).getClass();
    }
    
    public boolean mouseUp(Event param1Event, int param1Int1, int param1Int2) {
      this.this$0.UpdateList();
      return super.mouseUp(param1Event, param1Int1, param1Int2);
    }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\Help\webhelp.zip!\hhapplet\ForAppleList.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */