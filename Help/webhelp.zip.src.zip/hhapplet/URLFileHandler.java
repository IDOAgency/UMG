package hhapplet;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;

public class URLFileHandler {
  public static String GetNormalizedLocal(String paramString) {
    String str = paramString;
    for (byte b = 0; b < str.length(); b++) {
      if (str.charAt(b) > '')
        str = str.substring(0, b) + "%" + Integer.toString(str.charAt(b), 16) + str.substring(b + 1, str.length()); 
    } 
    return str;
  }
  
  public static URL makeURL(URL paramURL, String paramString1, String paramString2) throws MalformedURLException {
    try {
      String str1 = paramURL.getProtocol();
      String str2 = paramURL.getHost();
      String str3 = paramURL.getFile();
      int i = paramURL.getPort();
      String str4 = tuHtmlToText(str3);
      String str5 = GetNormalizedLocal(str4);
      URL uRL = new URL(str1, str2, i, str5);
      String str6 = tuHtmlToText(paramString1);
      String str7 = GetNormalizedLocal(str6);
      return new URL(uRL, str7);
    } catch (MalformedURLException malformedURLException) {
      File file = new File(paramString1);
      return file.exists() ? new URL("file:/" + paramString1) : new URL(paramURL, paramString2);
    } 
  }
  
  static String tuHtmlToText(String paramString) {
    if (paramString == null)
      return null; 
    int i = paramString.indexOf('&');
    if (i < 0)
      return paramString; 
    String str = "";
    while (i > -1 && i < paramString.length() - 2) {
      str = str + paramString.substring(0, i);
      String str1 = paramString.substring(i);
      int j = str1.indexOf(';');
      if (j < 0) {
        str = str + str1;
        break;
      } 
      if (j < str1.length() - 1) {
        paramString = str1.substring(j + 1);
      } else {
        paramString = "";
      } 
      str1 = str1.substring(1, j);
      switch (Character.toUpperCase(str1.charAt(0))) {
        case 'A':
          if (str1.equalsIgnoreCase("amp"))
            str1 = "&"; 
          break;
        case 'C':
          if (str1.equalsIgnoreCase("copy"))
            str1 = "(c)"; 
          break;
        case 'G':
          if (str1.equalsIgnoreCase("gt"))
            str1 = ">"; 
          break;
        case 'L':
          if (str1.equalsIgnoreCase("lt"))
            str1 = "<"; 
          break;
        case 'N':
          if (str1.equalsIgnoreCase("nbsp"))
            str1 = " "; 
          break;
        case 'Q':
          if (str1.equalsIgnoreCase("quot"))
            str1 = "\""; 
          break;
        case 'R':
          if (str1.equalsIgnoreCase("reg"))
            str1 = "(R)"; 
          break;
      } 
      str = str + str1;
      i = paramString.indexOf('&');
      if (i < 0)
        str = str + paramString; 
    } 
    return str;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\Help\webhelp.zip!\hhapplet\URLFileHandler.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */