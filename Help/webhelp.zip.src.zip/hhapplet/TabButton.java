package hhapplet;

import WebHelp;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Rectangle;

public class TabButton extends CanvasButton {
  protected String label;
  
  protected int x_offset = -1;
  
  protected int y_offset = -1;
  
  protected Font active;
  
  protected Font inactive;
  
  protected int tab_x;
  
  protected int tab_y;
  
  protected int tab_width;
  
  protected int tab_height;
  
  protected boolean m_bDrawLeft = true;
  
  protected boolean m_bDrawRight = true;
  
  protected boolean m_bCenterBroken = false;
  
  protected void centerText(Font paramFont) {
    Rectangle rectangle = bounds();
    FontMetrics fontMetrics = getFontMetrics(paramFont);
    int i = fontMetrics.stringWidth(this.label);
    int j = fontMetrics.getMaxAscent();
    this.y_offset = rectangle.height - j;
    this.y_offset = this.y_offset / 2 + j;
    this.x_offset = rectangle.width - i;
    this.x_offset /= 2;
    if (this.m_bCenterBroken && !isEnabled())
      this.x_offset += 3; 
  }
  
  public void reshape(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.reshape(paramInt1, paramInt2, paramInt3, paramInt4);
    this.tab_x = paramInt1;
    this.tab_y = paramInt2;
    this.tab_width = paramInt3;
    this.tab_height = paramInt4;
    centerText(getFont());
  }
  
  public TabButton(String paramString) {
    int i = WebHelp.GetFontSize();
    this.active = new Font(WebHelp.GetFontName(), 1, i);
    while (this.active.getSize() != i && i < WebHelp.GetFontSize() + 10)
      this.active = new Font(WebHelp.GetFontName(), 1, ++i); 
    this.inactive = new Font(WebHelp.GetFontName(), 0, i);
    setFont(this.inactive);
    this.label = paramString;
    if (System.getProperty("java.vendor").startsWith("Netscape") && System.getProperty("os.name").startsWith("Windows 95"))
      try {
        String str = System.getProperty("java.version");
        if (str.startsWith("1.02"))
          this.m_bCenterBroken = true; 
        Integer integer1 = new Integer(str.substring(0, 1));
        Integer integer2 = new Integer(str.substring(2, 3));
        Integer integer3 = new Integer(str.substring(4, 5));
        if (integer1.intValue() <= 1 && integer2.intValue() <= 1 && integer3.intValue() <= 2) {
          this.m_bCenterBroken = true;
          return;
        } 
      } catch (Exception exception) {} 
  }
  
  public void paint(Graphics paramGraphics) {
    paramGraphics.setColor(getBackground());
    paramGraphics.fillRect(0, 0, (bounds()).width, (bounds()).height);
    if (this.img != null) {
      paramGraphics.drawImage(this.img, 2, 2, null);
    } else if (this.label != null) {
      centerText(getFont());
      paramGraphics.setColor(getForeground());
      paramGraphics.setFont(getFont());
      paramGraphics.drawString(this.label, this.x_offset, this.y_offset);
    } 
    paintBorderOut(paramGraphics);
  }
  
  public void paintBorderOut(Graphics paramGraphics) {
    Rectangle rectangle = bounds();
    if (!isEnabled()) {
      paramGraphics.setColor(Color.white);
      paramGraphics.drawLine(2, 0, rectangle.width - 3, 0);
      paramGraphics.drawLine(1, 1, 1, 1);
      paramGraphics.drawLine(0, 2, 0, rectangle.height - 1);
      paramGraphics.setColor(Color.white);
      paramGraphics.drawLine(2, 0, rectangle.width - 3, 0);
    } else if (this.m_bDrawLeft) {
      paramGraphics.setColor(Color.white);
      paramGraphics.drawLine(2, 3, rectangle.width - 3, 3);
      paramGraphics.drawLine(1, 4, 1, 4);
      paramGraphics.drawLine(0, 5, 0, rectangle.height - 1);
    } else {
      paramGraphics.setColor(Color.white);
      paramGraphics.drawLine(0, 3, rectangle.width - 3, 3);
    } 
    if (!isEnabled()) {
      paramGraphics.setColor(Color.darkGray);
      paramGraphics.drawLine(rectangle.width - 2, 2, rectangle.width - 2, rectangle.height - 1);
      paramGraphics.setColor(Color.black);
      paramGraphics.drawLine(rectangle.width - 2, 1, rectangle.width - 2, 1);
      paramGraphics.drawLine(rectangle.width - 1, 2, rectangle.width - 1, rectangle.height - 1);
    } else if (this.m_bDrawRight) {
      paramGraphics.setColor(Color.darkGray);
      paramGraphics.drawLine(rectangle.width - 2, 5, rectangle.width - 2, rectangle.height - 1);
      paramGraphics.setColor(Color.black);
      paramGraphics.drawLine(rectangle.width - 2, 4, rectangle.width - 2, 4);
      paramGraphics.drawLine(rectangle.width - 1, 5, rectangle.width - 1, rectangle.height - 1);
    } else {
      paramGraphics.setColor(Color.white);
      paramGraphics.drawLine(2, 3, rectangle.width - 1, 3);
    } 
    if (isEnabled()) {
      paramGraphics.setColor(Color.white);
      paramGraphics.drawLine(0, rectangle.height - 1, rectangle.width - 1, rectangle.height - 1);
      paramGraphics.setColor(getBackground());
      paramGraphics.drawLine(0, 0, rectangle.width - 1, 0);
      paramGraphics.drawLine(0, 1, rectangle.width - 1, 1);
      paramGraphics.drawLine(0, 2, rectangle.width - 1, 2);
    } 
  }
  
  public void disable() {
    if (isEnabled()) {
      setFont(this.active);
      super.reshape(this.tab_x, this.tab_y, this.tab_width, this.tab_height);
      centerText(this.active);
      repaint();
      super.disable();
    } 
  }
  
  public void enable() {
    if (!isEnabled()) {
      setFont(this.inactive);
      super.reshape(this.tab_x, this.tab_y, this.tab_width, this.tab_height);
      centerText(this.inactive);
      repaint();
      super.enable();
    } 
  }
  
  public void enable(boolean paramBoolean) {
    if (paramBoolean) {
      enable();
      return;
    } 
    disable();
  }
  
  public void SetDrawRight(boolean paramBoolean) {
    this.m_bDrawRight = paramBoolean;
    repaint();
  }
  
  public Dimension preferredSize() {
    try {
      if (this.img != null)
        return new Dimension(this.img.getWidth(this) + 4, this.img.getHeight(this) + 4); 
      if (this.label != null) {
        FontMetrics fontMetrics = getFontMetrics(getFont());
        int i = fontMetrics.stringWidth(this.label);
        int j = fontMetrics.getMaxAscent();
        i += 20;
        j += 8 + fontMetrics.getMaxDescent();
        return new Dimension(i, j);
      } 
      return new Dimension(20, 20);
    } catch (Exception exception) {
      return new Dimension(20, 20);
    } 
  }
  
  public void SetDrawLeft(boolean paramBoolean) {
    this.m_bDrawLeft = paramBoolean;
    repaint();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\Help\webhelp.zip!\hhapplet\TabButton.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */