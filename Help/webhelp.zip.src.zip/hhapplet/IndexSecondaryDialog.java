package hhapplet;

import WebHelp;
import java.applet.Applet;
import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Event;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Label;
import java.awt.List;
import java.awt.Panel;
import java.awt.Point;
import java.awt.Toolkit;
import java.net.MalformedURLException;
import java.util.Vector;

public class IndexSecondaryDialog extends Frame {
  protected Button m_btnDisplay = new Button("Display");
  
  protected Button m_btnCancel = new Button("Cancel");
  
  protected List m_list = new List();
  
  protected Applet m_applet;
  
  protected Vector m_vEntries;
  
  protected DialogDoneTarget m_ddtDone;
  
  private boolean m_bIsIE3 = false;
  
  private Point m_pntPosition;
  
  public boolean gotFocus(Event paramEvent, Object paramObject) {
    if (paramEvent.target == this) {
      this.m_list.requestFocus();
      return true;
    } 
    return super.gotFocus(paramEvent, paramObject);
  }
  
  public IndexSecondaryDialog(Applet paramApplet, Vector paramVector, DialogDoneTarget paramDialogDoneTarget) {
    super("Topics Found");
    this.m_applet = paramApplet;
    this.m_vEntries = paramVector;
    this.m_ddtDone = paramDialogDoneTarget;
    if (System.getProperty("java.vendor").startsWith("Microsoft") && System.getProperty("java.version").startsWith("1.0"))
      this.m_bIsIE3 = true; 
    int i = WebHelp.GetFontSize();
    this.m_list.setFont(new Font(WebHelp.GetFontName(), 0, i));
    for (byte b = 0; b < this.m_vEntries.size(); b++)
      this.m_list.addItem(((IndexSecondaryEntry)this.m_vEntries.elementAt(b)).name); 
    this.m_list.select(0);
    Panel panel = new Panel();
    panel.add(this.m_btnDisplay);
    panel.add(this.m_btnCancel);
    setLayout(new BorderLayout(5, 5));
    this.m_list.setBackground(Color.white);
    setBackground(new Color(192, 192, 192));
    char c1 = 'Ĭ';
    char c2 = 'ð';
    resize(c1, c2);
    add("North", new Label("   Click a topic, then click Display."));
    add("Center", this.m_list);
    add("South", panel);
    Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
    int j = dimension.width / 2 - c1 / '\002';
    int k = dimension.height / 2 - c2 / '\002';
    this.m_pntPosition = new Point(j, k);
    move(j, k);
    setResizable(false);
  }
  
  public List getList() { return this.m_list; }
  
  protected void gotoSelectedIndex() {
    int i = this.m_list.getSelectedIndex();
    if (i != -1) {
      try {
        IndexSecondaryEntry indexSecondaryEntry = (IndexSecondaryEntry)this.m_vEntries.elementAt(i);
        if (indexSecondaryEntry.frame != null) {
          this.m_applet.getAppletContext().showDocument(URLFileHandler.makeURL(this.m_applet.getDocumentBase(), indexSecondaryEntry.local, indexSecondaryEntry.url), indexSecondaryEntry.frame);
        } else {
          this.m_applet.getAppletContext().showDocument(URLFileHandler.makeURL(this.m_applet.getDocumentBase(), indexSecondaryEntry.local, indexSecondaryEntry.url), "_self");
        } 
      } catch (MalformedURLException malformedURLException) {}
      closeDialog();
      dispose();
    } 
  }
  
  public void show() {
    if (this.m_bIsIE3) {
      Dimension dimension = size();
      reshape(this.m_pntPosition.x, this.m_pntPosition.y, dimension.width, dimension.height);
      super.show();
      reshape(this.m_pntPosition.x, this.m_pntPosition.y, dimension.width, dimension.height);
    } else {
      super.show();
    } 
    this.m_list.requestFocus();
  }
  
  public boolean action(Event paramEvent, Object paramObject) {
    if (paramEvent.target == this.m_btnDisplay || paramEvent.target == this.m_list) {
      gotoSelectedIndex();
      return true;
    } 
    if (paramEvent.target == this.m_btnCancel) {
      closeDialog();
      return true;
    } 
    return false;
  }
  
  protected void closeDialog() {
    dispose();
    if (this.m_ddtDone != null)
      this.m_ddtDone.dialogDone(); 
  }
  
  public boolean handleEvent(Event paramEvent) {
    if (System.getProperty("java.version").startsWith("1.1.5") && System.getProperty("java.vendor").startsWith("Netscape") && paramEvent.id == 401 && paramEvent.key == 10 && (paramEvent.target == this.m_btnDisplay || paramEvent.target == this.m_btnCancel)) {
      action(paramEvent, paramEvent.target);
      return true;
    } 
    if (paramEvent.id == 201) {
      closeDialog();
      dispose();
    } else {
      if (paramEvent.target == this.m_list && paramEvent.key == 10 && paramEvent.id == 401) {
        gotoSelectedIndex();
        return true;
      } 
      if (paramEvent.target == this.m_list && paramEvent.key == 10 && paramEvent.id == 402) {
        if (System.getProperty("java.version").equals("1.1") && System.getProperty("java.vendor").startsWith("Microsoft")) {
          gotoSelectedIndex();
          return true;
        } 
      } else if (paramEvent.key == 27 && paramEvent.id == 402) {
        closeDialog();
        dispose();
      } 
    } 
    return super.handleEvent(paramEvent);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\Help\webhelp.zip!\hhapplet\IndexSecondaryDialog.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */