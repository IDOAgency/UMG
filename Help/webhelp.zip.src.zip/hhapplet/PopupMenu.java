package hhapplet;

import java.applet.Applet;
import java.awt.Button;
import java.awt.Dimension;
import java.awt.Event;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.Window;
import java.net.MalformedURLException;
import java.util.Vector;

public class PopupMenu extends Window {
  private Applet m_applet;
  
  private Vector m_vEntries;
  
  private boolean m_bIsIE3 = false;
  
  private Point m_pntPosition;
  
  public PopupMenu(Applet paramApplet, Vector paramVector) {
    super(null);
    this.m_applet = paramApplet;
    this.m_vEntries = paramVector;
    setLayout(new GridLayout(paramVector.size(), 1));
    for (byte b = 0; b < paramVector.size(); b++)
      add(new Button(((IndexSecondaryEntry)this.m_vEntries.elementAt(b)).name)); 
    pack();
    Rectangle rectangle = bounds();
    if (rectangle.width < 150) {
      rectangle.width = 150;
      resize(rectangle.width, rectangle.height);
    } 
    Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
    int i = dimension.width / 2 - rectangle.width / 2;
    int j = dimension.height / 2 - rectangle.height / 2;
    this.m_pntPosition = new Point(i, j);
    move(i, j);
  }
  
  public void show() {
    if (this.m_bIsIE3) {
      Dimension dimension = size();
      reshape(this.m_pntPosition.x, this.m_pntPosition.y, dimension.width, dimension.height);
      super.show();
      reshape(this.m_pntPosition.x, this.m_pntPosition.y, dimension.width, dimension.height);
      return;
    } 
    super.show();
  }
  
  public boolean action(Event paramEvent, Object paramObject) {
    String str = paramObject.toString();
    for (byte b = 0; b < this.m_vEntries.size(); b++) {
      if (str == ((IndexSecondaryEntry)this.m_vEntries.elementAt(b)).name) {
        try {
          IndexSecondaryEntry indexSecondaryEntry = (IndexSecondaryEntry)this.m_vEntries.elementAt(b);
          String str1 = (indexSecondaryEntry.frame != null) ? indexSecondaryEntry.frame : "_self";
          this.m_applet.getAppletContext().showDocument(URLFileHandler.makeURL(this.m_applet.getDocumentBase(), indexSecondaryEntry.local, indexSecondaryEntry.url), str1);
        } catch (MalformedURLException malformedURLException) {}
        dispose();
      } 
    } 
    return true;
  }
  
  public boolean handleEvent(Event paramEvent) {
    if (paramEvent.id == 201)
      dispose(); 
    return super.handleEvent(paramEvent);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\Help\webhelp.zip!\hhapplet\PopupMenu.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */