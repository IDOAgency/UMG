package hhapplet;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Panel;
import java.awt.Rectangle;

public class TabPanel extends Panel {
  Component m_compLast;
  
  protected Image buffer;
  
  public void paint(Graphics paramGraphics) {
    super.paint(paramGraphics);
    if (this.buffer == null)
      try {
        this.buffer = createImage((bounds()).width, (bounds()).height);
      } catch (Throwable throwable) {
        this.buffer = null;
      }  
    if (this.buffer == null)
      return; 
    Color color1 = getBackground();
    Color color2 = color1.brighter();
    color2.darker();
    Graphics graphics = this.buffer.getGraphics();
    Rectangle rectangle1 = bounds();
    graphics.setColor(getBackground());
    graphics.fillRect(rectangle1.x, rectangle1.y, rectangle1.width, rectangle1.height);
    graphics.setColor(color2);
    Rectangle rectangle2 = this.m_compLast.bounds();
    byte b = 0;
    int i = rectangle2.y + rectangle2.height;
    graphics.drawLine(b, i - 1, rectangle1.width, i - 1);
    paramGraphics.drawImage(this.buffer, (bounds()).x, (bounds()).y, this);
  }
  
  public Component add(Component paramComponent) {
    this.m_compLast = paramComponent;
    return super.add(paramComponent);
  }
  
  public void resize(int paramInt1, int paramInt2) {
    if (this.buffer != null && ((bounds()).width != paramInt1 || (bounds()).height != paramInt2)) {
      this.buffer.flush();
      this.buffer = null;
    } 
    super.resize(paramInt1, paramInt2);
  }
  
  public void reshape(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (this.buffer != null && ((bounds()).width != paramInt3 || (bounds()).height != paramInt4)) {
      this.buffer.flush();
      this.buffer = null;
    } 
    super.reshape(paramInt1, paramInt2, paramInt3, paramInt4);
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\Help\webhelp.zip!\hhapplet\TabPanel.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */