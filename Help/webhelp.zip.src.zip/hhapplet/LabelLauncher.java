package hhapplet;

import java.awt.Event;
import java.awt.Label;
import java.awt.Window;

public class LabelLauncher extends Label {
  Window m_window;
  
  public LabelLauncher(String paramString, Window paramWindow) {
    super(paramString);
    this.m_window = paramWindow;
  }
  
  public boolean mouseDown(Event paramEvent, int paramInt1, int paramInt2) {
    this.m_window.show();
    return true;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\Help\webhelp.zip!\hhapplet\LabelLauncher.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */