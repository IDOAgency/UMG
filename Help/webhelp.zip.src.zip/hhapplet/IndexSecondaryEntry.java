package hhapplet;

public class IndexSecondaryEntry {
  public String name;
  
  public String local;
  
  public String url;
  
  public String frame;
  
  public String see_also;
  
  public String toString() { return getClass().getName() + "[name=" + this.name + ",local=" + this.local + ",url=" + this.url + ",see also=" + this.see_also + ",frame=" + this.frame + "]"; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\Help\webhelp.zip!\hhapplet\IndexSecondaryEntry.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */