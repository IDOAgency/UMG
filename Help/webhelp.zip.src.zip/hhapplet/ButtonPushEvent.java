package hhapplet;

public class ButtonPushEvent {
  private int x;
  
  private int y;
  
  private Object source;
  
  public int getX() { return this.x; }
  
  public ButtonPushEvent(Object paramObject, int paramInt1, int paramInt2) {
    this.source = paramObject;
    this.x = paramInt1;
    this.y = paramInt2;
  }
  
  public ButtonPushEvent(Object paramObject) { this(paramObject, 0, 0); }
  
  public int getY() { return this.y; }
  
  public Object getSource() { return this.source; }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\Help\webhelp.zip!\hhapplet\ButtonPushEvent.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */