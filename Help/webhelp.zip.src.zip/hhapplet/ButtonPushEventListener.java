package hhapplet;

public interface ButtonPushEventListener {
  void notifyButtonPushEvent(ButtonPushEvent paramButtonPushEvent);
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\Help\webhelp.zip!\hhapplet\ButtonPushEventListener.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */