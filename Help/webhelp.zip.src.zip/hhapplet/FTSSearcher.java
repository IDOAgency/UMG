package hhapplet;

import java.applet.Applet;
import java.awt.List;

public class FTSSearcher {
  protected Applet m_applet;
  
  protected int m_nTopicCount = 0;
  
  protected int m_nKeywordCount = 0;
  
  protected int m_nStopWordCount = 0;
  
  protected TopicData[] m_tdTopics;
  
  protected KeywordData[] m_kdKeywords;
  
  protected String[] m_strStopWords;
  
  protected int[] m_aryTopicsFound;
  
  protected int m_nTopicsFoundCount = 0;
  
  protected FTSPane m_spSearch = null;
  
  public List m_lst = null;
  
  public SearchTree m_searchtree = null;
  
  public String getTopicURL(String paramString) {
    for (byte b = 0; b < this.m_nTopicsFoundCount; b++) {
      if ((this.m_tdTopics[this.m_aryTopicsFound[b]]).m_strTitle.compareTo(paramString) == 0)
        return (this.m_tdTopics[this.m_aryTopicsFound[b]]).m_urlTopic; 
    } 
    return "";
  }
  
  public boolean setTopicData(int paramInt, String paramString1, String paramString2) {
    if (paramInt < 0 || paramInt >= this.m_nTopicCount)
      return false; 
    this.m_tdTopics[paramInt] = new TopicData(this);
    (this.m_tdTopics[paramInt]).m_strTitle = paramString1;
    (this.m_tdTopics[paramInt]).m_urlTopic = paramString2;
    return true;
  }
  
  public int getKeywordCount() { return this.m_nKeywordCount; }
  
  public int setKeywordCount(int paramInt) {
    this.m_kdKeywords = new KeywordData[paramInt];
    this.m_nKeywordCount = paramInt;
    return this.m_nKeywordCount;
  }
  
  public int getStopWordCount() { return this.m_nStopWordCount; }
  
  public int setStopWordCount(int paramInt) {
    this.m_strStopWords = new String[paramInt];
    this.m_nStopWordCount = paramInt;
    return this.m_nStopWordCount;
  }
  
  public FTSSearcher(Applet paramApplet) { this.m_applet = paramApplet; }
  
  public void setPane(FTSPane paramFTSPane) { this.m_spSearch = paramFTSPane; }
  
  public int getTopicCount() { return this.m_nTopicCount; }
  
  public int setTopicCount(int paramInt) {
    this.m_tdTopics = new TopicData[paramInt];
    this.m_nTopicCount = paramInt;
    this.m_aryTopicsFound = new int[this.m_nTopicCount];
    return this.m_nTopicCount;
  }
  
  private void SortTopics(int[] paramArrayOfInt, int paramInt1, int paramInt2) {
    if (paramInt2 - paramInt1 > 0) {
      int j = paramInt1;
      for (int k = paramInt1 + 1; k <= paramInt2; k++) {
        TopicData topicData1 = this.m_tdTopics[paramArrayOfInt[k]];
        String str1 = topicData1.m_strTitle;
        TopicData topicData2 = this.m_tdTopics[paramArrayOfInt[paramInt1]];
        String str2 = topicData2.m_strTitle;
        if (str1.compareTo(str2) < 0) {
          j++;
          int m = paramArrayOfInt[k];
          paramArrayOfInt[k] = paramArrayOfInt[j];
          paramArrayOfInt[j] = m;
        } 
      } 
      int i = paramArrayOfInt[paramInt1];
      paramArrayOfInt[paramInt1] = paramArrayOfInt[j];
      paramArrayOfInt[j] = i;
      SortTopics(paramArrayOfInt, paramInt1, j);
      SortTopics(paramArrayOfInt, j + 1, paramInt2);
    } 
  }
  
  public boolean doSearch(String paramString, List paramList, SearchTree paramSearchTree) {
    boolean bool1 = false;
    boolean bool2 = false;
    boolean bool3 = false;
    boolean bool4 = true;
    String str1 = "";
    String str2 = "";
    int i = 0;
    int j = 0;
    int k = 0;
    byte b1 = 0;
    byte b2 = 0;
    this.m_spSearch.HideList();
    this.m_lst = paramList;
    this.m_searchtree = paramSearchTree;
    if (this.m_lst != null && this.m_lst.countItems() > 0)
      this.m_lst.clear(); 
    if (this.m_searchtree != null && this.m_searchtree.countItems() > 0)
      this.m_searchtree.clear(); 
    this.m_nTopicsFoundCount = 0;
    String str3 = "\t\r\n\"\\ .,!@#$%^&*()~'`:;<>?/{}[]|+-=";
    int m = str3.length();
    while (!bool3 && paramString.length() != 0) {
      i = -1;
      int n;
      for (n = 0; n < m && i == -1; n++)
        i = paramString.indexOf(str3.charAt(n)); 
      if (i == -1) {
        str1 = paramString;
        paramString = "";
      } else {
        str1 = paramString.substring(0, i);
        if (paramString.charAt(i) == '~')
          bool2 = true; 
        paramString = paramString.substring(i + 1);
      } 
      if (str1.length() == 0) {
        if (paramString.length() == 0)
          break; 
        continue;
      } 
      if (str1.equalsIgnoreCase("or") || str1.compareTo("|") == 0) {
        bool1 = false;
        bool2 = false;
        continue;
      } 
      if (str1.equalsIgnoreCase("and") || str1.compareTo("&") == 0) {
        bool1 = true;
        bool2 = false;
        continue;
      } 
      if (str1.equalsIgnoreCase("not") || str1.compareTo("~") == 0) {
        bool2 = true;
        continue;
      } 
      if (!IsStopWord(str1)) {
        if (str1.substring(false, true) == "~") {
          bool2 = true;
          str1 = str1.substring(1);
        } 
        str2 = GetStem(str1);
        j = -1;
        j = FindKeyword(str2);
        if (j != -1) {
          n = (this.m_kdKeywords[j]).m_aryTopicLinks.length;
          if (!bool1) {
            if (bool2) {
              for (b1 = 0; b1 < this.m_nTopicCount; b1++) {
                for (b2 = 0; b2 < n && (this.m_kdKeywords[j]).m_aryTopicLinks[b2] != b1; b2++);
                if (b2 == n) {
                  for (k = 0; k < this.m_nTopicsFoundCount && this.m_aryTopicsFound[k] != b1; k++);
                  if (k == this.m_nTopicsFoundCount) {
                    this.m_aryTopicsFound[this.m_nTopicsFoundCount] = b1;
                    this.m_nTopicsFoundCount++;
                  } 
                } 
              } 
            } else {
              for (b1 = 0; b1 < n; b1++) {
                int i1 = (this.m_kdKeywords[j]).m_aryTopicLinks[b1];
                for (k = 0; k < this.m_nTopicsFoundCount && this.m_aryTopicsFound[k] != i1; k++);
                if (k == this.m_nTopicsFoundCount) {
                  this.m_aryTopicsFound[this.m_nTopicsFoundCount] = i1;
                  this.m_nTopicsFoundCount++;
                } 
              } 
            } 
          } else if (bool1 == true) {
            if (bool2) {
              for (b1 = 0; b1 < n; b1++) {
                for (k = this.m_nTopicsFoundCount - 1; k >= 0; k--) {
                  if (this.m_aryTopicsFound[k] == (this.m_kdKeywords[j]).m_aryTopicLinks[b1]) {
                    if (this.m_nTopicsFoundCount > 0)
                      this.m_aryTopicsFound[k] = this.m_aryTopicsFound[this.m_nTopicsFoundCount - 1]; 
                    this.m_nTopicsFoundCount--;
                    break;
                  } 
                } 
              } 
            } else {
              for (k = this.m_nTopicsFoundCount - 1; k >= 0; k--) {
                for (b1 = 0; b1 < n && this.m_aryTopicsFound[k] != (this.m_kdKeywords[j]).m_aryTopicLinks[b1]; b1++);
                if (b1 == n) {
                  if (this.m_nTopicsFoundCount > 0)
                    this.m_aryTopicsFound[k] = this.m_aryTopicsFound[this.m_nTopicsFoundCount - 1]; 
                  this.m_nTopicsFoundCount--;
                } 
              } 
            } 
          } 
        } else if (bool1 == true && !bool2) {
          this.m_nTopicsFoundCount = 0;
        } else if (!bool1 && bool2) {
          this.m_nTopicsFoundCount = 0;
          for (b1 = 0; b1 < this.m_nTopicCount; b1++) {
            this.m_aryTopicsFound[this.m_nTopicsFoundCount] = b1;
            this.m_nTopicsFoundCount++;
          } 
        } 
        if (bool4) {
          bool4 = false;
          bool1 = true;
        } 
      } 
    } 
    SortTopics(this.m_aryTopicsFound, 0, this.m_nTopicsFoundCount - 1);
    if (this.m_lst != null)
      for (byte b = 0; b < this.m_nTopicsFoundCount; b++)
        this.m_lst.addItem((this.m_tdTopics[this.m_aryTopicsFound[b]]).m_strTitle);  
    if (this.m_searchtree != null)
      for (byte b = 0; b < this.m_nTopicsFoundCount; b++)
        this.m_searchtree.addItem((this.m_tdTopics[this.m_aryTopicsFound[b]]).m_strTitle);  
    this.m_spSearch.ShowList();
    if (this.m_searchtree != null)
      this.m_searchtree.paint(this.m_searchtree.getGraphics()); 
    if (this.m_nTopicsFoundCount == 0) {
      if (this.m_lst != null)
        this.m_lst.addItem("No Topics Found."); 
      if (this.m_searchtree != null)
        this.m_searchtree.addItem("No Topics Found."); 
      if (this.m_searchtree != null)
        this.m_searchtree.paint(this.m_searchtree.getGraphics()); 
      return false;
    } 
    return true;
  }
  
  public boolean setStopWord(int paramInt, String paramString) {
    if (paramInt < 0 || paramInt >= this.m_nStopWordCount)
      return false; 
    if (paramString == null) {
      this.m_strStopWords[paramInt] = null;
    } else {
      this.m_strStopWords[paramInt] = paramString.toLowerCase();
    } 
    return true;
  }
  
  private int FindKeyword(String paramString) {
    int i = 0;
    int j = this.m_nKeywordCount - 1;
    int k = 0;
    boolean bool = false;
    String str = "";
    paramString = paramString.toLowerCase();
    while (i <= j) {
      k = i + j;
      k >>= 1;
      str = (this.m_kdKeywords[k]).m_strKeyword;
      if (paramString.compareTo(str) > 0) {
        i = (i == k) ? (k + 1) : k;
        continue;
      } 
      if (paramString.compareTo(str) < 0) {
        j = (j == k) ? (k - 1) : k;
        continue;
      } 
      bool = true;
      break;
    } 
    return bool ? k : -1;
  }
  
  public boolean setKeywordData(int paramInt, String paramString, int[] paramArrayOfInt) {
    if (paramInt < 0 || paramInt >= this.m_nKeywordCount)
      return false; 
    this.m_kdKeywords[paramInt] = new KeywordData(this);
    if (paramString == null) {
      (this.m_kdKeywords[paramInt]).m_strKeyword = null;
    } else {
      (this.m_kdKeywords[paramInt]).m_strKeyword = paramString.toLowerCase();
    } 
    (this.m_kdKeywords[paramInt]).m_aryTopicLinks = paramArrayOfInt;
    return true;
  }
  
  private String GetStem(String paramString) {
    String[] arrayOfString = new String[8];
    arrayOfString[0] = "ed";
    arrayOfString[1] = "es";
    arrayOfString[2] = "er";
    arrayOfString[3] = "s";
    arrayOfString[4] = "ingly";
    arrayOfString[5] = "ing";
    arrayOfString[6] = "ly";
    arrayOfString[7] = "e";
    int i = arrayOfString.length;
    int j = 0;
    null = "";
    String str = "";
    paramString = paramString.toLowerCase();
    for (byte b = 0; b < i; b++) {
      j = paramString.lastIndexOf(arrayOfString[b]);
      if (j > 0) {
        str = paramString.substring(j);
        if (str.compareTo(arrayOfString[b]) == 0) {
          null = paramString;
          if (paramString.charAt(j - 2) == paramString.charAt(j - 1)) {
            null = null.substring(0, j - 1);
          } else {
            null = null.substring(0, j);
          } 
          return null;
        } 
      } 
    } 
    return paramString;
  }
  
  private boolean IsStopWord(String paramString) {
    int i = 0;
    int j = this.m_nStopWordCount - 1;
    int k = 0;
    boolean bool = false;
    String str = null;
    paramString.toLowerCase();
    while (i <= j) {
      k = i + j;
      k >>= 1;
      str = this.m_strStopWords[k];
      if (paramString.compareTo(str) > 0) {
        i = (i == k) ? (k + 1) : k;
        continue;
      } 
      if (paramString.compareTo(str) < 0) {
        j = (j == k) ? (k - 1) : k;
        continue;
      } 
      bool = true;
      break;
    } 
    return bool;
  }
  
  private class TopicData {
    public String m_strTitle;
    
    public String m_urlTopic;
    
    final FTSSearcher this$0;
    
    TopicData(FTSSearcher this$0) { (this.this$0 = this$0).getClass(); }
  }
  
  private class KeywordData {
    public String m_strKeyword;
    
    public int[] m_aryTopicLinks;
    
    final FTSSearcher this$0;
    
    KeywordData(FTSSearcher this$0) { (this.this$0 = this$0).getClass(); }
    
    public void addTopicLink(int param1Int) {
      int[] arrayOfInt = new int[(this.m_aryTopicLinks == null) ? 1 : (this.m_aryTopicLinks.length + 1)];
      arrayOfInt[this.m_aryTopicLinks.length] = param1Int;
      this.m_aryTopicLinks = null;
      this.m_aryTopicLinks = arrayOfInt;
    }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\Help\webhelp.zip!\hhapplet\FTSSearcher.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */