package hhapplet;

import WebHelp;
import java.applet.Applet;
import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Color;
import java.awt.Event;
import java.awt.Font;
import java.awt.Label;
import java.awt.LayoutManager;
import java.awt.List;
import java.awt.Panel;
import java.awt.TextField;
import java.net.MalformedURLException;
import java.util.Vector;

public class IndexPane extends Panel implements DialogDoneTarget {
  protected Applet m_applet;
  
  protected Vector m_vSecondaryEntries = new Vector();
  
  protected List m_list;
  
  protected List m_listHolder;
  
  protected IndexTree m_forapplelistHolder;
  
  protected IndexTree m_forapplelist;
  
  protected TextField m_tfEdit = new TextField();
  
  protected Button m_btnDisplay = new Button("Display");
  
  protected IndexSecondaryDialog m_dlgSecondary;
  
  protected int m_nSelectedIndex = -1;
  
  protected Panel m_pnlEditArea = new Panel();
  
  protected Label m_lblEditArea = new Label("Type in the keyword to find:");
  
  protected LayoutManager m_layEditArea = new BorderLayout(0, 0);
  
  protected boolean m_bIsIE4 = false;
  
  protected boolean m_bIsNSWin16 = false;
  
  protected boolean m_bIsNSWin32 = false;
  
  protected boolean m_bIsIE3 = false;
  
  protected boolean m_bMacOS = false;
  
  protected boolean m_bUseForAppleList = false;
  
  private LayoutManager m_layout;
  
  MyThread m_textChangedThread = null;
  
  public boolean gotFocus(Event paramEvent, Object paramObject) {
    if (this.m_bUseForAppleList) {
      if (paramEvent.target != this.m_tfEdit && paramEvent.target != this.m_forapplelist && paramEvent.target != this.m_btnDisplay)
        this.m_tfEdit.requestFocus(); 
    } else if (paramEvent.target != this.m_tfEdit && paramEvent.target != this.m_list && paramEvent.target != this.m_btnDisplay) {
      this.m_tfEdit.requestFocus();
    } 
    return true;
  }
  
  public void HideList() {
    if (this.m_bUseForAppleList) {
      add("Center", this.m_forapplelistHolder);
      this.m_forapplelistHolder.show(true);
      this.m_forapplelist.show(false);
    } else {
      add("Center", this.m_listHolder);
      this.m_listHolder.show(true);
      this.m_list.show(false);
    } 
    paintComponents(getGraphics());
  }
  
  public IndexTree getForAppleList() { return this.m_forapplelistHolder; }
  
  public void MoveSelectionDown() {}
  
  public void dialogDone() { this.m_dlgSecondary = null; }
  
  public IndexPane(Applet paramApplet) {
    this.m_applet = paramApplet;
    try {
      if (System.getProperty("os.name").startsWith("MacOS"))
        this.m_bMacOS = true; 
      if (System.getProperty("java.vendor").startsWith("Netscape")) {
        if (System.getProperty("os.name").startsWith("16-bit Windows")) {
          this.m_bIsNSWin16 = true;
        } else if (System.getProperty("os.name").startsWith("Windows")) {
          if (System.getProperty("java.version").equalsIgnoreCase("1.02"))
            this.m_bUseForAppleList = true; 
          this.m_bIsNSWin32 = true;
        } else if (System.getProperty("os.name").startsWith("Mac")) {
          this.m_bUseForAppleList = true;
        } 
      } else if (System.getProperty("java.vendor").startsWith("Microsoft")) {
        if (System.getProperty("java.version").startsWith("1.1")) {
          this.m_bIsIE4 = true;
        } else {
          this.m_bIsIE3 = true;
        } 
        if (System.getProperty("os.name").startsWith("Mac"))
          this.m_bUseForAppleList = true; 
        if (System.getProperty("java.version").equalsIgnoreCase("1.1")) {
          this.m_bUseForAppleList = true;
        } else if (System.getProperty("java.version").equalsIgnoreCase("1.0.2")) {
          this.m_bUseForAppleList = true;
        } 
      } 
    } finally {}
    if (this.m_bUseForAppleList) {
      this.m_forapplelist = new IndexTree(this);
      this.m_forapplelistHolder = new IndexTree(null);
      this.m_forapplelistHolder.addItem("Loading Index Data...");
    } else {
      this.m_list = new List();
      this.m_listHolder = new List();
      this.m_listHolder.addItem("Loading Index Data...");
      this.m_listHolder.setBackground(Color.white);
    } 
    this.m_pnlEditArea.setLayout(this.m_layEditArea);
    this.m_pnlEditArea.add("North", this.m_lblEditArea);
    this.m_pnlEditArea.add("Center", this.m_tfEdit);
    this.m_layout = new BorderLayout(2, 2);
    setLayout(this.m_layout);
    if (!this.m_bUseForAppleList)
      this.m_list.setBackground(Color.white); 
    int i = WebHelp.GetFontSize();
    if (!this.m_bUseForAppleList)
      this.m_list.setFont(new Font(WebHelp.GetFontName(), 0, i)); 
    this.m_tfEdit.setFont(new Font(WebHelp.GetFontName(), 0, i));
    this.m_btnDisplay.setFont(new Font(WebHelp.GetFontName(), 0, i));
    if (this.m_bUseForAppleList) {
      add("Center", this.m_forapplelistHolder);
    } else {
      add("North", this.m_pnlEditArea);
      add("Center", this.m_listHolder);
      add("South", this.m_btnDisplay);
    } 
    this.m_tfEdit.requestFocus();
  }
  
  public void add(String paramString, Vector paramVector) {
    if (this.m_bUseForAppleList) {
      this.m_forapplelist.addItem(paramString);
    } else {
      this.m_list.addItem(paramString);
    } 
    this.m_vSecondaryEntries.addElement(paramVector);
  }
  
  public boolean mouseUp(Event paramEvent, int paramInt1, int paramInt2) { return super.mouseUp(paramEvent, paramInt1, paramInt2); }
  
  public List getList() { return this.m_list; }
  
  public void MoveSelectionPageDown() {}
  
  public int FindBaseKeywordForAppleList(int paramInt1, int paramInt2) {
    while ((paramInt1 > 0 && paramInt2 < 0) || (paramInt1 < this.m_forapplelist.countItems() - 1 && paramInt2 > 0)) {
      if (this.m_forapplelist.getItem(paramInt1).charAt(0) != ' ')
        return paramInt1; 
      paramInt1 += paramInt2;
    } 
    return paramInt1;
  }
  
  public void ShowList() {
    if (this.m_bUseForAppleList) {
      this.m_forapplelistHolder.show(false);
      add("North", this.m_pnlEditArea);
      add("Center", this.m_forapplelist);
      add("South", this.m_btnDisplay);
      this.m_forapplelist.show(true);
    } else {
      this.m_listHolder.show(false);
      add("North", this.m_pnlEditArea);
      add("Center", this.m_list);
      add("South", this.m_btnDisplay);
      this.m_list.show(true);
    } 
    paintAll(getGraphics());
    paintComponents(getGraphics());
  }
  
  public TextField getEditBox() { return this.m_tfEdit; }
  
  public boolean keyUp(Event paramEvent, int paramInt) {
    if ((paramEvent.target == this.m_forapplelist || paramEvent.target == this.m_list) && System.getProperty("java.version").equals("1.1") && System.getProperty("java.vendor").startsWith("Microsoft") && paramEvent.key == 10) {
      action(paramEvent, paramEvent.target);
      return true;
    } 
    if (this.m_bIsNSWin16)
      paramInt &= 0xFF; 
    boolean bool = super.keyUp(paramEvent, paramInt);
    if (paramInt >= 32 && paramInt <= 126 && paramEvent.target == this.m_tfEdit)
      try {
        textChanged();
        if (paramEvent.target == this.m_tfEdit)
          this.m_tfEdit.requestFocus(); 
      } finally {} 
    return bool;
  }
  
  public boolean GetUseForAppleListFlag() { return this.m_bUseForAppleList; }
  
  public void gotoSelectedIndex() {
    int i = -1;
    if (this.m_bUseForAppleList) {
      i = this.m_forapplelist.getSelectedIndex();
    } else {
      i = this.m_list.getSelectedIndex();
    } 
    if (i == -1)
      return; 
    if (((Vector)this.m_vSecondaryEntries.elementAt(i)).size() == 1) {
      IndexSecondaryEntry indexSecondaryEntry = (IndexSecondaryEntry)((Vector)this.m_vSecondaryEntries.elementAt(i)).elementAt(0);
      if (indexSecondaryEntry.see_also != null) {
        for (byte b = 0; b < this.m_vSecondaryEntries.size(); b++) {
          if (((Vector)this.m_vSecondaryEntries.elementAt(b)).size() == 1) {
            IndexSecondaryEntry indexSecondaryEntry1 = (IndexSecondaryEntry)((Vector)this.m_vSecondaryEntries.elementAt(b)).elementAt(0);
            if (indexSecondaryEntry1.name.equals(indexSecondaryEntry.see_also)) {
              if (this.m_bUseForAppleList) {
                this.m_forapplelist.select(b);
                if (b > 0) {
                  this.m_forapplelist.setTopIndex(b - 1);
                } else {
                  this.m_forapplelist.setTopIndex(b);
                } 
                gotoSelectedIndex();
                return;
              } 
              if (this.m_list.getVisibleIndex() != b) {
                this.m_list.makeVisible(this.m_forapplelist.countItems() - 1);
                if (b > 0) {
                  this.m_list.makeVisible(b - 1);
                } else {
                  this.m_list.makeVisible(b);
                } 
              } 
              this.m_list.select(b);
              gotoSelectedIndex();
              return;
            } 
          } 
        } 
        return;
      } 
      try {
        if (indexSecondaryEntry.frame != null) {
          this.m_applet.getAppletContext().showDocument(URLFileHandler.makeURL(this.m_applet.getDocumentBase(), indexSecondaryEntry.local, indexSecondaryEntry.url), indexSecondaryEntry.frame);
          return;
        } 
        this.m_applet.getAppletContext().showDocument(URLFileHandler.makeURL(this.m_applet.getDocumentBase(), indexSecondaryEntry.local, indexSecondaryEntry.url), "_self");
        return;
      } catch (MalformedURLException malformedURLException) {
        return;
      } 
    } 
    if (this.m_dlgSecondary != null) {
      this.m_dlgSecondary.closeDialog();
      this.m_dlgSecondary = null;
    } 
    this.m_dlgSecondary = new IndexSecondaryDialog(this.m_applet, (Vector)this.m_vSecondaryEntries.elementAt(i), this);
    this.m_dlgSecondary.show();
    this.m_dlgSecondary.getList().requestFocus();
  }
  
  public int FindBaseKeyword(int paramInt1, int paramInt2) {
    while ((paramInt1 > 0 && paramInt2 < 0) || (paramInt1 < this.m_list.countItems() - 1 && paramInt2 > 0)) {
      if (this.m_list.getItem(paramInt1).charAt(0) != ' ')
        return paramInt1; 
      paramInt1 += paramInt2;
    } 
    return paramInt1;
  }
  
  protected void finalize() {
    if (this.m_bUseForAppleList) {
      this.m_forapplelist.clear();
      this.m_forapplelist = null;
    } else {
      this.m_list.clear();
      this.m_list = null;
    } 
    super.finalize();
  }
  
  public boolean action(Event paramEvent, Object paramObject) {
    gotoSelectedIndex();
    return true;
  }
  
  public boolean handleEvent(Event paramEvent) {
    if (System.getProperty("java.version").startsWith("1.1.5") && this.m_bIsNSWin32 && paramEvent.id == 401 && paramEvent.key == 10 && paramEvent.target == this.m_btnDisplay) {
      action(paramEvent, paramEvent.target);
      return true;
    } 
    if (this.m_bIsIE4 && paramEvent.id == 1001 && paramEvent.target == this.m_tfEdit)
      return true; 
    if (paramEvent.target == this.m_list) {
      if (paramEvent.id == 701 && this.m_list.getSelectedIndex() != this.m_nSelectedIndex) {
        String str = this.m_list.getSelectedItem();
        this.m_nSelectedIndex = this.m_list.getSelectedIndex();
        if (str != null) {
          this.m_tfEdit.setText(str);
          this.m_applet.showStatus(str);
        } 
      } 
    } else if (paramEvent.target == this.m_tfEdit && paramEvent.id == 403) {
      switch (paramEvent.key) {
        case 1005:
          MoveSelectionDown();
          break;
        case 1004:
          MoveSelectionUp();
          break;
        case 1003:
          MoveSelectionPageDown();
          break;
        case 1002:
          MoveSelectionPageUp();
          break;
      } 
    } 
    return super.handleEvent(paramEvent);
  }
  
  public void textChanged() {
    if (this.m_textChangedThread == null) {
      this.m_textChangedThread = new MyThread(this);
      this.m_textChangedThread.setPriority(4);
      this.m_textChangedThread.start();
      return;
    } 
    this.m_textChangedThread.m_bResearch++;
  }
  
  public void MoveSelectionUp() {}
  
  public void MoveSelectionPageUp() {}
  
  public boolean keyDown(Event paramEvent, int paramInt) {
    if ((paramEvent.target == this.m_forapplelist || paramEvent.target == this.m_list) && (!System.getProperty("java.version").equals("1.1") || !System.getProperty("java.vendor").startsWith("Microsoft")) && paramEvent.key == 10) {
      action(paramEvent, paramEvent.target);
      return true;
    } 
    return super.keyDown(paramEvent, paramInt);
  }
  
  class MyThread extends Thread {
    int m_bResearch;
    
    final IndexPane this$0;
    
    MyThread(IndexPane this$0) {
      (this.this$0 = this$0).getClass();
      this.m_bResearch = 1;
    }
    
    public void run() {
      while (true) {
        while (this.m_bResearch <= 0) {
          try {
            Thread.sleep(100L);
          } catch (InterruptedException interruptedException) {}
        } 
        String str = this.this$0.m_tfEdit.getText().toUpperCase();
        int i = str.length();
        if (i > 0)
          if (this.this$0.m_bUseForAppleList) {
            int j = 0;
            int k = this.this$0.FindBaseKeywordForAppleList(this.this$0.m_forapplelist.countItems() - 1, -1);
            int m;
            for (m = this.this$0.FindBaseKeywordForAppleList((this.this$0.m_forapplelist.countItems() - 1) / 2, -1); j < k; m = this.this$0.FindBaseKeywordForAppleList((j + k) / 2, -1)) {
              String str1 = this.this$0.m_forapplelist.getItem(m).toUpperCase();
              int n = str1.compareTo(str);
              if (n > 0) {
                k = m;
              } else if (n < 0) {
                j = this.this$0.FindBaseKeywordForAppleList(m + 1, 1);
              } else {
                j = m;
                k = m;
              } 
            } 
            this.this$0.m_forapplelist.getItem(m).toUpperCase();
            if (m > this.this$0.m_forapplelist.countItems() - 1)
              m = this.this$0.m_forapplelist.countItems() - 1; 
            if (m < 0)
              m = 0; 
            if (m > 0) {
              this.this$0.m_forapplelist.setTopIndex(m - 1);
            } else {
              this.this$0.m_forapplelist.setTopIndex(m);
            } 
            this.this$0.m_forapplelist.select(m);
            this.this$0.m_nSelectedIndex = m;
            this.this$0.m_applet.showStatus(this.this$0.m_forapplelist.getSelectedItem());
          } else {
            int j = 0;
            int k = this.this$0.FindBaseKeyword(this.this$0.m_list.countItems() - 1, -1);
            int m;
            for (m = this.this$0.FindBaseKeyword((this.this$0.m_list.countItems() - 1) / 2, -1); j < k; m = this.this$0.FindBaseKeyword((j + k) / 2, -1)) {
              String str1 = this.this$0.m_list.getItem(m).toUpperCase();
              int n = str1.compareTo(str);
              if (n > 0) {
                k = m;
              } else if (n < 0) {
                j = this.this$0.FindBaseKeyword(m + 1, 1);
              } else {
                j = m;
                k = m;
              } 
            } 
            this.this$0.m_list.getItem(m).toUpperCase();
            if (m > this.this$0.m_list.countItems() - 1)
              m = this.this$0.m_list.countItems() - 1; 
            if (m < 0)
              m = 0; 
            if (m != this.this$0.m_nSelectedIndex) {
              this.this$0.m_list.makeVisible(this.this$0.m_list.countItems() - 1);
              if (m > 0) {
                this.this$0.m_list.makeVisible(m - 1);
              } else {
                this.this$0.m_list.makeVisible(m);
              } 
              this.this$0.m_list.getVisibleIndex();
              this.this$0.m_list.select(m);
              this.this$0.m_nSelectedIndex = m;
            } 
            this.this$0.m_applet.showStatus(this.this$0.m_list.getSelectedItem());
          }  
        this.m_bResearch--;
      } 
    }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\Help\webhelp.zip!\hhapplet\IndexPane.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */