package hhapplet;

import java.applet.Applet;
import java.awt.Label;
import java.io.IOException;
import java.net.URL;
import java.util.Vector;
import sitemap.MyBufferedInputStream;

public class FTSParser extends Thread {
  protected Applet m_applet;
  
  protected FTSPane m_spSearch;
  
  protected FTSSearcher m_ftsSearcher;
  
  protected Thread m_Thread;
  
  protected MyBufferedInputStream m_is;
  
  protected int m_nTotalBytesRead;
  
  protected int m_nOffset = 0;
  
  protected String m_strFileName;
  
  protected URL m_urlDocBase;
  
  public FTSSearcher getSearcher() { return this.m_ftsSearcher; }
  
  public void parse() { run(); }
  
  public Thread parseInSeparateThread(String paramString, URL paramURL) {
    this.m_strFileName = paramString;
    this.m_urlDocBase = paramURL;
    setPriority(4);
    start();
    return this;
  }
  
  protected boolean advancePastQuoteInStream() {
    try {
      byte b;
      do {
        b = (byte)this.m_is.read();
        this.m_nTotalBytesRead++;
      } while (b != 10 && b != 34);
      return (b == 34);
    } catch (IOException iOException) {
      return false;
    } 
  }
  
  protected boolean advancePastCommaInStream() {
    try {
      byte b;
      do {
        b = (byte)this.m_is.read();
        this.m_nTotalBytesRead++;
      } while (b != 10 && b != 44);
      return (b == 44);
    } catch (IOException iOException) {
      return false;
    } 
  }
  
  public FTSParser(Applet paramApplet) {
    this.m_applet = paramApplet;
    this.m_ftsSearcher = new FTSSearcher(this.m_applet);
    this.m_spSearch = new FTSPane(this.m_applet, this.m_ftsSearcher);
    this.m_ftsSearcher.setPane(this.m_spSearch);
  }
  
  protected boolean advancePastEOLInStream() {
    try {
      byte b;
      do {
        b = (byte)this.m_is.read();
        this.m_nTotalBytesRead++;
      } while (b != 10);
      return true;
    } catch (IOException iOException) {
      return false;
    } 
  }
  
  protected String getStringFromStream() {
    String str = new String();
    try {
      byte b = (byte)this.m_is.read();
      this.m_nTotalBytesRead++;
      if (b == 34) {
        b = (byte)this.m_is.read();
        this.m_nTotalBytesRead++;
      } 
      while (b != 34) {
        if (b < 0) {
          str = str + (char)(b + 256);
        } else {
          str = str + (char)b;
        } 
        b = (byte)this.m_is.read();
        this.m_nTotalBytesRead++;
      } 
      return str;
    } catch (IOException iOException) {
      return null;
    } 
  }
  
  protected String getStopWordFromStream() {
    String str = new String();
    str = getStringFromStream();
    advancePastEOLInStream();
    return str;
  }
  
  protected String getKeywordNameFromStream() {
    String str = getStringFromStream();
    advancePastCommaInStream();
    return str;
  }
  
  protected String getTopicTitleFromStream() {
    String str = new String();
    str = getStringFromStream();
    advancePastCommaInStream();
    return str;
  }
  
  protected String getTopicURLFromStream() {
    String str = new String();
    str = getStringFromStream();
    advancePastEOLInStream();
    return str;
  }
  
  public void UpdateStreamStatus() { this.m_applet.showStatus("Reading Search Data [" + this.m_nTotalBytesRead + "]"); }
  
  public void run() {
    this.m_spSearch.getEditBox().enable(false);
    try {
      this.m_is = new MyBufferedInputStream(URLFileHandler.makeURL(this.m_urlDocBase, this.m_strFileName, null).openStream());
    } catch (Exception exception) {
      this.m_applet.add("Center", new Label("Can't open URL or file " + exception.getMessage()));
      return;
    } 
    this.m_nTotalBytesRead = 0;
    int i = getCountFromStream("TOPICS=");
    UpdateStreamStatus();
    this.m_ftsSearcher.setTopicCount(i);
    byte b;
    for (b = 0; b < i; b++) {
      String str1 = getTopicTitleFromStream();
      String str2 = getTopicURLFromStream();
      this.m_ftsSearcher.setTopicData(b, str1, str2);
      if (b % 'È' == '\000')
        UpdateStreamStatus(); 
    } 
    int j = getCountFromStream("KEYWORDS=");
    UpdateStreamStatus();
    this.m_ftsSearcher.setKeywordCount(j);
    for (b = 0; b < j; b++) {
      String str = getKeywordNameFromStream();
      if (str == null) {
        Object object = null;
      } else {
        String str1 = str.toLowerCase();
      } 
      int[] arrayOfInt = getKeywordLinksFromStream();
      this.m_ftsSearcher.setKeywordData(b, str, arrayOfInt);
      if (b % 'È' == '\000')
        UpdateStreamStatus(); 
    } 
    int k = getCountFromStream("STOPWORDS=");
    UpdateStreamStatus();
    this.m_ftsSearcher.setStopWordCount(k);
    for (b = 0; b < k; b++) {
      String str = getStopWordFromStream();
      this.m_ftsSearcher.setStopWord(b, str);
      if (b % 'È' == '\000')
        UpdateStreamStatus(); 
    } 
    if (this.m_spSearch != null && this.m_spSearch.getList() != null)
      this.m_spSearch.getList().clear(); 
    if (this.m_spSearch != null && this.m_spSearch.getforappleList() != null) {
      this.m_spSearch.getforappleList().clear();
      this.m_spSearch.paintComponents(this.m_spSearch.getGraphics());
    } 
    this.m_spSearch.ShowList();
    this.m_applet.showStatus("Done");
    this.m_spSearch.getEditBox().enable(true);
    this.m_spSearch.getEditBox().requestFocus();
  }
  
  public FTSPane getFTS() { return this.m_spSearch; }
  
  protected Integer getIntegerFromStream() {
    String str = new String();
    try {
      byte b = (byte)this.m_is.read();
      this.m_nTotalBytesRead++;
      while (b == 32) {
        b = (byte)this.m_is.read();
        this.m_nTotalBytesRead++;
      } 
      while (b >= 48 && b <= 57) {
        if (b < 0) {
          str = str + (char)(b + 256);
        } else {
          str = str + (char)b;
        } 
        b = (byte)this.m_is.read();
        this.m_nTotalBytesRead++;
      } 
      if (b == 10)
        return null; 
      Integer integer = null;
      try {
        integer = new Integer(str);
      } catch (NumberFormatException numberFormatException) {
        integer = null;
        System.out.println("Error at Byte #" + this.m_nTotalBytesRead + " in stream.");
      } 
      return integer;
    } catch (IOException iOException) {
      return null;
    } 
  }
  
  protected int getCountFromStream(String paramString) {
    String str = new String();
    boolean bool = false;
    byte b = 0;
    try {
      byte b1 = (byte)this.m_is.read();
      this.m_nTotalBytesRead++;
      while (!bool) {
        while (b1 != 91) {
          b1 = (byte)this.m_is.read();
          this.m_nTotalBytesRead++;
        } 
        b1 = (byte)this.m_is.read();
        this.m_nTotalBytesRead++;
        while (b < paramString.length() && b1 == paramString.charAt(b) && b1 != 93) {
          b1 = (byte)this.m_is.read();
          this.m_nTotalBytesRead++;
          b++;
        } 
        if (b == paramString.length()) {
          bool = true;
          continue;
        } 
        b = 0;
      } 
      while (b1 >= 48 && b1 <= 57) {
        if (b1 < 0) {
          str = str + (char)(b1 + 256);
        } else {
          str = str + (char)b1;
        } 
        b1 = (byte)this.m_is.read();
        this.m_nTotalBytesRead++;
      } 
      if (b1 == 10)
        return 0; 
      advancePastEOLInStream();
      return Integer.parseInt(str);
    } catch (IOException iOException) {
      return 0;
    } 
  }
  
  protected int[] getKeywordLinksFromStream() {
    Vector vector = new Vector();
    Integer integer = null;
    do {
      integer = getIntegerFromStream();
      if (integer == null)
        continue; 
      vector.addElement(integer);
    } while (integer != null);
    int[] arrayOfInt = new int[vector.size()];
    for (byte b = 0; b < arrayOfInt.length; b++)
      arrayOfInt[b] = ((Integer)vector.elementAt(b)).intValue(); 
    return arrayOfInt;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\Help\webhelp.zip!\hhapplet\FTSParser.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */