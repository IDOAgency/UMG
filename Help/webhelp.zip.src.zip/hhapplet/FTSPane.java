package hhapplet;

import WebHelp;
import java.applet.Applet;
import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Color;
import java.awt.Event;
import java.awt.Font;
import java.awt.Label;
import java.awt.LayoutManager;
import java.awt.List;
import java.awt.Panel;
import java.awt.TextField;
import java.net.MalformedURLException;
import java.net.URL;

public class FTSPane extends Panel implements DialogDoneTarget {
  protected Applet m_applet;
  
  protected List m_list;
  
  protected List m_listHolder;
  
  protected SearchTree m_forapplelistHolder;
  
  protected SearchTree m_forapplelist;
  
  protected TextField m_tfEdit = new TextField();
  
  protected FTSNorthPanel m_pnlNorth = new FTSNorthPanel(this);
  
  protected Button m_btnDisplay = new Button("Display");
  
  protected Button m_btnFind = new Button("Find");
  
  protected IndexSecondaryDialog m_dlgSecondary;
  
  protected int m_nSelectedIndex = -1;
  
  protected FTSSearcher m_ftsSearcher = null;
  
  protected Panel m_pnlEditArea = new Panel();
  
  protected Label m_lblEditArea = new Label("Type in the word(s) to search for:");
  
  protected LayoutManager m_layEditArea = new BorderLayout(0, 0);
  
  protected boolean m_bIsIE4 = false;
  
  protected boolean m_bIsNSWin16 = false;
  
  protected boolean m_bIsNSWin32 = false;
  
  protected boolean m_bIsIE3 = false;
  
  protected boolean m_bUseForAppleList = false;
  
  private LayoutManager m_layout;
  
  public boolean gotFocus(Event paramEvent, Object paramObject) {
    if (paramEvent.target != this.m_tfEdit && paramEvent.target != this.m_list && paramEvent.target != this.m_forapplelist && paramEvent.target != this.m_btnDisplay && paramEvent.target != this.m_btnFind)
      this.m_tfEdit.requestFocus(); 
    return true;
  }
  
  public void HideList() {
    if (!this.m_bUseForAppleList) {
      this.m_listHolder.clear();
      this.m_listHolder.addItem("Searching...");
      this.m_list.show(false);
      add("Center", this.m_listHolder);
      this.m_listHolder.show(true);
      layout();
      paintAll(getGraphics());
    } 
    paintComponents(getGraphics());
  }
  
  public SearchTree getforappleList() { return this.m_forapplelist; }
  
  public void dialogDone() {
    this.m_dlgSecondary = null;
    this.m_tfEdit.requestFocus();
  }
  
  public FTSPane(Applet paramApplet, FTSSearcher paramFTSSearcher) {
    this.m_applet = paramApplet;
    this.m_ftsSearcher = paramFTSSearcher;
    this.m_layout = new BorderLayout(2, 2);
    setLayout(this.m_layout);
    try {
      if (System.getProperty("java.vendor").startsWith("Netscape")) {
        if (System.getProperty("os.name").startsWith("16-bit Windows")) {
          this.m_bIsNSWin16 = true;
        } else if (System.getProperty("os.name").startsWith("Windows")) {
          this.m_bIsNSWin32 = true;
        } else if (System.getProperty("os.name").startsWith("Mac")) {
        
        } 
      } else if (System.getProperty("java.vendor").startsWith("Microsoft")) {
        if (System.getProperty("java.version").startsWith("1.1")) {
          this.m_bIsIE4 = true;
        } else {
          this.m_bIsIE3 = true;
        } 
        if (System.getProperty("os.name").startsWith("Mac"))
          this.m_bUseForAppleList = true; 
      } 
    } finally {}
    if (this.m_bUseForAppleList) {
      this.m_forapplelistHolder = new SearchTree(this);
      this.m_forapplelist = new SearchTree(this);
    } else {
      this.m_list = new List();
      this.m_listHolder = new List();
      this.m_list.setBackground(Color.white);
    } 
    int i = WebHelp.GetFontSize();
    if (this.m_list != null)
      this.m_list.setFont(new Font(WebHelp.GetFontName(), 0, i)); 
    this.m_tfEdit.setFont(new Font(WebHelp.GetFontName(), 0, i));
    this.m_btnDisplay.setFont(new Font(WebHelp.GetFontName(), 0, i));
    this.m_btnFind.setFont(new Font(WebHelp.GetFontName(), 0, i));
    this.m_pnlEditArea.setLayout(this.m_layEditArea);
    this.m_pnlEditArea.add("North", this.m_lblEditArea);
    this.m_pnlEditArea.add("Center", this.m_tfEdit);
    if (this.m_bUseForAppleList) {
      this.m_forapplelistHolder.addItem("Loading Search Data...");
      this.m_forapplelist.addItem("Loading Search Data...");
    } else {
      this.m_listHolder.addItem("Loading Search Data...");
      this.m_listHolder.setBackground(Color.white);
    } 
    this.m_pnlNorth.add("North", this.m_pnlEditArea);
    this.m_pnlNorth.add("South", this.m_btnFind);
    add("North", this.m_pnlNorth);
    if (this.m_bUseForAppleList) {
      add("Center", this.m_forapplelist);
    } else {
      add("Center", this.m_listHolder);
    } 
    add("South", this.m_btnDisplay);
    this.m_tfEdit.requestFocus();
  }
  
  public List getList() { return this.m_list; }
  
  public void ShowList() {
    if (!this.m_bUseForAppleList) {
      this.m_listHolder.show(false);
      this.m_layout.removeLayoutComponent(this.m_listHolder);
      add("Center", this.m_list);
      add("South", this.m_btnDisplay);
      this.m_list.show(true);
      layout();
      paintAll(getGraphics());
    } 
    paintComponents(getGraphics());
  }
  
  public TextField getEditBox() { return this.m_tfEdit; }
  
  public boolean keyUp(Event paramEvent, int paramInt) {
    if (this.m_bIsNSWin16)
      paramInt &= 0xFF; 
    if ((this.m_bIsIE4 || this.m_bIsIE3 || this.m_bIsNSWin32) && paramEvent.key == 10) {
      if (System.getProperty("java.version").startsWith("1.1.5") && this.m_bIsNSWin32)
        return super.keyUp(paramEvent, paramInt); 
      if (System.getProperty("java.version").startsWith("1.0.2") && System.getProperty("java.vendor").startsWith("Microsoft"))
        return super.keyUp(paramEvent, paramInt); 
      if (System.getProperty("java.version").startsWith("1.02") && System.getProperty("java.vendor").startsWith("Netscape"))
        return super.keyUp(paramEvent, paramInt); 
      if (paramEvent.target == this.m_forapplelist || paramEvent.target == this.m_list || paramEvent.target == this.m_tfEdit) {
        action(paramEvent, paramEvent.target);
        return true;
      } 
    } 
    boolean bool = super.keyUp(paramEvent, paramInt);
    if (paramInt >= 32 && paramInt <= 126)
      try {
        textChanged();
        if (paramEvent.target == this.m_tfEdit)
          this.m_tfEdit.requestFocus(); 
      } finally {} 
    return bool;
  }
  
  protected void gotoSelectedIndex() {
    if (this.m_bUseForAppleList) {
      int j = this.m_forapplelist.getSelectedIndex();
      if (j == -1)
        return; 
      try {
        String str1 = this.m_applet.getParameter("Frame");
        String str2 = this.m_ftsSearcher.getTopicURL(this.m_forapplelist.getItem(j));
        if (str2 == null || str2.length() == 0)
          return; 
        URL uRL = URLFileHandler.makeURL(this.m_applet.getDocumentBase(), str2, "");
        if (str1 == null) {
          this.m_applet.getAppletContext().showDocument(uRL, "_self");
          return;
        } 
        this.m_applet.getAppletContext().showDocument(uRL, str1);
        return;
      } catch (MalformedURLException malformedURLException) {
        return;
      } 
    } 
    int i = this.m_list.getSelectedIndex();
    if (i == -1)
      return; 
    try {
      String str1 = this.m_applet.getParameter("Frame");
      String str2 = this.m_ftsSearcher.getTopicURL(this.m_list.getItem(i));
      if (str2 == null || str2.length() == 0)
        return; 
      URL uRL = URLFileHandler.makeURL(this.m_applet.getDocumentBase(), str2, "");
      if (str1 == null) {
        this.m_applet.getAppletContext().showDocument(uRL, "_self");
        return;
      } 
      this.m_applet.getAppletContext().showDocument(uRL, str1);
      return;
    } catch (MalformedURLException malformedURLException) {
      return;
    } 
  }
  
  protected void finalize() {
    if (this.m_bUseForAppleList) {
      this.m_forapplelist.clear();
      this.m_forapplelist = null;
    } else {
      this.m_list.clear();
      this.m_list = null;
    } 
    super.finalize();
  }
  
  public boolean action(Event paramEvent, Object paramObject) {
    System.out.println("action(" + paramEvent.toString() + ", " + paramObject.toString() + ")");
    if (paramEvent.target == this.m_btnFind || paramEvent.target == this.m_tfEdit) {
      if (this.m_bUseForAppleList) {
        this.m_ftsSearcher.doSearch(this.m_tfEdit.getText(), null, this.m_forapplelist);
      } else {
        this.m_ftsSearcher.doSearch(this.m_tfEdit.getText(), this.m_list, null);
      } 
      paintComponents(getGraphics());
    } else {
      gotoSelectedIndex();
    } 
    return true;
  }
  
  public boolean handleEvent(Event paramEvent) {
    if (System.getProperty("java.version").equalsIgnoreCase("1.0.2") && System.getProperty("java.vendor").startsWith("Microsoft") && paramEvent.id == 402 && paramEvent.key == 10 && paramEvent.target != this.m_tfEdit) {
      action(paramEvent, paramEvent.target);
      return true;
    } 
    if (System.getProperty("java.version").equalsIgnoreCase("1.1.5") && this.m_bIsNSWin32 && paramEvent.id == 402 && paramEvent.key == 10 && paramEvent.target != this.m_tfEdit) {
      action(paramEvent, paramEvent.target);
      return true;
    } 
    if (this.m_bIsIE4 && paramEvent.id == 1001 && paramEvent.target == this.m_tfEdit)
      return true; 
    if (paramEvent.target == this.m_list && paramEvent.id == 701 && this.m_list.getSelectedIndex() != this.m_nSelectedIndex) {
      String str1 = this.m_list.getSelectedItem();
      String str2 = this.m_ftsSearcher.getTopicURL(this.m_list.getSelectedItem());
      this.m_nSelectedIndex = this.m_list.getSelectedIndex();
      if (str2 != null && str2.length() != 0 && str1 != null) {
        this.m_applet.showStatus(str1);
        this.m_list.requestFocus();
      } 
    } 
    return super.handleEvent(paramEvent);
  }
  
  public void textChanged() {}
  
  private class FTSNorthPanel extends Panel {
    private LayoutManager m_layout;
    
    final FTSPane this$0;
    
    FTSNorthPanel(FTSPane this$0) {
      (this.this$0 = this$0).getClass();
      this.m_layout = new BorderLayout(2, 2);
      setLayout(this.m_layout);
    }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\Help\webhelp.zip!\hhapplet\FTSPane.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */