package hhapplet;

interface DialogDoneTarget {
  void dialogDone();
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\Help\webhelp.zip!\hhapplet\DialogDoneTarget.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */