package hhapplet;

class MyThread extends Thread {
  int m_bResearch;
  
  final IndexPane this$0;
  
  MyThread(IndexPane paramIndexPane) {
    (this.this$0 = paramIndexPane).getClass();
    this.m_bResearch = 1;
  }
  
  public void run() {
    while (true) {
      while (this.m_bResearch <= 0) {
        try {
          Thread.sleep(100L);
        } catch (InterruptedException interruptedException) {}
      } 
      String str = this.this$0.m_tfEdit.getText().toUpperCase();
      int i = str.length();
      if (i > 0)
        if (this.this$0.m_bUseForAppleList) {
          int j = 0;
          int k = this.this$0.FindBaseKeywordForAppleList(this.this$0.m_forapplelist.countItems() - 1, -1);
          int m;
          for (m = this.this$0.FindBaseKeywordForAppleList((this.this$0.m_forapplelist.countItems() - 1) / 2, -1); j < k; m = this.this$0.FindBaseKeywordForAppleList((j + k) / 2, -1)) {
            String str1 = this.this$0.m_forapplelist.getItem(m).toUpperCase();
            int n = str1.compareTo(str);
            if (n > 0) {
              k = m;
            } else if (n < 0) {
              j = this.this$0.FindBaseKeywordForAppleList(m + 1, 1);
            } else {
              j = m;
              k = m;
            } 
          } 
          this.this$0.m_forapplelist.getItem(m).toUpperCase();
          if (m > this.this$0.m_forapplelist.countItems() - 1)
            m = this.this$0.m_forapplelist.countItems() - 1; 
          if (m < 0)
            m = 0; 
          if (m > 0) {
            this.this$0.m_forapplelist.setTopIndex(m - 1);
          } else {
            this.this$0.m_forapplelist.setTopIndex(m);
          } 
          this.this$0.m_forapplelist.select(m);
          this.this$0.m_nSelectedIndex = m;
          this.this$0.m_applet.showStatus(this.this$0.m_forapplelist.getSelectedItem());
        } else {
          int j = 0;
          int k = this.this$0.FindBaseKeyword(this.this$0.m_list.countItems() - 1, -1);
          int m;
          for (m = this.this$0.FindBaseKeyword((this.this$0.m_list.countItems() - 1) / 2, -1); j < k; m = this.this$0.FindBaseKeyword((j + k) / 2, -1)) {
            String str1 = this.this$0.m_list.getItem(m).toUpperCase();
            int n = str1.compareTo(str);
            if (n > 0) {
              k = m;
            } else if (n < 0) {
              j = this.this$0.FindBaseKeyword(m + 1, 1);
            } else {
              j = m;
              k = m;
            } 
          } 
          this.this$0.m_list.getItem(m).toUpperCase();
          if (m > this.this$0.m_list.countItems() - 1)
            m = this.this$0.m_list.countItems() - 1; 
          if (m < 0)
            m = 0; 
          if (m != this.this$0.m_nSelectedIndex) {
            this.this$0.m_list.makeVisible(this.this$0.m_list.countItems() - 1);
            if (m > 0) {
              this.this$0.m_list.makeVisible(m - 1);
            } else {
              this.this$0.m_list.makeVisible(m);
            } 
            this.this$0.m_list.getVisibleIndex();
            this.this$0.m_list.select(m);
            this.this$0.m_nSelectedIndex = m;
          } 
          this.this$0.m_applet.showStatus(this.this$0.m_list.getSelectedItem());
        }  
      this.m_bResearch--;
    } 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\Help\webhelp.zip!\hhapplet\IndexPane$MyThread.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */