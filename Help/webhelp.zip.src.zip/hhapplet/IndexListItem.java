package hhapplet;

import java.util.Vector;

public class IndexListItem {
  public IndexSecondaryEntry main_entry;
  
  public Vector secondary_entries;
  
  IndexListItem(IndexSecondaryEntry paramIndexSecondaryEntry, Vector paramVector) {
    this.main_entry = paramIndexSecondaryEntry;
    this.secondary_entries = paramVector;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\Help\webhelp.zip!\hhapplet\IndexListItem.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */