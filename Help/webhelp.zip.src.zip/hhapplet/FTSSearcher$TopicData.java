package hhapplet;

class TopicData {
  public String m_strTitle;
  
  public String m_urlTopic;
  
  final FTSSearcher this$0;
  
  TopicData(FTSSearcher paramFTSSearcher) { (this.this$0 = paramFTSSearcher).getClass(); }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\Help\webhelp.zip!\hhapplet\FTSSearcher$TopicData.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */