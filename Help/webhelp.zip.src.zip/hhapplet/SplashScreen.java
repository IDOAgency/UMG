package hhapplet;

import java.applet.Applet;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Label;
import java.awt.MediaTracker;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.Window;

public class SplashScreen extends Window implements Runnable {
  private Thread thread = new Thread(this, "Splash screen");
  
  private Image image;
  
  private int timeout;
  
  private boolean m_bIsIE3 = false;
  
  private Point m_pntPosition;
  
  public SplashScreen(Applet paramApplet, Image paramImage, int paramInt, String paramString) {
    super(new Frame("Splash screen hidden window"));
    this.image = paramImage;
    this.timeout = (paramInt == 0) ? 2500 : paramInt;
    if (System.getProperty("java.vendor").startsWith("Microsoft") && System.getProperty("java.version").startsWith("1.0"))
      this.m_bIsIE3 = true; 
    try {
      if (paramImage != null) {
        paramApplet.showStatus("Loading splash screen");
        MediaTracker mediaTracker = new MediaTracker(this);
        mediaTracker.addImage(paramImage, 0);
        mediaTracker.waitForID(0);
        resize(paramImage.getWidth(this), paramImage.getHeight(this));
      } else {
        add("Center", new Label(paramString));
        resize(200, 100);
      } 
      Rectangle rectangle = bounds();
      Dimension dimension = Toolkit.getDefaultToolkit().getScreenSize();
      int i = dimension.width / 2 - rectangle.width / 2;
      int j = dimension.height / 2 - rectangle.height / 2;
      this.m_pntPosition = new Point(i, j);
      move(i, j);
      show();
      this.thread.start();
      return;
    } catch (InterruptedException interruptedException) {
      return;
    } 
  }
  
  public void paint(Graphics paramGraphics) {
    if (this.image != null)
      paramGraphics.drawImage(this.image, 0, 0, this); 
  }
  
  public void show() {
    if (this.m_bIsIE3) {
      Dimension dimension = size();
      reshape(this.m_pntPosition.x, this.m_pntPosition.y, dimension.width, dimension.height);
      super.show();
      reshape(this.m_pntPosition.x, this.m_pntPosition.y, dimension.width, dimension.height);
      return;
    } 
    super.show();
  }
  
  public void run() {
    try {
      Thread.sleep(this.timeout);
    } catch (InterruptedException interruptedException) {}
    dispose();
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\Help\webhelp.zip!\hhapplet\SplashScreen.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */