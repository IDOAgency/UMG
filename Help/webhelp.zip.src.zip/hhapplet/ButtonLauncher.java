package hhapplet;

import java.awt.Button;
import java.awt.Event;
import java.awt.Window;

public class ButtonLauncher extends Button {
  Window m_window;
  
  public ButtonLauncher(String paramString, Window paramWindow) {
    this.m_window = paramWindow;
    int i = paramString.indexOf(':');
    if (i == -1)
      return; 
    String str1 = paramString.substring(0, i);
    String str2 = paramString.substring(i + 1);
    if (!str1.equalsIgnoreCase("Text"))
      return; 
    setLabel(str2);
  }
  
  public boolean action(Event paramEvent, Object paramObject) {
    this.m_window.show();
    return true;
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\Help\webhelp.zip!\hhapplet\ButtonLauncher.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */