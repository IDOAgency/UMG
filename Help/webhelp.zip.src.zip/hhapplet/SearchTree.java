package hhapplet;

import java.awt.Color;
import treeview.TreeView;
import treeview.TreeViewNode;

public class SearchTree extends TreeView {
  FTSPane m_sp;
  
  private SearchTreeNode m_root = new SearchTreeNode(this);
  
  int m_nVisibleIndex = -1;
  
  int m_nCountCache = -1;
  
  public String getItem(int paramInt) {
    SearchTreeNode searchTreeNode = (SearchTreeNode)this.m_root.getChild();
    for (byte b = 0; b < paramInt; b++)
      searchTreeNode = (SearchTreeNode)searchTreeNode.getSibling(); 
    return searchTreeNode.getLabel();
  }
  
  public SearchTree(FTSPane paramFTSPane) {
    this.m_sp = paramFTSPane;
    this.m_root = new SearchTreeNode(this);
    this.m_root.expandTree();
    setRoot(this.m_root);
    setBackground(new Color(255, 255, 255));
    this.m_nCountCache = -1;
  }
  
  public int getVisibleIndex() { return this.m_nVisibleIndex; }
  
  public int countItems() {
    if (this.m_nCountCache == -1) {
      SearchTreeNode searchTreeNode = (SearchTreeNode)this.m_root.getChild();
      this.m_nCountCache = 0;
      while (searchTreeNode != null) {
        this.m_nCountCache++;
        searchTreeNode = (SearchTreeNode)searchTreeNode.getSibling();
      } 
    } 
    return this.m_nCountCache;
  }
  
  public String getSelectedItem() {
    for (SearchTreeNode searchTreeNode = (SearchTreeNode)this.m_root.getChild(); searchTreeNode != null; searchTreeNode = (SearchTreeNode)searchTreeNode.getSibling()) {
      if (searchTreeNode.isSelected() == true)
        return searchTreeNode.getLabel(); 
    } 
    return "";
  }
  
  public void select(int paramInt) {
    SearchTreeNode searchTreeNode = (SearchTreeNode)this.m_root.getChild();
    for (byte b = 0; searchTreeNode != null; b++) {
      if (b == paramInt) {
        searchTreeNode.select(true);
      } else {
        searchTreeNode.select(false);
      } 
      searchTreeNode = (SearchTreeNode)searchTreeNode.getSibling();
    } 
    paintAll(getGraphics());
  }
  
  public void addItem(String paramString) {
    SearchTreeNode searchTreeNode = new SearchTreeNode(this);
    searchTreeNode.setLabel(paramString);
    this.m_root.addChild(searchTreeNode);
    this.m_nCountCache = -1;
  }
  
  public void makeVisible(int paramInt) {
    this.m_nVisibleIndex = paramInt;
    SearchTreeNode searchTreeNode = (SearchTreeNode)this.m_root.getChild();
    for (byte b = 0; b < paramInt; b++)
      searchTreeNode = (SearchTreeNode)searchTreeNode.getSibling(); 
    EnsureDisplayed(searchTreeNode);
    paintAll(getGraphics());
  }
  
  public int getSelectedIndex() {
    SearchTreeNode searchTreeNode = (SearchTreeNode)this.m_root.getChild();
    for (byte b = 0; searchTreeNode != null; b++) {
      if (searchTreeNode.isSelected() == true)
        return b; 
      searchTreeNode = (SearchTreeNode)searchTreeNode.getSibling();
    } 
    return -1;
  }
  
  public void clear() {
    this.m_root = new SearchTreeNode(this);
    setRoot(this.m_root);
    this.m_root.expandTree();
    this.m_nCountCache = -1;
    paintAll(getGraphics());
  }
  
  class SearchTreeNode extends TreeViewNode {
    final SearchTree this$0;
    
    public void doDblClick() { this.this$0.m_sp.gotoSelectedIndex(); }
    
    SearchTreeNode(SearchTree this$0) { (this.this$0 = this$0).getClass(); }
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Local.war!\Help\webhelp.zip!\hhapplet\SearchTree.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */