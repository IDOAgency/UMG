import java.awt.Window;

class MethodRunner extends Thread {
  Window m_winToShow;
  
  public MethodRunner(Window paramWindow, String paramString) {
    super(paramString);
    this.m_winToShow = paramWindow;
  }
  
  public void run() {
    if (this.m_winToShow != null)
      this.m_winToShow.show(); 
  }
}


/* Location:              D:\Documents\NetBeansProjects\milestone2 Prod.war!\Help\webhelp.zip!\MethodRunner.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       1.0.7
 */